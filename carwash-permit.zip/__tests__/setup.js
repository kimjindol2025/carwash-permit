/**
 * Jest 테스트 설정
 */

// 환경변수 설정
process.env.NODE_ENV = 'test';
process.env.USE_MOCK = 'false';
process.env.ADMIN_PASSWORD = 'test_password';

// 전역 타임아웃 설정
jest.setTimeout(10000);
