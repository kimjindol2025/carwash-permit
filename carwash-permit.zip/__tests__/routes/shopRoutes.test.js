/**
 * 쇼핑몰 라우트 테스트
 */

const request = require('supertest');
const express = require('express');
const db = require('../../db/init');
const shopRoutes = require('../../routes/shopRoutes');

describe('Shopping Routes', () => {
  let app;

  beforeAll(() => {
    app = express();
    app.use(express.json());
    app.use('/api/shop', shopRoutes);
  });

  describe('GET /api/shop/categories', () => {
    it('should return all categories with success code', async () => {
      const response = await request(app).get('/api/shop/categories');

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.code).toBe('CATEGORIES_FOUND');
      expect(Array.isArray(response.body.data)).toBe(true);
      expect(response.body.data.length).toBeGreaterThan(0);
    });

    it('should have required category fields', async () => {
      const response = await request(app).get('/api/shop/categories');
      const category = response.body.data[0];

      expect(category).toHaveProperty('id');
      expect(category).toHaveProperty('name');
      expect(category).toHaveProperty('slug');
    });

    it('should have required response structure', async () => {
      const response = await request(app).get('/api/shop/categories');

      expect(response.body).toHaveProperty('success');
      expect(response.body).toHaveProperty('code');
      expect(response.body).toHaveProperty('data');
    });
  });

  describe('GET /api/shop/products', () => {
    it('should return products with pagination', async () => {
      const response = await request(app).get('/api/shop/products?limit=10');

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.code).toBe('PRODUCTS_FOUND');
      expect(response.body.data).toBeDefined();
      expect(response.body.pagination).toBeDefined();
      expect(response.body.pagination).toHaveProperty('page');
      expect(response.body.pagination).toHaveProperty('limit');
      expect(response.body.pagination).toHaveProperty('total');
    });

    it('should filter products by category', async () => {
      const response = await request(app).get('/api/shop/products?category_id=1&limit=10');

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);

      if (response.body.data.length > 0) {
        response.body.data.forEach(product => {
          expect(product.category_id).toBe(1);
        });
      }
    });

    it('should search products by name', async () => {
      const response = await request(app).get('/api/shop/products?search=처리기');

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
    });

    it('should handle pagination limits', async () => {
      const response = await request(app).get('/api/shop/products?limit=5&page=1');

      expect(response.status).toBe(200);
      expect(response.body.pagination.limit).toBeLessThanOrEqual(5);
    });
  });

  describe('GET /api/shop/products/:id', () => {
    it('should return product detail by id', async () => {
      const response = await request(app).get('/api/shop/products/1');

      if (response.status === 200) {
        expect(response.body.success).toBe(true);
        expect(response.body.code).toBe('PRODUCT_FOUND');
        expect(response.body.data).toBeDefined();
        expect(response.body.data.id).toBe(1);
      } else if (response.status === 404) {
        expect(response.body.success).toBe(false);
        expect(response.body.code).toBe('PRODUCT_NOT_FOUND');
      }
    });

    it('should return 404 for non-existent product', async () => {
      const response = await request(app).get('/api/shop/products/99999');

      expect(response.status).toBe(404);
      expect(response.body.success).toBe(false);
      expect(response.body.code).toBe('PRODUCT_NOT_FOUND');
    });

    it('should parse options as JSON array', async () => {
      const response = await request(app).get('/api/shop/products/1');

      if (response.status === 200) {
        expect(Array.isArray(response.body.data.options)).toBe(true);
      }
    });
  });

  describe('POST /api/shop/orders', () => {
    it('should create order with valid data', async () => {
      const orderData = {
        customer_name: '테스트 고객',
        customer_phone: '010-1234-5678',
        customer_addr: '서울시 강남구',
        memo: '빠른 배송 부탁합니다',
        items: [
          { product_id: 1, quantity: 1 }
        ]
      };

      const response = await request(app)
        .post('/api/shop/orders')
        .send(orderData);

      if (response.status === 201) {
        expect(response.body.success).toBe(true);
        expect(response.body.code).toBe('ORDER_CREATED');
        expect(response.body.data).toHaveProperty('orderId');
        expect(response.body.data).toHaveProperty('orderNumber');
        expect(response.body.data).toHaveProperty('totalPrice');
        expect(response.body.data.status).toBe('pending');
      }
    });

    it('should validate required fields', async () => {
      const response = await request(app)
        .post('/api/shop/orders')
        .send({});

      expect(response.status).toBe(400);
      expect(response.body.success).toBe(false);
      expect(response.body.code).toBe('VALIDATION_ERROR');
      expect(response.body.message).toContain('필수 정보');
    });

    it('should reject missing items array', async () => {
      const response = await request(app)
        .post('/api/shop/orders')
        .send({
          customer_name: '테스트',
          customer_phone: '010-1234-5678',
          customer_addr: '서울'
        });

      expect(response.status).toBe(400);
      expect(response.body.success).toBe(false);
    });

    it('should validate phone number format', async () => {
      const orderData = {
        customer_name: '테스트',
        customer_phone: '123',
        customer_addr: '서울',
        items: [{ product_id: 1, quantity: 1 }]
      };

      const response = await request(app)
        .post('/api/shop/orders')
        .send(orderData);

      // 전화번호 검증이 없으면 201, 있으면 400
      expect([201, 400]).toContain(response.status);
    });
  });

  describe('GET /api/shop/orders/:orderNumber', () => {
    it('should return 404 for non-existent order', async () => {
      const response = await request(app)
        .get('/api/shop/orders/ORD-NONEXISTENT');

      expect(response.status).toBe(404);
      expect(response.body.success).toBe(false);
      expect(response.body.code).toBe('ORDER_NOT_FOUND');
    });

    it('should validate order number format', async () => {
      const response = await request(app).get('/api/shop/orders/');

      // 빈 문자열은 라우팅 되지 않음
      expect([404, 400]).toContain(response.status);
    });
  });

  describe('Error Handling', () => {
    it('should return error response with timestamp', async () => {
      const response = await request(app).get('/api/shop/products/invalid-id');

      expect(response.body).toHaveProperty('timestamp');
    });

    it('should not expose errorId in production mode', async () => {
      const originalEnv = process.env.NODE_ENV;
      process.env.NODE_ENV = 'production';

      const response = await request(app).post('/api/shop/orders').send({});

      if (response.body.errorId !== undefined) {
        // errorId가 있으면 개발 모드에서 온 것
        expect(process.env.NODE_ENV).not.toBe('production');
      }

      process.env.NODE_ENV = originalEnv;
    });
  });
});
