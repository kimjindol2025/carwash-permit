/**
 * 워크플로우 라우트 테스트
 */

const request = require('supertest');
const express = require('express');
const db = require('../../db/init');
const workflowRoutes = require('../../routes/workflowRoutes');

describe('Workflow Routes', () => {
  let app;
  let sessionId;

  beforeAll(() => {
    app = express();
    app.use(express.json());
    app.use('/api/workflow', workflowRoutes);
  });

  describe('POST /api/workflow/start', () => {
    it('should create new workflow session', async () => {
      const response = await request(app).post('/api/workflow/start');

      expect(response.status).toBe(201);
      expect(response.body.success).toBe(true);
      expect(response.body.code).toBe('SESSION_CREATED');
      expect(response.body.data).toHaveProperty('sessionId');
      expect(response.body.data).toHaveProperty('message');
      expect(response.body.data.sessionId).toBeTruthy();

      // Save sessionId for later tests
      sessionId = response.body.data.sessionId;
    });

    it('should return response with proper structure', async () => {
      const response = await request(app).post('/api/workflow/start');

      expect(response.body).toHaveProperty('success');
      expect(response.body).toHaveProperty('code');
      expect(response.body).toHaveProperty('data');
    });

    it('should create persistent session in database', async () => {
      const response = await request(app).post('/api/workflow/start');
      const testSessionId = response.body.data.sessionId;

      // Verify session exists in database
      const session = db.prepare('SELECT * FROM workflow_sessions WHERE session_id = ?').get(testSessionId);
      expect(session).toBeDefined();
      expect(session.status).toBe('active');
      expect(session.current_step).toBe(0);
    });
  });

  describe('GET /api/workflow/:sessionId/status', () => {
    beforeAll(async () => {
      // Create a session first
      const response = await request(app).post('/api/workflow/start');
      sessionId = response.body.data.sessionId;
    });

    it('should return session status with progress', async () => {
      const response = await request(app).get(`/api/workflow/${sessionId}/status`);

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.code).toBe('SESSION_STATUS');
      expect(response.body.data).toHaveProperty('sessionId');
      expect(response.body.data).toHaveProperty('progress');
      expect(response.body.data.progress).toHaveProperty('completed');
      expect(response.body.data.progress).toHaveProperty('total');
      expect(response.body.data.progress).toHaveProperty('percentage');
    });

    it('should contain all 4 steps in response', async () => {
      const response = await request(app).get(`/api/workflow/${sessionId}/status`);

      expect(response.body.data.steps).toHaveLength(4);
      expect(response.body.data.steps[0].step).toBe(1);
      expect(response.body.data.steps[1].step).toBe(2);
      expect(response.body.data.steps[2].step).toBe(3);
      expect(response.body.data.steps[3].step).toBe(4);
    });

    it('should return 404 for non-existent session', async () => {
      const response = await request(app).get('/api/workflow/non-existent-session/status');

      expect(response.status).toBe(404);
      expect(response.body.success).toBe(false);
      expect(response.body.code).toBe('SESSION_NOT_FOUND');
    });

    it('should return 400 for invalid session ID', async () => {
      const response = await request(app).get('/api/workflow//status');

      expect([400, 404]).toContain(response.status);
    });
  });

  describe('POST /api/workflow/:sessionId/step/1', () => {
    beforeAll(async () => {
      const response = await request(app).post('/api/workflow/start');
      sessionId = response.body.data.sessionId;
    });

    it('should complete step 1 with address data', async () => {
      const step1Data = {
        roadAddr: '서울시 강남구 테헤란로 123',
        sigunguCd: '11680',
        bjdongCd: '10100',
        pnu: '1168010100...'
      };

      const response = await request(app)
        .post(`/api/workflow/${sessionId}/step/1`)
        .send(step1Data);

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.code).toBe('STEP1_COMPLETE');
      expect(response.body.data).toHaveProperty('nextStep');
      expect(response.body.data.nextStep).toBe(2);
    });

    it('should validate required fields', async () => {
      const newSessionRes = await request(app).post('/api/workflow/start');
      const newSessionId = newSessionRes.body.data.sessionId;

      const response = await request(app)
        .post(`/api/workflow/${newSessionId}/step/1`)
        .send({});

      expect(response.status).toBe(400);
      expect(response.body.success).toBe(false);
      expect(response.body.code).toBe('VALIDATION_ERROR');
    });

    it('should require both roadAddr and sigunguCd', async () => {
      const newSessionRes = await request(app).post('/api/workflow/start');
      const newSessionId = newSessionRes.body.data.sessionId;

      const response = await request(app)
        .post(`/api/workflow/${newSessionId}/step/1`)
        .send({ roadAddr: '서울시 강남구' });

      expect(response.status).toBe(400);
      expect(response.body.success).toBe(false);
    });

    it('should persist step 1 data in database', async () => {
      const newSessionRes = await request(app).post('/api/workflow/start');
      const newSessionId = newSessionRes.body.data.sessionId;

      const step1Data = {
        roadAddr: '서울시 종로구 삼일대로',
        sigunguCd: '11110',
        bjdongCd: '10100',
        pnu: 'test-pnu'
      };

      await request(app)
        .post(`/api/workflow/${newSessionId}/step/1`)
        .send(step1Data);

      const session = db.prepare('SELECT * FROM workflow_sessions WHERE session_id = ?').get(newSessionId);
      expect(session.step1_completed).toBe(1);
      expect(session.step1_address).toBe(step1Data.roadAddr);
      expect(session.step1_sigungu_cd).toBe(step1Data.sigunguCd);
    });

    it('should return 404 for non-existent session', async () => {
      const response = await request(app)
        .post('/api/workflow/non-existent/step/1')
        .send({ roadAddr: '서울시', sigunguCd: '11680' });

      expect(response.status).toBe(404);
      expect(response.body.success).toBe(false);
      expect(response.body.code).toBe('SESSION_NOT_FOUND');
    });
  });

  describe('POST /api/workflow/:sessionId/step/2', () => {
    beforeAll(async () => {
      const response = await request(app).post('/api/workflow/start');
      sessionId = response.body.data.sessionId;

      // Complete step 1 first
      await request(app)
        .post(`/api/workflow/${sessionId}/step/1`)
        .send({
          roadAddr: '서울시 강남구 테헤란로',
          sigunguCd: '11680',
          bjdongCd: '10100'
        });
    });

    it('should require step 1 to be completed first', async () => {
      const newSessionRes = await request(app).post('/api/workflow/start');
      const newSessionId = newSessionRes.body.data.sessionId;

      const response = await request(app)
        .post(`/api/workflow/${newSessionId}/step/2`)
        .send({});

      expect(response.status).toBe(400);
      expect(response.body.success).toBe(false);
      expect(response.body.code).toBe('STEP1_NOT_COMPLETE');
    });

    it('should complete step 2 successfully', async () => {
      const response = await request(app)
        .post(`/api/workflow/${sessionId}/step/2`)
        .send({ dataSource: 'db' });

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.code).toBe('STEP2_COMPLETE');
    });
  });

  describe('POST /api/workflow/:sessionId/step/3', () => {
    beforeAll(async () => {
      const response = await request(app).post('/api/workflow/start');
      sessionId = response.body.data.sessionId;

      // Complete steps 1 and 2
      await request(app)
        .post(`/api/workflow/${sessionId}/step/1`)
        .send({
          roadAddr: '서울시 강남구 테헤란로',
          sigunguCd: '11680',
          bjdongCd: '10100'
        });

      await request(app)
        .post(`/api/workflow/${sessionId}/step/2`)
        .send({});
    });

    it('should complete step 3 with building query', async () => {
      const response = await request(app)
        .post(`/api/workflow/${sessionId}/step/3/query`)
        .send({});

      expect([200, 201, 400]).toContain(response.status);
      if (response.status === 200 || response.status === 201) {
        expect(response.body.success).toBe(true);
      }
    });

    it('should return building list on step 3', async () => {
      const response = await request(app)
        .post(`/api/workflow/${sessionId}/step/3/query`)
        .send({});

      if (response.status === 200) {
        expect(response.body.data).toBeDefined();
      }
    });
  });

  describe('POST /api/workflow/:sessionId/step/4', () => {
    beforeAll(async () => {
      const response = await request(app).post('/api/workflow/start');
      sessionId = response.body.data.sessionId;

      // Complete all previous steps
      await request(app)
        .post(`/api/workflow/${sessionId}/step/1`)
        .send({
          roadAddr: '서울시 강남구 테헤란로',
          sigunguCd: '11680',
          bjdongCd: '10100'
        });

      await request(app)
        .post(`/api/workflow/${sessionId}/step/2`)
        .send({});

      await request(app)
        .post(`/api/workflow/${sessionId}/step/3/query`)
        .send({});
    });

    it('should complete step 4 permit check', async () => {
      const response = await request(app)
        .post(`/api/workflow/${sessionId}/step/4`)
        .send({});

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.code).toBe('STEP4_COMPLETE');
    });

    it('should return permit decision report', async () => {
      const response = await request(app)
        .post(`/api/workflow/${sessionId}/step/4`)
        .send({});

      if (response.status === 200) {
        expect(response.body.data).toBeDefined();
      }
    });
  });

  describe('Error Handling', () => {
    it('should return error response with timestamp', async () => {
      const response = await request(app).get('/api/workflow/invalid-session/status');

      expect(response.body).toHaveProperty('timestamp');
    });

    it('should return proper error code for invalid operations', async () => {
      const response = await request(app)
        .post('/api/workflow/invalid-session/step/1')
        .send({ roadAddr: '주소' });

      expect([400, 404]).toContain(response.status);
      expect(response.body.success).toBe(false);
    });

    it('should not expose errorId in production mode', async () => {
      const originalEnv = process.env.NODE_ENV;
      process.env.NODE_ENV = 'production';

      const response = await request(app).get('/api/workflow/invalid-session/status');

      if (response.body.errorId !== undefined) {
        expect(process.env.NODE_ENV).not.toBe('production');
      }

      process.env.NODE_ENV = originalEnv;
    });
  });
});
