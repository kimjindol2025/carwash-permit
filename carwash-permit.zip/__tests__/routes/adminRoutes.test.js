/**
 * 관리자 라우트 테스트
 */

const request = require('supertest');
const express = require('express');
const db = require('../../db/init');
const adminRoutes = require('../../routes/adminRoutes');

describe('Admin Routes', () => {
  let app;
  let token;
  let productId;

  beforeAll(() => {
    app = express();
    app.use(express.json());
    app.use('/api/admin', adminRoutes);
  });

  describe('POST /api/admin/login', () => {
    it('should create token with correct password', async () => {
      const response = await request(app)
        .post('/api/admin/login')
        .send({ password: 'test_password' });

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.code).toBe('LOGIN_SUCCESS');
      expect(response.body.data).toHaveProperty('token');
      expect(response.body.data.token).toBeTruthy();

      // Save token for later tests
      token = response.body.data.token;
    });

    it('should reject incorrect password', async () => {
      const response = await request(app)
        .post('/api/admin/login')
        .send({ password: 'wrong_password' });

      expect(response.status).toBe(401);
      expect(response.body.success).toBe(false);
      expect(response.body.code).toBe('INVALID_PASSWORD');
    });

    it('should require password field', async () => {
      const response = await request(app)
        .post('/api/admin/login')
        .send({});

      expect(response.status).toBe(400);
      expect(response.body.success).toBe(false);
      expect(response.body.code).toBe('MISSING_PASSWORD');
    });

    it('should return response with proper structure', async () => {
      const response = await request(app)
        .post('/api/admin/login')
        .send({ password: 'test_password' });

      expect(response.body).toHaveProperty('success');
      expect(response.body).toHaveProperty('code');
      expect(response.body).toHaveProperty('data');
    });
  });

  describe('GET /api/admin/products', () => {
    beforeAll(async () => {
      const loginRes = await request(app)
        .post('/api/admin/login')
        .send({ password: 'test_password' });
      token = loginRes.body.data.token;
    });

    it('should require authentication', async () => {
      const response = await request(app).get('/api/admin/products');

      expect(response.status).toBe(401);
      expect(response.body.success).toBe(false);
    });

    it('should return product list with valid token', async () => {
      const response = await request(app)
        .get('/api/admin/products')
        .set('Authorization', `Bearer ${token}`);

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.code).toBe('PRODUCTS_FOUND');
      expect(Array.isArray(response.body.data)).toBe(true);
    });

    it('should include category information in response', async () => {
      const response = await request(app)
        .get('/api/admin/products')
        .set('Authorization', `Bearer ${token}`);

      if (response.body.data.length > 0) {
        const product = response.body.data[0];
        expect(product).toHaveProperty('id');
        expect(product).toHaveProperty('name');
        expect(product).toHaveProperty('category_name');
      }
    });

    it('should reject invalid token', async () => {
      const response = await request(app)
        .get('/api/admin/products')
        .set('Authorization', 'Bearer invalid-token');

      expect(response.status).toBe(401);
      expect(response.body.success).toBe(false);
    });
  });

  describe('POST /api/admin/products', () => {
    beforeAll(async () => {
      const loginRes = await request(app)
        .post('/api/admin/login')
        .send({ password: 'test_password' });
      token = loginRes.body.data.token;
    });

    it('should create product with valid data', async () => {
      const response = await request(app)
        .post('/api/admin/products')
        .set('Authorization', `Bearer ${token}`)
        .send({
          name: '테스트 상품',
          category_id: 1,
          price: 50000,
          stock: 10,
          description: '테스트 설명'
        });

      if (response.status === 201) {
        expect(response.body.success).toBe(true);
        expect(response.body.code).toBe('PRODUCT_CREATED');
        expect(response.body.data).toHaveProperty('id');

        productId = response.body.data.id;
      }
    });

    it('should validate required fields', async () => {
      const response = await request(app)
        .post('/api/admin/products')
        .set('Authorization', `Bearer ${token}`)
        .send({});

      expect(response.status).toBe(400);
      expect(response.body.success).toBe(false);
      expect(response.body.code).toBe('VALIDATION_ERROR');
    });

    it('should require name and category_id', async () => {
      const response = await request(app)
        .post('/api/admin/products')
        .set('Authorization', `Bearer ${token}`)
        .send({ price: 50000 });

      expect(response.status).toBe(400);
      expect(response.body.success).toBe(false);
    });

    it('should require authentication', async () => {
      const response = await request(app)
        .post('/api/admin/products')
        .send({
          name: '테스트',
          category_id: 1
        });

      expect(response.status).toBe(401);
    });

    it('should save product to database', async () => {
      const response = await request(app)
        .post('/api/admin/products')
        .set('Authorization', `Bearer ${token}`)
        .send({
          name: '데이터베이스 테스트 상품',
          category_id: 1,
          price: 75000,
          stock: 5
        });

      if (response.status === 201) {
        const id = response.body.data.id;
        const product = db.prepare('SELECT * FROM products WHERE id = ?').get(id);
        expect(product).toBeDefined();
        expect(product.name).toBe('데이터베이스 테스트 상품');
        expect(product.price).toBe(75000);
      }
    });
  });

  describe('PUT /api/admin/products/:id', () => {
    let testProductId;

    beforeAll(async () => {
      const loginRes = await request(app)
        .post('/api/admin/login')
        .send({ password: 'test_password' });
      token = loginRes.body.data.token;

      // Create a product to update
      const createRes = await request(app)
        .post('/api/admin/products')
        .set('Authorization', `Bearer ${token}`)
        .send({
          name: '수정될 상품',
          category_id: 1,
          price: 50000,
          stock: 10
        });

      if (createRes.status === 201) {
        testProductId = createRes.body.data.id;
      }
    });

    it('should update product with valid data', async () => {
      if (!testProductId) {
        this.skip();
      }

      const response = await request(app)
        .put(`/api/admin/products/${testProductId}`)
        .set('Authorization', `Bearer ${token}`)
        .send({
          name: '수정된 상품',
          price: 60000
        });

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.code).toBe('PRODUCT_UPDATED');
    });

    it('should validate product ID', async () => {
      const response = await request(app)
        .put('/api/admin/products/invalid-id')
        .set('Authorization', `Bearer ${token}`)
        .send({ name: 'test' });

      expect(response.status).toBe(400);
      expect(response.body.success).toBe(false);
    });

    it('should return 404 for non-existent product', async () => {
      const response = await request(app)
        .put('/api/admin/products/99999')
        .set('Authorization', `Bearer ${token}`)
        .send({ name: 'test' });

      expect(response.status).toBe(404);
      expect(response.body.success).toBe(false);
      expect(response.body.code).toBe('PRODUCT_NOT_FOUND');
    });

    it('should require authentication', async () => {
      const response = await request(app)
        .put(`/api/admin/products/${testProductId}`)
        .send({ name: 'test' });

      expect(response.status).toBe(401);
    });

    it('should persist updates in database', async () => {
      if (!testProductId) {
        this.skip();
      }

      const updateRes = await request(app)
        .put(`/api/admin/products/${testProductId}`)
        .set('Authorization', `Bearer ${token}`)
        .send({
          name: '데이터베이스 수정 테스트',
          price: 88888
        });

      if (updateRes.status === 200) {
        const product = db.prepare('SELECT * FROM products WHERE id = ?').get(testProductId);
        expect(product.name).toBe('데이터베이스 수정 테스트');
        expect(product.price).toBe(88888);
      }
    });
  });

  describe('DELETE /api/admin/products/:id', () => {
    let testProductId;

    beforeAll(async () => {
      const loginRes = await request(app)
        .post('/api/admin/login')
        .send({ password: 'test_password' });
      token = loginRes.body.data.token;

      // Create a product to delete
      const createRes = await request(app)
        .post('/api/admin/products')
        .set('Authorization', `Bearer ${token}`)
        .send({
          name: '삭제될 상품',
          category_id: 1,
          price: 50000,
          stock: 10
        });

      if (createRes.status === 201) {
        testProductId = createRes.body.data.id;
      }
    });

    it('should delete product with valid ID', async () => {
      if (!testProductId) {
        this.skip();
      }

      const response = await request(app)
        .delete(`/api/admin/products/${testProductId}`)
        .set('Authorization', `Bearer ${token}`);

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.code).toBe('PRODUCT_DELETED');
    });

    it('should validate product ID', async () => {
      const response = await request(app)
        .delete('/api/admin/products/invalid-id')
        .set('Authorization', `Bearer ${token}`);

      expect(response.status).toBe(400);
      expect(response.body.success).toBe(false);
    });

    it('should return 404 for non-existent product', async () => {
      const response = await request(app)
        .delete('/api/admin/products/99999')
        .set('Authorization', `Bearer ${token}`);

      expect(response.status).toBe(404);
      expect(response.body.success).toBe(false);
      expect(response.body.code).toBe('PRODUCT_NOT_FOUND');
    });

    it('should require authentication', async () => {
      const response = await request(app)
        .delete('/api/admin/products/1');

      expect(response.status).toBe(401);
    });

    it('should remove product from database', async () => {
      // Create a new product first
      const createRes = await request(app)
        .post('/api/admin/products')
        .set('Authorization', `Bearer ${token}`)
        .send({
          name: '데이터베이스 삭제 테스트',
          category_id: 1,
          price: 50000
        });

      if (createRes.status === 201) {
        const id = createRes.body.data.id;

        // Delete it
        await request(app)
          .delete(`/api/admin/products/${id}`)
          .set('Authorization', `Bearer ${token}`);

        // Verify it's gone
        const product = db.prepare('SELECT * FROM products WHERE id = ?').get(id);
        expect(product).toBeUndefined();
      }
    });
  });

  describe('GET /api/admin/orders', () => {
    beforeAll(async () => {
      const loginRes = await request(app)
        .post('/api/admin/login')
        .send({ password: 'test_password' });
      token = loginRes.body.data.token;
    });

    it('should require authentication', async () => {
      const response = await request(app).get('/api/admin/orders');

      expect(response.status).toBe(401);
    });

    it('should return order list with valid token', async () => {
      const response = await request(app)
        .get('/api/admin/orders')
        .set('Authorization', `Bearer ${token}`);

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.code).toBe('ORDERS_FOUND');
      expect(Array.isArray(response.body.data)).toBe(true);
    });

    it('should support status filtering', async () => {
      const response = await request(app)
        .get('/api/admin/orders?status=pending')
        .set('Authorization', `Bearer ${token}`);

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);

      if (response.body.data.length > 0) {
        response.body.data.forEach(order => {
          expect(order.status).toBe('pending');
        });
      }
    });

    it('should support pagination', async () => {
      const response = await request(app)
        .get('/api/admin/orders?page=1&limit=10')
        .set('Authorization', `Bearer ${token}`);

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
    });

    it('should include order items in response', async () => {
      const response = await request(app)
        .get('/api/admin/orders')
        .set('Authorization', `Bearer ${token}`);

      if (response.body.data.length > 0) {
        const order = response.body.data[0];
        expect(order).toHaveProperty('items');
      }
    });

    it('should reject invalid token', async () => {
      const response = await request(app)
        .get('/api/admin/orders')
        .set('Authorization', 'Bearer invalid-token');

      expect(response.status).toBe(401);
    });
  });

  describe('PATCH /api/admin/orders/:id/status', () => {
    beforeAll(async () => {
      const loginRes = await request(app)
        .post('/api/admin/login')
        .send({ password: 'test_password' });
      token = loginRes.body.data.token;
    });

    it('should update order status', async () => {
      // First get an order
      const ordersRes = await request(app)
        .get('/api/admin/orders')
        .set('Authorization', `Bearer ${token}`);

      if (ordersRes.body.data.length > 0) {
        const orderId = ordersRes.body.data[0].id;

        const response = await request(app)
          .patch(`/api/admin/orders/${orderId}/status`)
          .set('Authorization', `Bearer ${token}`)
          .send({ status: 'confirmed' });

        expect(response.status).toBe(200);
        expect(response.body.success).toBe(true);
        expect(response.body.code).toBe('ORDER_STATUS_UPDATED');
      }
    });

    it('should require authentication', async () => {
      const response = await request(app)
        .patch('/api/admin/orders/1/status')
        .send({ status: 'confirmed' });

      expect(response.status).toBe(401);
    });

    it('should validate status values', async () => {
      const ordersRes = await request(app)
        .get('/api/admin/orders')
        .set('Authorization', `Bearer ${token}`);

      if (ordersRes.body.data.length > 0) {
        const orderId = ordersRes.body.data[0].id;

        const response = await request(app)
          .patch(`/api/admin/orders/${orderId}/status`)
          .set('Authorization', `Bearer ${token}`)
          .send({ status: 'invalid-status' });

        expect([400, 200]).toContain(response.status);
      }
    });

    it('should require status field', async () => {
      const ordersRes = await request(app)
        .get('/api/admin/orders')
        .set('Authorization', `Bearer ${token}`);

      if (ordersRes.body.data.length > 0) {
        const orderId = ordersRes.body.data[0].id;

        const response = await request(app)
          .patch(`/api/admin/orders/${orderId}/status`)
          .set('Authorization', `Bearer ${token}`)
          .send({});

        expect(response.status).toBe(400);
      }
    });
  });

  describe('Error Handling', () => {
    it('should return proper error response format', async () => {
      const response = await request(app)
        .post('/api/admin/login')
        .send({ password: 'wrong' });

      expect(response.body).toHaveProperty('timestamp');
      expect(response.body).toHaveProperty('code');
      expect(response.body).toHaveProperty('success');
    });

    it('should not expose errorId in production mode', async () => {
      const originalEnv = process.env.NODE_ENV;
      process.env.NODE_ENV = 'production';

      const response = await request(app)
        .post('/api/admin/login')
        .send({});

      if (response.body.errorId !== undefined) {
        expect(process.env.NODE_ENV).not.toBe('production');
      }

      process.env.NODE_ENV = originalEnv;
    });
  });
});
