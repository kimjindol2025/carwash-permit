# 🔗 공공 API 실제 연동 가이드

**작성일**: 2026-03-30
**버전**: v1.0
**대상**: 개발자, 구축 담당자

---

## 목차

1. [VWorld API (용도지역)](#1-vworld-api-용도지역)
2. [행안부 도로명주소 API](#2-행안부-도로명주소-api)
3. [국토부 건축물대장 API](#3-국토부-건축물대장-api)
4. [통합 구현 예제](#4-통합-구현-예제)
5. [테스트 및 배포](#5-테스트-및-배포)

---

## 1. VWorld API (용도지역)

### API 개요

```
서비스명: VWorld 토지이용 조회
발급기관: 국토교통부 국토정보 플랫폼
URL: https://www.vworld.kr
발급: 즉시 (무료)
유효기간: 3개월 (자동 갱신)
```

### 1.1 API 키 발급

#### Step 1: VWorld 회원가입
```
1. https://www.vworld.kr/v4dv_intro.do 접속
2. 회원가입 (이메일)
3. 메일 인증
```

#### Step 2: 개발자 등록
```
1. 로그인 후 마이페이지
2. "개발자 등록" 클릭
3. 기본정보 입력
   - 개발자명
   - 조직명 (선택)
   - 개발 목적 (상업, 개인 등)
4. 약관 동의
5. "개발자 등록" 완료
```

#### Step 3: API 키 발급
```
1. 마이페이지 → API 관리
2. "+ 신규 API 키 발급"
3. API 선택:
   ├─ 토지이용
   ├─ 지상 유지보수 (LU_USE)
   └─ 지형도 조회
4. 서비스 목적 기입
5. "발급" 클릭
6. API Key 메모 (이후 .env 저장)

예시 API Key:
```
API_KEY=D1234567890ABCDEF1234567890ABCDEF
```

---

### 1.2 API 요청 명세

#### 토지이용 정보 조회

```bash
# 요청 형식
GET https://api.vworld.kr/ned/data/getLandUse
?service=query
&key=YOUR_API_KEY
&bounds=경계_좌표
&pageUnit=페이지_크기

# 예시 (강남구 역삼동)
GET https://api.vworld.kr/ned/data/getLandUse
?service=query
&key=D1234567890ABCDEF
&bounds=127.02,37.48,127.07,37.52  # (서쪽_경도, 남쪽_위도, 동쪽_경도, 북쪽_위도)
&pageUnit=10

# 응답 형식 (GeoJSON)
{
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[127.03, 37.50], [127.04, 37.50], ...]]
      },
      "properties": {
        "LPC_LC_NM": "상업지역",              // 용도지역명
        "LPC_LC_CLS_NM": "일반상업지역",     // 용도지역분류
        "LPC_LC_CLS_CD": "C1",               // 용도지역 코드
        "JIMOK_NM": "대",                    // 지목명
        "AREA": 1500.25,                     // 면적
        "GID": "12345678"                    // 지물ID
      }
    }
  ]
}
```

#### 좌표 기반 단일 지점 조회 (좋음!)

```bash
# 요청 (권장: 더 정확함)
GET https://api.vworld.kr/ned/data/getLandUse
?service=yard
&key=YOUR_API_KEY
&bounds=127.0,37.5,127.01,37.51  # 작은 경계 지정
&format=json

# 응답 필드 상세
{
  "LPC_LC_NM": "용도지역명",        // 주요!
    "C1": "일반상업지역"
    "R1": "1종일반주거지역"
    "G2": "보전녹지지역"

  "LPC_LC_CLS_CD": "용도지역코드",  // 주요!
    값: "C1", "R2", "I3" 등

  "JIMOK_NM": "지목",               // 부수
    "대": 대지 (건축물 기초)
    "임": 임야 (산림)
    "답": 논
    "전": 밭

  "AREA": 면적,                      // 부수
  "GID": "지물ID",                  // 참고
}
```

---

### 1.3 JavaScript 구현

```javascript
// services/vworld.js

class VWorldService {
  constructor(apiKey) {
    this.apiKey = apiKey;
    this.baseUrl = 'https://api.vworld.kr/ned/data/getLandUse';
  }

  /**
   * 좌표 기반 용도지역 조회
   * @param {number} longitude - 경도 (127.0)
   * @param {number} latitude - 위도 (37.5)
   * @returns {Promise<Object>} 용도지역 정보
   */
  async getZoneByCoordinates(longitude, latitude) {
    try {
      // 정확도를 위해 좁은 경계 설정 (약 1km × 1km)
      const offsetDeg = 0.01; // 약 1km
      const bounds = `${longitude - offsetDeg},${latitude - offsetDeg},${longitude + offsetDeg},${latitude + offsetDeg}`;

      const url = new URL(this.baseUrl);
      url.searchParams.append('service', 'yard');
      url.searchParams.append('key', this.apiKey);
      url.searchParams.append('bounds', bounds);
      url.searchParams.append('format', 'json');

      console.log(`[VWorld] 요청: ${longitude}, ${latitude}`);
      const response = await fetch(url.toString());

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      return this.parseResponse(data);

    } catch (error) {
      console.error('[VWorld] 에러:', error.message);
      throw new Error(`VWorld API 조회 실패: ${error.message}`);
    }
  }

  /**
   * 지번 기반 용도지역 조회 (VWorld는 좌표만 지원)
   * → 행안부 도로명주소 API로 먼저 좌표 변환 필요
   */
  async getZoneByAddress(sigunguCd, bjdongCd) {
    // 시군구코드 + 법정동코드 → 대표 좌표로 변환 필요
    // (별도 매핑 테이블 사용)
    console.warn('[VWorld] 지번 기반 조회는 좌표 변환 필요');
    return null;
  }

  /**
   * VWorld 응답 파싱
   */
  parseResponse(vworldData) {
    try {
      if (!vworldData.features || vworldData.features.length === 0) {
        return {
          zoneCode: 'UNKNOWN',
          zoneType: '미분류',
          jimok: '대',
          area: 0,
          source: 'VWorld'
        };
      }

      // 첫 번째 피처 선택 (가장 관련성 높음)
      const feature = vworldData.features[0];
      const props = feature.properties || {};

      return {
        zoneCode: props.LPC_LC_CLS_CD || 'UNKNOWN',
        zoneType: props.LPC_LC_NM || props.LPC_LC_CLS_NM || '미분류',
        zoneTypeDetailed: props.LPC_LC_CLS_NM || '',
        jimok: props.JIMOK_NM || '대',
        area: props.AREA ? Math.round(props.AREA) : 0,
        gid: props.GID || '',
        source: 'VWorld API'
      };

    } catch (error) {
      console.error('[VWorld] 파싱 에러:', error);
      return {
        zoneCode: 'ERROR',
        zoneType: '오류',
        error: error.message
      };
    }
  }
}

module.exports = VWorldService;
```

---

## 2. 행안부 도로명주소 API

### API 개요

```
서비스명: 도로명주소 조회
발급기관: 행정안전부 (주소정책과)
URL: https://business.juso.go.kr/addrlink/addressBuildDevOpenAPI.do
발급: 신청 즉시 (무료)
```

### 2.1 API 키 발급

#### Step 1: 신청
```
1. https://business.juso.go.kr 접속
2. "Open API" → "신청"
3. 기본정보 입력
4. "신청" 클릭
```

#### Step 2: 승인 및 키 발급
```
1. 이메일 확인 (신청 완료)
2. 마이페이지 → "서비스 관리"
3. "API 키 확인"
4. 키 메모 (.env 저장)

예시:
```
JUSO_KEY=ABC123DEF456GHI789
```

---

### 2.2 API 요청 명세

#### 주소 → 좌표 변환

```bash
# 요청 (도로명주소)
GET https://business.juso.go.kr/addrlink/addrLinkApi.do
?confmKey=YOUR_API_KEY
&resultType=json
&keyword=서울시+강남구+테헤란로+123

# 응답 예시
{
  "results": {
    "common": {
      "totalCount": 1,
      "currentPage": 1,
      "countPerPage": 10
    },
    "juso": [
      {
        "roadAddrPart1": "서울시 강남구 테헤란로 123",  // 도로명주소 (앞부분)
        "roadAddrPart2": "",                           // 도로명주소 (뒷부분)
        "roadAddrPart3": "세차장",                     // 건물명
        "roadAddrPart4": "",
        "roadAddr": "서울시 강남구 테헤란로 123",      // 완전 도로명주소
        "jibunAddr": "강남구 역삼동 123-4",            // 지번주소
        "engAddr": "123 Teheran-ro, Gangnam-gu, Seoul", // 영문주소
        "zipNo": "06234",                              // 우편번호
        "admCd": "11680",                              // 행정구역코드
        "rnMgtSn": "123456789",                        // 도로명 관리번호
        "bdMgtSn": "11680100001020004",               // 건물관리번호
        "detBdNmList": [                               // 상세건물명
          "세차장",
          "주차장"
        ],
        "bdNm": "세차장",                              // 건물명
        "bdKdcd": "0",                                 // 건물용도코드
        "siNm": "서울시",                              // 시도명
        "sggNm": "강남구",                             // 시군구명
        "emdNm": "역삼동",                             // 읍면동명
        "liNm": "",                                    // 리명
        "rn": "테헤란로",                              // 도로명
        "udrtYn": "0",                                 // 지하/지상 (0=지상)
        "buldMnnm": "123",                             // 건물번호 (본번)
        "buldSlno": "0",                               // 건물번호 (부번)
        "mtYn": "0",                                   // 산 여부 (0=아님)
        "lnbrCd": "00",                                // 법정리번호
        "lnbrNm": "",                                  // 법정리명
        "emdGubnCd": "1",                              // 행정구분 (1=동)
        "liDeNm": "",
        "ldCode": "11680-10100",                       // 토지코드
        "hemdCode": "11680-10100",                     // 법정동코드
        "newPlatPlc": "서울시 강남구 역삼동",         // 새로운 인구통계 동
        "lat": "37.499119",                            // 위도 ← 중요!
        "lng": "127.026305",                           // 경도 ← 중요!
        "hname": "세차장",
        "result": "00"                                 // 결과 (00=성공)
      }
    ]
  }
}
```

---

### 2.3 JavaScript 구현

```javascript
// services/juso.js

class JusoService {
  constructor(apiKey) {
    this.apiKey = apiKey;
    this.baseUrl = 'https://business.juso.go.kr/addrlink/addrLinkApi.do';
  }

  /**
   * 주소 검색 (자동완성 목록)
   * @param {string} keyword - 검색어 (예: "강남구 테헤란로")
   * @returns {Promise<Array>} 검색 결과 목록
   */
  async searchAddress(keyword) {
    try {
      const params = new URLSearchParams({
        confmKey: this.apiKey,
        resultType: 'json',
        keyword: keyword,
        countPerPage: 10
      });

      const url = `${this.baseUrl}?${params.toString()}`;
      console.log(`[Juso] 검색: ${keyword}`);

      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const data = await response.json();
      return this.parseSearchResults(data);

    } catch (error) {
      console.error('[Juso] 에러:', error.message);
      return [];
    }
  }

  /**
   * 검색 결과 파싱
   */
  parseSearchResults(data) {
    try {
      if (!data.results || !data.results.juso) {
        return [];
      }

      return data.results.juso.map(item => ({
        roadAddr: item.roadAddr,           // 도로명주소
        jibunAddr: item.jibunAddr,         // 지번주소
        zipNo: item.zipNo,                 // 우편번호
        sigunguCd: item.admCd,             // 시군구코드
        bjdongCd: item.hemdCode,           // 법정동코드
        bdMgtSn: item.bdMgtSn,             // 건물관리번호
        bdNm: item.bdNm,                   // 건물명
        lat: parseFloat(item.lat),         // 위도
        lng: parseFloat(item.lng),         // 경도
        siNm: item.siNm,                   // 시도명
        sggNm: item.sggNm,                 // 시군구명
        emdNm: item.emdNm,                 // 읍면동명
        rn: item.rn                        // 도로명
      }));

    } catch (error) {
      console.error('[Juso] 파싱 에러:', error);
      return [];
    }
  }

  /**
   * 건물 정보 추출 (위도/경도 포함)
   */
  extractBuildingInfo(jusoItem) {
    return {
      address: jusoItem.roadAddr,
      jibunAddress: jusoItem.jibunAddr,
      zipCode: jusoItem.zipNo,
      sigunguCode: jusoItem.sigunguCd,
      bjdongCode: jusoItem.bjdongCd,
      buildingName: jusoItem.bdNm,
      latitude: jusoItem.lat,
      longitude: jusoItem.lng,
      city: jusoItem.siNm,
      district: jusoItem.sggNm,
      dong: jusoItem.emdNm,
      road: jusoItem.rn
    };
  }
}

module.exports = JusoService;
```

---

## 3. 국토부 건축물대장 API

### API 개요

```
서비스명: 건축물대장 조회
발급기관: 국토교통부 (건축지원과)
URL: https://www.data.go.kr/data/15134735/openapi.do
발급: 1~2일 소요
비용: 무료
```

### 3.1 API 키 발급

#### Step 1: data.go.kr 가입
```
1. https://www.data.go.kr 접속
2. 회원가입 (기관/개인 선택)
3. 이메일 인증
```

#### Step 2: 신청
```
1. "OpenAPI 활용신청" 검색
2. 건축물대장 API 찾기
3. "신청" 버튼
4. 신청 정보 입력
```

#### Step 3: 승인
```
1. 이메일 확인 (신청 완료 안내)
2. 마이페이지 → "신청내역"
3. "승인" 확인 (보통 1일 이내)
4. API 키 메모

예시:
```
DATA_API_KEY=ABC123DEF456GHI789
```

---

### 3.2 API 요청 명세

#### 건물 기본정보 조회

```bash
# 요청 (건물관리번호 기반)
GET http://openapi.data.go.kr/openapi/service/rest/Building3/getBrBasisOld
?ServiceKey=YOUR_API_KEY
&bldMgtSn=건물관리번호
&resultType=json

# 예시
GET http://openapi.data.go.kr/openapi/service/rest/Building3/getBrBasisOld
?ServiceKey=ABC123DEF456
&bldMgtSn=11680100001020004
&resultType=json

# 응답 예시
{
  "response": {
    "header": {
      "resultCode": "00",                    // 00=성공
      "resultMsg": "NORMAL SERVICE."
    },
    "body": {
      "items": {
        "item": [
          {
            "bldNm": "세차장",                // 건물명
            "bldrgstSeq": "1",                // 건물등록일련번호
            "engBldNm": "Car Wash",           // 영문명
            "bldUsr": "세차장",               // 건물용도
            "bldArea": "500.25",              // 건물면적 (㎡)
            "mainBldCd": "1",                 // 주건물 코드
            "mainPurpsCd": "10110",           // 주용도 코드
            "mainPurpsNm": "일반세차",        // 주용도명
            "spec": "지상 1층",               // 구조
            "useAprDay": "20200101",          // 사용승인일
            "newBldCd": "0",                  // 신축 여부
            "bldSeq": "1",
            "bldGrade": "1",
            "tstdArea": "500.25",             // 대지면적 (㎡)
            "parea": "500.25",
            "sarea": "500.25",
            "grndFlrArea": "500.25",          // 1층 면적
            "basement": "0",                  // 지하층 수
            "grndFlr": "1",                   // 지상층 수
            "bdKdcd": "1",                    // 건물 분류코드
          }
        ]
      }
    }
  }
}
```

#### 건물 용도 상세 조회

```bash
# 요청 (건물관리번호)
GET http://openapi.data.go.kr/openapi/service/rest/Building3/getBrExtsns
?ServiceKey=YOUR_API_KEY
&bldMgtSn=11680100001020004
&resultType=json

# 응답 필드
{
  "item": {
    "bldNm": "건물명",
    "mainPurpsNm": "용도",         // "세차장", "주유소" 등
    "mainPurpsCd": "코드",         // 10110, 12220 등
    "subPurpsNm": "부용도",
    "bldGrade": "건물 등급",
    "emdNm": "읍면동",
    "pnuCd": "PNU 코드",           // 지번코드
    "lat": "37.5",                 // 위도
    "lon": "127.0"                 // 경도
  }
}
```

---

### 3.3 JavaScript 구현

```javascript
// services/building-api.js

class BuildingAPIService {
  constructor(apiKey) {
    this.apiKey = apiKey;
    this.baseUrl = 'http://openapi.data.go.kr/openapi/service/rest/Building3';
  }

  /**
   * 건물 기본정보 조회 (건물관리번호 기반)
   * @param {string} bdMgtSn - 건물관리번호
   * @returns {Promise<Object>} 건물정보
   */
  async getBuildingInfo(bdMgtSn) {
    try {
      const url = `${this.baseUrl}/getBrBasisOld?ServiceKey=${this.apiKey}&bldMgtSn=${bdMgtSn}&resultType=json`;

      console.log(`[BuildingAPI] 조회: ${bdMgtSn}`);
      const response = await fetch(url);

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const data = await response.json();
      return this.parseResponse(data);

    } catch (error) {
      console.error('[BuildingAPI] 에러:', error.message);
      return null;
    }
  }

  /**
   * 건물 용도 상세 조회
   * @param {string} bdMgtSn - 건물관리번호
   * @returns {Promise<Object>} 건물 용도정보
   */
  async getBuildingUsage(bdMgtSn) {
    try {
      const url = `${this.baseUrl}/getBrExtsns?ServiceKey=${this.apiKey}&bldMgtSn=${bdMgtSn}&resultType=json`;

      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const data = await response.json();
      return this.parseUsageResponse(data);

    } catch (error) {
      console.error('[BuildingAPI] 용도 조회 에러:', error);
      return null;
    }
  }

  /**
   * 응답 파싱
   */
  parseResponse(data) {
    try {
      const resultCode = data?.response?.header?.resultCode;

      // API 오류 확인
      if (resultCode !== '00') {
        console.warn(`[BuildingAPI] 결과 코드: ${resultCode}`);
        return null;
      }

      const item = data?.response?.body?.items?.item?.[0];
      if (!item) {
        return null;
      }

      return {
        buildingName: item.bldNm,
        usage: item.bldUsr || item.mainPurpsNm,
        usageCode: item.mainPurpsCd,
        buildingArea: parseFloat(item.bldArea),
        landArea: parseFloat(item.tstdArea),
        floors: {
          ground: parseInt(item.grndFlr) || 1,
          basement: parseInt(item.basement) || 0
        },
        groundFloorArea: parseFloat(item.grndFlrArea),
        useApprovalDate: item.useAprDay,
        structure: item.spec,
        source: 'Building API'
      };

    } catch (error) {
      console.error('[BuildingAPI] 파싱 에러:', error);
      return null;
    }
  }

  /**
   * 용도 응답 파싱
   */
  parseUsageResponse(data) {
    try {
      const item = data?.response?.body?.items?.item?.[0];
      if (!item) {
        return null;
      }

      return {
        mainUsage: item.mainPurpsNm,
        mainUsageCode: item.mainPurpsCd,
        subUsage: item.subPurpsNm,
        latitude: parseFloat(item.lat),
        longitude: parseFloat(item.lon),
        pnuCode: item.pnuCd
      };

    } catch (error) {
      console.error('[BuildingAPI] 용도 파싱 에러:', error);
      return null;
    }
  }
}

module.exports = BuildingAPIService;
```

---

## 4. 통합 구현 예제

### Express 라우트 통합

```javascript
// routes/api.js

const express = require('express');
const VWorldService = require('../services/vworld');
const JusoService = require('../services/juso');
const BuildingAPIService = require('../services/building-api');

const router = express.Router();

// 서비스 인스턴스
const vworld = new VWorldService(process.env.VWORLD_KEY);
const juso = new JusoService(process.env.JUSO_KEY);
const buildingAPI = new BuildingAPIService(process.env.DATA_API_KEY);

/**
 * GET /api/address/search
 * 주소 검색
 */
router.get('/api/address/search', async (req, res) => {
  try {
    const { query } = req.query;

    if (!query || query.trim() === '') {
      return res.status(400).json({ error: '검색어 필수' });
    }

    const results = await juso.searchAddress(query);

    return res.json({
      query,
      count: results.length,
      results: results.slice(0, 10) // 상위 10개
    });

  } catch (error) {
    console.error('[API] 주소 검색 에러:', error);
    return res.status(500).json({ error: error.message });
  }
});

/**
 * GET /api/zone/check
 * 용도지역 조회 (좌표 기반)
 */
router.get('/api/zone/check', async (req, res) => {
  try {
    const { lat, lng } = req.query;

    if (!lat || !lng) {
      return res.status(400).json({
        error: '위도/경도 필수',
        example: '?lat=37.5&lng=127.0'
      });
    }

    const zoneInfo = await vworld.getZoneByCoordinates(
      parseFloat(lng),
      parseFloat(lat)
    );

    if (!zoneInfo) {
      return res.status(404).json({ error: '용도지역 정보 없음' });
    }

    return res.json(zoneInfo);

  } catch (error) {
    console.error('[API] 용도지역 조회 에러:', error);
    return res.status(500).json({ error: error.message });
  }
});

/**
 * POST /api/location/full-check
 * 통합 조회 (주소 → 좌표 → 용도지역 → 건물정보)
 */
router.post('/api/location/full-check', async (req, res) => {
  try {
    const { address } = req.body;

    if (!address) {
      return res.status(400).json({ error: '주소 필수' });
    }

    console.log(`[Full Check] 주소: ${address}`);

    // 1단계: 주소 검색
    const addressResults = await juso.searchAddress(address);
    if (!addressResults || addressResults.length === 0) {
      return res.status(404).json({
        error: '주소를 찾을 수 없습니다.',
        address: address
      });
    }

    const selectedAddr = addressResults[0];
    console.log(`[Full Check] 선택된 주소: ${selectedAddr.roadAddr}`);

    // 2단계: 용도지역 조회
    const zoneInfo = await vworld.getZoneByCoordinates(
      selectedAddr.lng,
      selectedAddr.lat
    );

    // 3단계: 건물정보 조회
    let buildingInfo = null;
    if (selectedAddr.bdMgtSn) {
      buildingInfo = await buildingAPI.getBuildingInfo(selectedAddr.bdMgtSn);
    }

    return res.json({
      address: selectedAddr,
      zone: zoneInfo,
      building: buildingInfo
    });

  } catch (error) {
    console.error('[Full Check] 에러:', error);
    return res.status(500).json({ error: error.message });
  }
});

module.exports = router;
```

---

## 5. 테스트 및 배포

### 5.1 로컬 테스트

```bash
# .env 파일 설정
VWORLD_KEY=your_vworld_key
JUSO_KEY=your_juso_key
DATA_API_KEY=your_data_api_key
USE_MOCK=false

# 서버 시작
npm start

# curl 테스트
curl "http://localhost:35000/api/address/search?query=강남구+테헤란로"

curl "http://localhost:35000/api/zone/check?lat=37.5&lng=127.0"

curl -X POST http://localhost:35000/api/location/full-check \
  -H "Content-Type: application/json" \
  -d '{"address":"서울시 강남구 테헤란로 123"}'
```

### 5.2 프로덕션 배포

```bash
# .env.production 파일 생성
USE_MOCK=false
VWORLD_KEY=prod_vworld_key
JUSO_KEY=prod_juso_key
DATA_API_KEY=prod_data_api_key

# 환경변수 적용
export NODE_ENV=production
source .env.production

# 배포
npm start --env production
```

---

## 참고: API 비교표

| API | 용도 | 발급기간 | 비용 | 정확도 |
|-----|------|---------|------|--------|
| VWorld | 용도지역 | 즉시 | 무료 | 높음 |
| Juso | 주소→좌표 | 즉시 | 무료 | 높음 |
| Building API | 건물정보 | 1~2일 | 무료 | 중간 |

---

**작성**: Kim's Carwash Permit Project
**최종 검수**: 2026-03-30

