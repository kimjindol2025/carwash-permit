# 📋 API 응답 표준 사양 (v1.0)

## 개요
모든 API 응답은 통일된 JSON 형식을 따릅니다.

---

## 1️⃣ 성공 응답 (200-201)

### 기본 구조
```json
{
  "success": true,
  "code": "OPERATION_CODE",
  "data": { /* 응답 데이터 */ },
  "timestamp": "2026-04-01T12:00:00.000Z"
}
```

### 필드 설명
| 필드 | 타입 | 필수 | 설명 |
|------|------|------|------|
| `success` | boolean | ✅ | 요청 성공 여부 (항상 true) |
| `code` | string | ✅ | 작업 코드 (예: PRODUCT_CREATED, ORDER_FOUND) |
| `data` | object/array | ✅ | 응답 데이터 |
| `timestamp` | string | ⚠️ | ISO 8601 타임스탬프 (선택사항) |

### 예제

#### GET /api/shop/categories
```json
{
  "success": true,
  "code": "CATEGORIES_FOUND",
  "data": [
    { "id": 1, "name": "장비", "slug": "equipment" },
    { "id": 2, "name": "서비스", "slug": "service" }
  ]
}
```

#### POST /api/shop/orders
```json
{
  "success": true,
  "code": "ORDER_CREATED",
  "data": {
    "orderId": 123,
    "orderNumber": "ORD-20260401-0001",
    "totalPrice": 1000000,
    "status": "pending"
  }
}
```

---

## 2️⃣ 에러 응답 (4xx, 5xx)

### 기본 구조
```json
{
  "success": false,
  "code": "ERROR_CODE",
  "message": "사용자 친화적 메시지",
  "errorId": "ERR-XXXXYYYY",
  "timestamp": "2026-04-01T12:00:00.000Z"
}
```

### 필드 설명
| 필드 | 타입 | 필수 | 설명 |
|------|------|------|------|
| `success` | boolean | ✅ | 요청 성공 여부 (항상 false) |
| `code` | string | ✅ | 에러 코드 (예: VALIDATION_ERROR) |
| `message` | string | ✅ | 사용자 친화적 에러 메시지 |
| `errorId` | string | ⚠️ | 에러 추적 ID (개발 모드에서만 반환) |
| `timestamp` | string | ✅ | ISO 8601 타임스탐프 |

### 예제

#### 유효성 검사 실패 (400)
```json
{
  "success": false,
  "code": "VALIDATION_ERROR",
  "message": "필수 정보가 부족합니다 (이름, 전화, 주소, 상품)",
  "timestamp": "2026-04-01T12:00:00.000Z"
}
```

#### 인증 실패 (401)
```json
{
  "success": false,
  "code": "INVALID_PASSWORD",
  "message": "패스워드가 틀렸습니다",
  "timestamp": "2026-04-01T12:00:00.000Z"
}
```

#### 리소스 없음 (404)
```json
{
  "success": false,
  "code": "PRODUCT_NOT_FOUND",
  "message": "상품을 찾을 수 없습니다",
  "timestamp": "2026-04-01T12:00:00.000Z"
}
```

#### 서버 에러 (500, 개발 모드)
```json
{
  "success": false,
  "code": "PRODUCT_LIST_ERROR",
  "message": "상품 목록 조회에 실패했습니다",
  "errorId": "ERR-A1B2C3D4",
  "timestamp": "2026-04-01T12:00:00.000Z"
}
```

---

## 3️⃣ 응답 코드 목록

### 카테고리 & 상품
| 코드 | HTTP | 설명 |
|------|------|------|
| CATEGORIES_FOUND | 200 | 카테고리 목록 조회 성공 |
| PRODUCTS_FOUND | 200 | 상품 목록 조회 성공 |
| PRODUCT_FOUND | 200 | 상품 상세 조회 성공 |
| PRODUCT_CREATED | 201 | 상품 생성 성공 |
| PRODUCT_UPDATED | 200 | 상품 수정 성공 |
| PRODUCT_DELETED | 200 | 상품 삭제 성공 |
| PRODUCT_NOT_FOUND | 404 | 상품을 찾을 수 없음 |
| PRODUCT_LIST_ERROR | 500 | 상품 목록 조회 실패 |
| PRODUCT_CREATE_ERROR | 500 | 상품 생성 실패 |
| PRODUCT_UPDATE_ERROR | 500 | 상품 수정 실패 |
| PRODUCT_DELETE_ERROR | 500 | 상품 삭제 실패 |

### 주문
| 코드 | HTTP | 설명 |
|------|------|------|
| ORDER_CREATED | 201 | 주문 생성 성공 |
| ORDER_FOUND | 200 | 주문 조회 성공 |
| ORDER_STATUS_UPDATED | 200 | 주문 상태 변경 성공 |
| ORDER_NOT_FOUND | 404 | 주문을 찾을 수 없음 |
| VALIDATION_ERROR | 400 | 필수 정보 부족 |
| INVALID_ITEM | 400 | 잘못된 상품 정보 |
| ORDER_CREATE_ERROR | 500 | 주문 생성 실패 |
| ORDER_LIST_ERROR | 500 | 주문 목록 조회 실패 |
| ORDER_FETCH_ERROR | 500 | 주문 조회 실패 |
| ORDER_STATUS_ERROR | 500 | 주문 상태 변경 실패 |

### 워크플로우
| 코드 | HTTP | 설명 |
|------|------|------|
| SESSION_CREATED | 201 | 세션 생성 성공 |
| SESSION_STATUS | 200 | 세션 상태 조회 성공 |
| STEP1_COMPLETE | 200 | Step 1 완료 |
| STEP2_COMPLETE | 200 | Step 2 완료 |
| STEP3_COMPLETE | 200 | Step 3 완료 |
| STEP4_COMPLETE | 200 | Step 4 완료 |
| REPORT_FOUND | 200 | 리포트 조회 성공 |
| SESSION_DELETED | 200 | 세션 삭제 성공 |
| SESSION_NOT_FOUND | 404 | 세션을 찾을 수 없음 |
| STEP1_NOT_COMPLETE | 400 | Step 1을 먼저 완료하세요 |
| INVALID_SESSION_ID | 400 | 유효하지 않은 세션 ID |
| REPORT_NOT_READY | 400 | 리포트가 아직 생성되지 않음 |
| SESSION_CREATE_ERROR | 500 | 세션 생성 실패 |
| SESSION_STATUS_ERROR | 500 | 세션 상태 조회 실패 |
| STEP1_ERROR ~ STEP4_ERROR | 500 | 각 단계 처리 실패 |
| REPORT_FETCH_ERROR | 500 | 리포트 조회 실패 |
| SESSION_DELETE_ERROR | 500 | 세션 삭제 실패 |

### 어드민
| 코드 | HTTP | 설명 |
|------|------|------|
| LOGIN_SUCCESS | 200 | 로그인 성공 |
| MISSING_PASSWORD | 400 | 패스워드 필수 |
| INVALID_PASSWORD | 401 | 패스워드 틀림 |
| LOGIN_ERROR | 500 | 로그인 실패 |

---

## 4️⃣ HTTP 상태 코드 규칙

| 상태 | 사용 경우 |
|------|----------|
| **200** | 요청 성공, 결과 반환 (GET, PATCH) |
| **201** | 리소스 생성 성공 (POST) |
| **400** | 유효성 검사 실패, 필수 필드 누락 |
| **401** | 인증 실패 (토큰 없음, 패스워드 틀림) |
| **404** | 리소스 없음 |
| **500** | 서버 에러 |

---

## 5️⃣ 클라이언트 처리 가이드

### JavaScript/Fetch
```javascript
// 성공 처리
fetch('/api/shop/products')
  .then(res => res.json())
  .then(data => {
    if (data.success) {
      console.log('응답 코드:', data.code);
      console.log('응답 데이터:', data.data);
    }
  });

// 에러 처리
  .catch(err => {
    if (!response.ok) {
      const error = await response.json();
      console.error('에러:', error.code);
      console.error('메시지:', error.message);
      if (error.errorId) {
        console.error('추적 ID:', error.errorId);
      }
    }
  });
```

---

## 6️⃣ 응답 타입 (TypeScript)

```typescript
// 성공 응답
interface SuccessResponse<T> {
  success: true;
  code: string;
  data: T;
  timestamp?: string;
}

// 에러 응답
interface ErrorResponse {
  success: false;
  code: string;
  message: string;
  errorId?: string;  // 개발 모드에서만
  timestamp: string;
}

// 통합 응답
type ApiResponse<T> = SuccessResponse<T> | ErrorResponse;
```

---

**버전**: v1.0
**최종 업데이트**: 2026-04-01
**상태**: ✅ 표준화 완료
