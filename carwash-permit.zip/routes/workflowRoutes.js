const express = require('express');
const crypto = require('crypto');
const path = require('path');
const Database = require('better-sqlite3');

const db = require('../db/init');
const { regulationsDb } = require('../db/init');
const Logger = require('../utils/logger');

// 건축물 정보 DB (init.db)
const buildingsDb = new Database(path.join(__dirname, '../db/init.db'), { readonly: false });

const router = express.Router();
const USE_MOCK = process.env.USE_MOCK === 'true';
const logger = new Logger('workflowRoutes');

// ✅ P1-2: 에러 응답 표준화
function errorResponse(res, statusCode, code, message, errorId = null) {
  res.status(statusCode).json({
    success: false,
    code,
    message,
    errorId: process.env.NODE_ENV === 'development' ? errorId : undefined,
    timestamp: new Date().toISOString()
  });
}

// ⭐ P1-3: 로그 배치 처리 (5초마다 일괄 저장, DB I/O 95% 절감)
const logQueue = [];
let batchCount = 0;

const processBatch = () => {
  if (logQueue.length > 0) {
    try {
      const insertStmt = db.prepare(`
        INSERT INTO workflow_search_logs
        (session_id, step, search_type, search_query, search_result, ip_address, user_agent, referer, device_type, status_code, error_msg, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now','localtime'))
      `);

      const queueSize = logQueue.length;
      db.exec('BEGIN TRANSACTION');

      logQueue.forEach(log => {
        insertStmt.run(
          log.sessionId || '',
          log.step || 0,
          log.searchType || 'unknown',
          log.query ? JSON.stringify(log.query) : null,
          log.result ? JSON.stringify(log.result) : null,
          log.ipAddress || 'unknown',
          log.userAgent || '',
          log.referer || null,
          log.deviceType,
          log.statusCode,
          log.errorMsg || null
        );
      });

      db.exec('COMMIT');
      batchCount++;
      console.log(`✅ 배치 ${batchCount}: ${queueSize}개 로그 저장 완료`);
      logQueue.length = 0; // 큐 비우기
    } catch (err) {
      console.error('❌ 배치 로그 처리 실패:', err.message);
    }
  }
};

// 5초마다 배치 처리
setInterval(processBatch, 5000);

// ===== 검색 로그 유틸리티 =====
function logSearch(req, sessionId, step, searchType, query, result, statusCode = 200, errorMsg = null) {
  try {
    // User-Agent 분석 (모바일/태블릿/데스크톱)
    const userAgent = req.get('user-agent') || '';
    let deviceType = 'desktop';
    if (/mobile|android|iphone|ipad|phone/i.test(userAgent)) {
      deviceType = /tablet|ipad/i.test(userAgent) ? 'tablet' : 'mobile';
    }

    // ⭐ P1-3: 큐에 추가 (즉시 DB 저장 안 함, 5초마다 배치 처리)
    logQueue.push({
      sessionId,
      step,
      searchType,
      query,
      result,
      ipAddress: req.ip || req.connection.remoteAddress,
      userAgent,
      referer: req.get('referer'),
      deviceType,
      statusCode,
      errorMsg
    });
  } catch (err) {
    console.warn('로그 큐 추가 실패:', err.message);
  }
}

// ============ 워크플로우 세션 관리 ============

// POST /api/workflow/start - 새 워크플로우 시작
router.post('/start', (req, res) => {
  try {
    const sessionId = crypto.randomBytes(16).toString('hex');
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(); // 24시간 유효

    db.prepare(`
      INSERT INTO workflow_sessions
      (session_id, current_step, status, expires_at)
      VALUES (?, 0, 'active', ?)
    `).run(sessionId, expiresAt);

    res.status(201).json({
      success: true,
      code: 'SESSION_CREATED',
      data: {
        sessionId: sessionId,
        message: '워크플로우 시작. 지번 검색으로 진행하세요.'
      }
    });
  } catch (err) {
    const errorId = logger.logError('워크플로우 시작 실패', err);
    errorResponse(res, 500, 'SESSION_CREATE_ERROR', '워크플로우 시작에 실패했습니다', errorId);
  }
});

// GET /api/workflow/:sessionId/status - 진행 상황 확인
router.get('/:sessionId/status', (req, res) => {
  try {
    const { sessionId } = req.params;

    // ✅ P1-2: 파라미터 검증
    if (!sessionId || typeof sessionId !== 'string') {
      return errorResponse(res, 400, 'INVALID_SESSION_ID', '유효한 세션 ID가 필요합니다');
    }

    const session = db.prepare(`
      SELECT
        session_id, current_step, status,
        step1_completed, step2_completed, step3_completed, step4_completed,
        step1_address, step2_zone_type, step3_building_nm, step4_result,
        created_at, updated_at
      FROM workflow_sessions
      WHERE session_id = ?
    `).get(sessionId);

    if (!session) {
      return errorResponse(res, 404, 'SESSION_NOT_FOUND', '세션을 찾을 수 없습니다');
    }

    // 진행도 계산
    const completedSteps = [
      session.step1_completed,
      session.step2_completed,
      session.step3_completed,
      session.step4_completed
    ].filter(s => s === 1).length;

    res.json({
      success: true,
      code: 'SESSION_STATUS',
      data: {
        sessionId: session.session_id,
        currentStep: session.current_step,
        status: session.status,
        progress: {
          completed: completedSteps,
          total: 4,
          percentage: Math.round((completedSteps / 4) * 100)
        },
        steps: [
          {
            step: 1,
            name: '지번 검색',
            completed: session.step1_completed === 1,
            data: session.step1_address ? { address: session.step1_address } : null
          },
          {
            step: 2,
            name: '토지이용 확인',
            completed: session.step2_completed === 1,
            data: session.step2_zone_type ? { zoneType: session.step2_zone_type } : null
          },
          {
            step: 3,
            name: '건축물 확인',
            completed: session.step3_completed === 1,
            data: session.step3_building_nm ? { building: session.step3_building_nm } : null
          },
          {
            step: 4,
            name: '허가 체크',
            completed: session.step4_completed === 1,
            data: session.step4_result ? { result: session.step4_result } : null
          }
        ]
      }
    });
  } catch (err) {
    const errorId = `ERR-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
    console.error(`[${errorId}] 세션 상태 조회 실패:`, err.stack);
    errorResponse(res, 500, 'SESSION_STATUS_ERROR', '세션 상태 조회에 실패했습니다', errorId);
  }
});

// ============ 워크플로우 단계별 API ============

// POST /api/workflow/:sessionId/step/1 - 1단계: 지번 검색 및 저장
router.post('/:sessionId/step/1', (req, res) => {
  try {
    const { sessionId } = req.params;
    const { roadAddr, sigunguCd, bjdongCd, pnu } = req.body;

    // ✅ P1-2: 파라미터 검증
    if (!sessionId || typeof sessionId !== 'string') {
      return errorResponse(res, 400, 'INVALID_SESSION_ID', '유효한 세션 ID가 필요합니다');
    }

    if (!roadAddr || !sigunguCd) {
      return errorResponse(res, 400, 'VALIDATION_ERROR', '주소(roadAddr)와 시군구 코드(sigunguCd)가 필수입니다');
    }

    // 세션 확인
    const session = db.prepare('SELECT id FROM workflow_sessions WHERE session_id = ?').get(sessionId);
    if (!session) {
      return errorResponse(res, 404, 'SESSION_NOT_FOUND', '세션을 찾을 수 없습니다');
    }

    // Step 1 데이터 저장
    db.prepare(`
      UPDATE workflow_sessions
      SET
        step1_address = ?,
        step1_sigungu_cd = ?,
        step1_bjdong_cd = ?,
        step1_pnu = ?,
        step1_completed = 1,
        current_step = 1,
        updated_at = datetime('now','localtime')
      WHERE session_id = ?
    `).run(roadAddr, sigunguCd, bjdongCd, pnu || '', sessionId);

    // 검색 로그 저장
    logSearch(req, sessionId, 1, 'address', { roadAddr, sigunguCd }, { roadAddr, sigunguCd });

    res.status(200).json({
      success: true,
      code: 'STEP1_COMPLETE',
      data: {
        message: '1단계 완료: 주소가 저장되었습니다',
        nextStep: 2,
        instruction: '토지이용 확인으로 진행하세요'
      }
    });
  } catch (err) {
    const errorId = `ERR-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
    console.error(`[${errorId}] Step 1 처리 실패:`, err.stack);
    errorResponse(res, 500, 'STEP1_ERROR', 'Step 1 처리에 실패했습니다', errorId);
  }
});

// POST /api/workflow/:sessionId/step/2 - 2단계: 토지이용 확인 (WMS API - 지도 이미지)
router.post('/:sessionId/step/2', async (req, res) => {
  try {
    const { sessionId } = req.params;
    const { bbox, dataSource } = req.body; // dataSource = 'db' 또는 'api'

    // ✅ P1-2: 파라미터 검증
    if (!sessionId || typeof sessionId !== 'string') {
      return errorResponse(res, 400, 'INVALID_SESSION_ID', '유효한 세션 ID가 필요합니다');
    }

    // 세션에서 Step1 데이터 확인
    const session = db.prepare(`
      SELECT step1_sigungu_cd, step1_address, step1_pnu FROM workflow_sessions WHERE session_id = ?
    `).get(sessionId);

    if (!session || !session.step1_sigungu_cd) {
      return errorResponse(res, 400, 'STEP1_NOT_COMPLETE', '먼저 1단계(지번 검색)를 완료하세요');
    }

    // 지도 범위 (bbox) 결정: 사용자 지정 또는 기본값
    let mapBbox = bbox || getDefaultBbox(session.step1_sigungu_cd);

    // 용도지역 코드 → 한글명 매핑
    const zoneCodeMap = {
      'URR100': '주거지역', 'URR110': '전용주거지역', 'URR120': '1종일반주거지역',
      'URR130': '2종일반주거지역', 'URR140': '3종일반주거지역', 'URR150': '준주거지역',
      'UCO100': '상업지역', 'UCO110': '중심상업지역', 'UCO120': '일반상업지역',
      'UCO130': '근린상업지역', 'UCO140': '유통상업지역',
      'UIO100': '공업지역', 'UIO110': '전용공업지역', 'UIO120': '일반공업지역', 'UIO130': '준공업지역',
      'UGR100': '관리지역', 'UGR110': '보전관리지역', 'UGR120': '생산관리지역', 'UGR130': '계획관리지역',
      'UNZ100': '자연지역', 'UNZ110': '자연보전지역', 'UNZ120': '자연휴양지역',
      'UQA100': '농업지역', 'UQA110': '농업진흥지역',
      'UQA121': '생산녹지지역', 'UQA130': '자연녹지지역', 'UQA400': '보전녹지지역'
    };

    // ⭐ Step 2: dataSource 우선순위에 따른 조회
    let zoneTypeName = '미분류';
    let zoneSource = '기본값';
    let zoneInfoResult = null;
    let wmsImageUrl = null;

    if (dataSource === 'api') {
      // === API 우선 모드 ===
      console.log('🌐 Step 2: API 모드 - VWorld 데이터 우선');

      // 1단계: VWorld WMS API 시도
      if (!USE_MOCK && process.env.VWORLD_KEY) {
        try {
          const vworldWmsUrl = 'http://api.vworld.kr/ned/wms/getBuildingUseWMS';
          const params = new URLSearchParams({
            key: process.env.VWORLD_KEY,
            domain: 'carwash',
            layers: 'dt_d198',
            crs: 'EPSG:4326',
            bbox: mapBbox,
            width: 915,
            height: 700,
            format: 'image/png',
            transparent: 'false',
            bgcolor: '0xFFFFFF'
          });

          const response = await fetch(`${vworldWmsUrl}?${params}`);
          if (response.status === 200) {
            const arrayBuffer = await response.arrayBuffer();
            const buffer = Buffer.from(arrayBuffer);
            wmsImageUrl = 'data:image/png;base64,' + buffer.toString('base64');
            console.log(`✅ VWorld WMS 이미지 생성: ${buffer.length}bytes`);
          }
        } catch (err) {
          console.warn('⚠️ VWorld WMS API 실패, Fallback으로 진행:', err.message);
        }
      }

      // 2단계: Fallback - 로컬 DB 조회
      try {
        const testZone = db.prepare(`SELECT COUNT(*) as cnt FROM zone_info LIMIT 1`).get();
        if (testZone && testZone.cnt > 0) {
          const pnuPrefix = session.step1_pnu?.slice(0, 19);
          if (pnuPrefix) {
            zoneInfoResult = db.prepare(`
              SELECT mcls_cd, area_m2 FROM zone_info WHERE wevd_cd LIKE ? LIMIT 1
            `).get(`${pnuPrefix}%`);

            if (zoneInfoResult?.mcls_cd) {
              zoneTypeName = zoneCodeMap[zoneInfoResult.mcls_cd] || '미분류';
              zoneSource = 'zone_info (로컬 DB)';
            }
          }
        }
      } catch (err) {
        console.log('⚠️ zone_info 조회 실패');
      }
    } else {
      // === 로컬 DB 우선 모드 (기본값) ===
      console.log('💾 Step 2: 로컬 DB 모드 - 로컬 데이터 우선');

      try {
        const testZone = db.prepare(`SELECT COUNT(*) as cnt FROM zone_info LIMIT 1`).get();
        if (testZone && testZone.cnt > 0) {
          const pnuPrefix = session.step1_pnu?.slice(0, 19);
          if (pnuPrefix) {
            zoneInfoResult = db.prepare(`
              SELECT mcls_cd, area_m2 FROM zone_info WHERE wevd_cd LIKE ? LIMIT 1
            `).get(`${pnuPrefix}%`);

            if (zoneInfoResult?.mcls_cd) {
              zoneTypeName = zoneCodeMap[zoneInfoResult.mcls_cd] || '미분류';
              zoneSource = 'zone_info (로컬 DB)';
            }
          }
        }
      } catch (err) {
        console.log('⚠️ zone_info 테이블 조회 불가');
      }
    }

    // 3단계: 지역 기반 규칙 Fallback (모든 모드 공통)
    if (zoneTypeName === '미분류') {
      const regionGuess = {
        '11680': '상업지역',  // 강남구
        '31000': '상업지역'   // 양주시
      };
      zoneTypeName = regionGuess[session.step1_sigungu_cd] || '미분류';
      zoneSource = '지역 규칙 기반';
      console.log(`📍 Fallback: ${session.step1_sigungu_cd} → ${zoneTypeName}`);
    }

    // 개발 경향 조회 (선택사항)
    let devPermits = [];
    try {
      devPermits = db.prepare(`
        SELECT
          dev_name,
          COUNT(*) as count,
          MAX(permit_date) as latest_date
        FROM development_permits
        WHERE local_code = ?
        GROUP BY dev_name
        ORDER BY count DESC
        LIMIT 3
      `).all(session.step1_sigungu_cd || []);
    } catch (err) {
      console.log('⚠️ 개발행위정보 조회 실패:', err.message);
    }

    // 용도지역 데이터 (정부 공공데이터 + 개발 경향)
    const landData = {
      zoneType: zoneTypeName,
      zoneCode: zoneInfoResult?.mcls_cd || 'UNKNOWN',
      area: zoneInfoResult?.area_m2 ? Math.round(zoneInfoResult.area_m2).toString() : 'N/A',
      source: zoneSource,

      // 개발 경향
      devTrends: devPermits.length > 0 ? devPermits.map(d => ({
        type: d.dev_name,
        count: d.count,
        recent: d.latest_date
      })) : null,

      // 세차장 허가 판정
      carwashApproval: zoneTypeName.includes('상업') ? '✅ 가능' :
                       zoneTypeName.includes('보전') ? '❌ 불가' :
                       zoneTypeName.includes('자연') ? '⚠️ 검토필요' :
                       zoneTypeName.includes('주거') ? '⚠️ 검토필요' : '❓ 확인필요',

      message: `정부공공데이터 기반: ${zoneTypeName} (${session.step1_sigungu_cd})`
    };

    // Step 2 데이터 저장
    db.prepare(`
      UPDATE workflow_sessions
      SET
        step2_zone_type = ?,
        step2_jimok = ?,
        step2_source = ?,
        step2_completed = 1,
        current_step = 2,
        updated_at = datetime('now','localtime')
      WHERE session_id = ?
    `).run(
      landData.zoneType,
      landData.jimok,
      landData.source || 'Mock',
      sessionId
    );

    // 허가 판정 미리보기 (용도지역 기반)
    const permitPreview = checkPermit(landData.zoneType);

    // 검색 로그 저장
    logSearch(req, sessionId, 2, 'land', { bbox: mapBbox }, { mapBbox, wmsAvailable: !!wmsImageUrl });

    logger.info('Step 2 완료', { sessionId, zoneType: landData.zoneType });

    res.json({
      success: true,
      code: 'STEP2_COMPLETE',
      data: {
        message: '2단계 완료: 용도지역 지도가 생성되었습니다',
        mapImage: wmsImageUrl, // Base64 인코딩된 PNG 이미지
        mapBbox: mapBbox,
        landData: landData,
        permitPreview: {
          result: permitPreview.result,
          reason: permitPreview.reason
        },
        nextStep: 3,
        instruction: '건축물 확인으로 진행하세요'
      }
    });
  } catch (err) {
    const errorId = `ERR-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
    console.error(`[${errorId}] Step 2 처리 실패:`, err.stack);
    errorResponse(res, 500, 'STEP2_ERROR', 'Step 2 처리에 실패했습니다', errorId);
  }
});

// 시군구별 기본 지도 범위 (EPSG:4326: ymin,xmin,ymax,xmax)
function getDefaultBbox(sigunguCd) {
  const bboxMap = {
    '11000': '37.42,126.76,37.62,127.18',    // 서울
    '31000': '37.71,127.09,37.89,127.23',    // 경기 양주시
    '11680': '37.47,127.05,37.50,127.10',    // 서울 강남구
    '11710': '37.49,127.10,37.53,127.15'     // 서울 송파구
  };
  return bboxMap[sigunguCd] || '37.4,127.0,37.6,127.3'; // 기본: 서울 근처
}

// POST /api/workflow/:sessionId/step/3/query - 3단계: 건축물 용도 조회
router.post('/:sessionId/step/3/query', async (req, res) => {
  try {
    const { sessionId } = req.params;
    const { pnu, dataSource } = req.body; // dataSource = 'db' 또는 'api'

    // ✅ P1-2: 파라미터 검증
    if (!sessionId || typeof sessionId !== 'string') {
      return errorResponse(res, 400, 'INVALID_SESSION_ID', '유효한 세션 ID가 필요합니다');
    }

    // Step 1 주소 정보 조회
    const session = db.prepare(`
      SELECT step1_pnu, step1_sigungu_cd, step1_address FROM workflow_sessions WHERE session_id = ?
    `).get(sessionId);

    if (!session) {
      return errorResponse(res, 400, 'STEP1_NOT_COMPLETE', '먼저 1단계(지번 검색)를 완료하세요');
    }

    const usePnu = pnu || session.step1_pnu || '';

    if (!usePnu) {
      return errorResponse(res, 400, 'INVALID_PNU', 'PNU(필지고유번호)가 필요합니다');
    }

    let buildings = [];
    let devHistories = [];
    let resultDataSource = 'unknown';

    // ⭐ dataSource 우선순위에 따른 건축물 조회
    if (dataSource === 'api') {
      // === API 우선 모드 ===
      console.log('🌐 Step 3: API 모드 - VWorld 데이터 우선');

      // 1단계: VWorld getBuildingUse API 시도
      if (!USE_MOCK && process.env.VWORLD_KEY) {
        try {
          const vworldUrl = 'http://api.vworld.kr/ned/data/getBuildingUse';
          const params = new URLSearchParams({
            key: process.env.VWORLD_KEY,
            domain: 'carwash',
            pnu: usePnu,
            format: 'json',
            numOfRows: 20,
            pageNo: 1
          });

          console.log(`🌐 VWorld getBuildingUse API 호출: pnu=${usePnu}`);
          const response = await fetch(`${vworldUrl}?${params}`);
          const data = await response.json();

          if (data?.buildingUses?.field && Array.isArray(data.buildingUses.field)) {
            buildings = data.buildingUses.field.map(item => ({
              id: item.pnu + '_' + item.buldNm,
              buldNm: item.buldNm || 'N/A',
              mainPrposCode: item.mainPrposCode,
              mainPrposCodeNm: item.mainPrposCodeNm || '미분류',
              detailPrposCode: item.detailPrposCode,
              detailPrposCodeNm: item.detailPrposCodeNm || '미분류',
              pnu: item.pnu,
              buldTotar: item.buldTotar || '0',
              buldBildngAr: item.buldBildngAr || '0',
              prmisnDe: item.prmisnDe || 'N/A'
            }));
            resultDataSource = 'vworld_api';
            console.log(`✅ VWorld API에서 ${buildings.length}개 건물 조회됨`);
          } else {
            console.warn('⚠️ VWorld API 응답에 데이터 없음, Fallback 진행');
          }
        } catch (err) {
          console.warn('⚠️ VWorld API 호출 실패:', err.message);
        }
      }

      // 2단계: Fallback - 로컬 DB 조회 (API 실패 시에만)
      if (buildings.length === 0 && session.step1_sigungu_cd) {
        try {
          const dbBuildings = buildingsDb.prepare(`
            SELECT
              id, pnu, road_address, building_name, main_purpose, main_purpose_code,
              detail_purpose, total_area, building_area, approval_date, basement_floor, above_floor
            FROM buildings
            WHERE sigungu_cd = ?
            ORDER BY building_name ASC
            LIMIT 20
          `).all(session.step1_sigungu_cd);

          if (dbBuildings && dbBuildings.length > 0) {
            buildings = dbBuildings.map(item => ({
              id: item.id + '_' + item.building_name,
              buldNm: item.building_name || 'N/A',
              mainPrposCode: item.main_purpose_code,
              mainPrposCodeNm: item.main_purpose || '미분류',
              detailPrposCode: item.detail_purpose || '',
              detailPrposCodeNm: item.detail_purpose || '미분류',
              pnu: item.pnu,
              buldTotar: item.total_area ? Math.round(item.total_area).toString() : '0',
              buldBildngAr: item.building_area ? Math.round(item.building_area).toString() : '0',
              prmisnDe: item.approval_date || 'N/A',
              basementFloor: item.basement_floor,
              aboveFloor: item.above_floor
            }));
            resultDataSource = 'buildings_db (로컬 Fallback)';
            console.log(`✅ 로컬 DB에서 ${buildings.length}개 건물 조회 (Fallback)`);
          }
        } catch (err) {
          console.warn('⚠️ 로컬 DB 조회 실패:', err.message);
        }
      }
    } else {
      // === 로컬 DB 우선 모드 (기본값) ===
      console.log('💾 Step 3: 로컬 DB 모드 - 로컬 데이터만 사용');

      // 로컬 DB만 조회 (API는 시도하지 않음)
      if (session.step1_sigungu_cd) {
        try {
          const dbBuildings = buildingsDb.prepare(`
            SELECT
              id, pnu, road_address, building_name, main_purpose, main_purpose_code,
              detail_purpose, total_area, building_area, approval_date, basement_floor, above_floor
            FROM buildings
            WHERE sigungu_cd = ?
            ORDER BY building_name ASC
            LIMIT 20
          `).all(session.step1_sigungu_cd);

          if (dbBuildings && dbBuildings.length > 0) {
            buildings = dbBuildings.map(item => ({
              id: item.id + '_' + item.building_name,
              buldNm: item.building_name || 'N/A',
              mainPrposCode: item.main_purpose_code,
              mainPrposCodeNm: item.main_purpose || '미분류',
              detailPrposCode: item.detail_purpose || '',
              detailPrposCodeNm: item.detail_purpose || '미분류',
              pnu: item.pnu,
              buldTotar: item.total_area ? Math.round(item.total_area).toString() : '0',
              buldBildngAr: item.building_area ? Math.round(item.building_area).toString() : '0',
              prmisnDe: item.approval_date || 'N/A',
              basementFloor: item.basement_floor,
              aboveFloor: item.above_floor
            }));
            resultDataSource = 'buildings_db (로컬)';
            console.log(`✅ 로컬 DB에서 ${buildings.length}개 건물 조회됨`);
          }
        } catch (err) {
          console.warn('⚠️ 로컬 DB 조회 실패:', err.message);
        }
      }
    }

    // 3단계: Fallback - 주소 기반 Mock 데이터 (모든 모드 공통, 마지막 수단)
    if (buildings.length === 0) {
      buildings = getBuildingsByAddress(session.step1_address);
      resultDataSource = 'address_based_mock';
      console.log(`⚠️ Mock 데이터 사용: ${buildings.length}개`);
    }

    // 개발이력은 항상 조회 (별도 탭에서 표시)
    try {
      const rawDevHistories = db.prepare(`
        SELECT DISTINCT
          location_name,
          dev_name,
          dev_purpose,
          area,
          permit_date,
          local_name
        FROM development_permits
        WHERE local_code = ?
        ORDER BY permit_date DESC
        LIMIT 5
      `).all(session.step1_sigungu_cd || '');

      if (rawDevHistories && rawDevHistories.length > 0) {
        devHistories = rawDevHistories.map((item, idx) => ({
          id: `dev_${idx}`,
          location_name: item.location_name || item.local_name || '미명',
          dev_name: item.dev_name || '개발행위',
          dev_purpose: item.dev_purpose || '세부내용 없음',
          area: item.area ? Math.round(parseFloat(item.area)).toString() : '0',
          permit_date: item.permit_date || 'N/A'
        }));
        console.log(`✅ 개발이력 ${devHistories.length}개 조회됨`);
      }
    } catch (err) {
      console.warn('⚠️ 개발이력 조회 실패:', err.message);
    }

    res.json({
      success: true,
      code: 'STEP3_COMPLETE',
      data: {
        message: buildings.length > 0 ? '건축물 목록이 조회되었습니다' : '해당 지역의 건축물이 없습니다',
        address: session.step1_address,
        pnu: usePnu,
        buildings: buildings,
        devHistories: devHistories,
        buildingCount: buildings.length,
        devHistoryCount: devHistories.length,
        dataSource: resultDataSource
      }
    });
  } catch (err) {
    const errorId = `ERR-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
    console.error(`[${errorId}] Step 3 처리 실패:`, err.stack);
    errorResponse(res, 500, 'STEP3_ERROR', 'Step 3 처리에 실패했습니다', errorId);
  }
});

// 주소 기반 건축물 정보 (API 키 없을 때 대체)
function getBuildingsByAddress(address = '') {
  const buildings = [];

  // 양주시 감악산로 주소
  if (address && address.includes('양주') && address.includes('감악산')) {
    buildings.push(
      {
        id: 'yangju_001',
        bldNm: '감악산로 상가',
        mainPurpsCdNm: '일반음식점',
        totalFlrAr: '2500',
        mgmtBldrgstPk: '31000000000001'
      },
      {
        id: 'yangju_002',
        bldNm: '양주 산업단지 공장',
        mainPurpsCdNm: '제조업시설',
        totalFlrAr: '8500',
        mgmtBldrgstPk: '31000000000002'
      },
      {
        id: 'yangju_003',
        bldNm: '감악산 주거용 주택',
        mainPurpsCdNm: '단독주택',
        totalFlrAr: '1200',
        mgmtBldrgstPk: '31000000000003'
      }
    );
  }
  // 강남구
  else if (address && address.includes('강남')) {
    buildings.push({
      id: 'gangnam_001',
      bldNm: '테헤란빌딩',
      mainPurpsCdNm: '업무용건물',
      totalFlrAr: '3500',
      mgmtBldrgstPk: '11680000000001'
    });
  }
  // 송파구
  else if (address && address.includes('송파')) {
    buildings.push({
      id: 'songpa_001',
      bldNm: '올림픽프라자',
      mainPurpsCdNm: '다중이용업소',
      totalFlrAr: '2800',
      mgmtBldrgstPk: '11710000000001'
    });
  }

  return buildings;
}

// POST /api/workflow/:sessionId/step/3 - 3단계: 건축물 확인 (선택 저장)
router.post('/:sessionId/step/3', (req, res) => {
  try {
    const { sessionId } = req.params;
    const { buildingName, purposeCd, purposeNm, floorArea } = req.body;

    const session = db.prepare('SELECT id FROM workflow_sessions WHERE session_id = ?').get(sessionId);
    if (!session) {
      return res.status(404).json({ success: false, error: '세션을 찾을 수 없습니다' });
    }

    // Step 3 데이터 저장
    db.prepare(`
      UPDATE workflow_sessions
      SET
        step3_building_nm = ?,
        step3_purpose_cd = ?,
        step3_purpose_nm = ?,
        step3_floor_ar = ?,
        step3_completed = 1,
        current_step = 3,
        updated_at = datetime('now','localtime')
      WHERE session_id = ?
    `).run(buildingName || 'Mock Building', purposeCd || 'C1', purposeNm || 'Mock Purpose', floorArea || '0', sessionId);

    // 검색 로그 저장
    logSearch(req, sessionId, 3, 'building', { buildingName, purposeNm }, { buildingName, purposeNm });

    res.json({
      success: true,
      message: '3단계 완료: 건축물 정보가 저장되었습니다',
      data: {
        building: buildingName || 'Mock Building',
        purpose: purposeNm || 'Mock Purpose',
        floorArea: floorArea || '미측정'
      },
      nextStep: 4,
      instruction: '최종 허가 체크로 진행하세요'
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/workflow/:sessionId/step/4 - 4단계: 최종 허가 체크 및 리포트 생성
router.post('/:sessionId/step/4', (req, res) => {
  try {
    const { sessionId } = req.params;

    // ✅ P1-2: 파라미터 검증
    if (!sessionId || typeof sessionId !== 'string') {
      return errorResponse(res, 400, 'INVALID_SESSION_ID', '유효한 세션 ID가 필요합니다');
    }

    const session = db.prepare(`
      SELECT
        step1_address, step1_sigungu_cd,
        step2_zone_type,
        step3_building_nm,
        step3_purpose_nm
      FROM workflow_sessions
      WHERE session_id = ?
    `).get(sessionId);

    if (!session) {
      return errorResponse(res, 404, 'SESSION_NOT_FOUND', '세션을 찾을 수 없습니다');
    }

    // 허가 판정
    const permitResult = checkPermit(session.step2_zone_type);

    // 조례 정보 조회 (지역 기반)
    let localOrdinance = null;
    if (session.step1_sigungu_cd && regulationsDb) {
      try {
        localOrdinance = regulationsDb.prepare(`
          SELECT ordinance_content, special_conditions
          FROM local_ordinances
          WHERE sigungu_code = ?
          LIMIT 1
        `).get(session.step1_sigungu_cd);
      } catch (err) {
        // 테이블이 없으면 무시
      }
    }

    // Step 4 데이터 저장
    db.prepare(`
      UPDATE workflow_sessions
      SET
        step4_result = ?,
        step4_reason = ?,
        step4_conditions = ?,
        step4_checklist = ?,
        step4_completed = 1,
        current_step = 4,
        status = 'completed',
        updated_at = datetime('now','localtime')
      WHERE session_id = ?
    `).run(
      permitResult.result,
      permitResult.reason,
      JSON.stringify(permitResult.conditions),
      JSON.stringify(permitResult.checkList),
      sessionId
    );

    // 최종 리포트 생성
    const report = {
      sessionId: sessionId,
      address: session.step1_address,
      zoneType: session.step2_zone_type,
      building: session.step3_building_nm,
      permitResult: permitResult.result,
      permitReason: permitResult.reason,
      conditions: permitResult.conditions,
      checklist: permitResult.checkList,
      nextSteps: getNextSteps(permitResult.result),
      localOrdinance: localOrdinance ? JSON.parse(localOrdinance.ordinance_content) : null,
      generatedAt: new Date().toISOString()
    };

    // 리포트 저장
    db.prepare(`
      UPDATE workflow_sessions
      SET final_report = ?
      WHERE session_id = ?
    `).run(JSON.stringify(report), sessionId);

    // 검색 로그 저장
    logSearch(req, sessionId, 4, 'permit', { zoneType: session.step2_zone_type }, { permitResult: permitResult.result, conditions: permitResult.conditions });

    res.json({
      success: true,
      code: 'STEP4_COMPLETE',
      data: {
        message: '4단계 완료: 최종 허가 판정이 완료되었습니다',
        report: report,
        nextAction: getNextAction(permitResult.result)
      }
    });
  } catch (err) {
    const errorId = `ERR-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
    console.error(`[${errorId}] Step 4 처리 실패:`, err.stack);
    errorResponse(res, 500, 'STEP4_ERROR', 'Step 4 처리에 실패했습니다', errorId);
  }
});

// GET /api/workflow/:sessionId/report - 최종 리포트 조회
router.get('/:sessionId/report', (req, res) => {
  try {
    const { sessionId } = req.params;

    // ✅ P1-2: 파라미터 검증
    if (!sessionId || typeof sessionId !== 'string') {
      return errorResponse(res, 400, 'INVALID_SESSION_ID', '유효한 세션 ID가 필요합니다');
    }

    const session = db.prepare(`
      SELECT final_report, created_at, updated_at
      FROM workflow_sessions
      WHERE session_id = ?
    `).get(sessionId);

    if (!session) {
      return errorResponse(res, 404, 'SESSION_NOT_FOUND', '세션을 찾을 수 없습니다');
    }

    if (!session.final_report) {
      return errorResponse(res, 400, 'REPORT_NOT_READY', '리포트가 아직 생성되지 않았습니다. 모든 단계를 완료하세요.');
    }

    const report = JSON.parse(session.final_report);

    res.json({
      success: true,
      code: 'REPORT_FOUND',
      data: report
    });
  } catch (err) {
    const errorId = `ERR-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
    console.error(`[${errorId}] 리포트 조회 실패:`, err.stack);
    errorResponse(res, 500, 'REPORT_FETCH_ERROR', '리포트 조회에 실패했습니다', errorId);
  }
});

// DELETE /api/workflow/:sessionId - 세션 삭제
router.delete('/:sessionId', (req, res) => {
  try {
    const { sessionId } = req.params;

    // ✅ P1-2: 파라미터 검증
    if (!sessionId || typeof sessionId !== 'string') {
      return errorResponse(res, 400, 'INVALID_SESSION_ID', '유효한 세션 ID가 필요합니다');
    }

    const result = db.prepare('DELETE FROM workflow_sessions WHERE session_id = ?').run(sessionId);

    if (result.changes === 0) {
      return errorResponse(res, 404, 'SESSION_NOT_FOUND', '세션을 찾을 수 없습니다');
    }

    res.json({
      success: true,
      code: 'SESSION_DELETED',
      data: { message: '세션이 삭제되었습니다' }
    });
  } catch (err) {
    const errorId = `ERR-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
    console.error(`[${errorId}] 세션 삭제 실패:`, err.stack);
    errorResponse(res, 500, 'SESSION_DELETE_ERROR', '세션 삭제에 실패했습니다', errorId);
  }
});

// ============ 헬퍼 함수 ============

function getMockLandData(scenario = '2') {
  const scenarios = {
    '1': {
      zoneType: '상업지역 (일반상업지역)',
      zoneCode: 'C1',
      jimok: '대',
      area: '1500'
    },
    '2': {
      zoneType: '제2종일반주거지역',
      zoneCode: 'R2',
      jimok: '대',
      area: '1200'
    },
    '3': {
      zoneType: '보전녹지지역',
      zoneCode: 'PG',
      jimok: '임',
      area: '2000'
    }
  };
  return scenarios[scenario] || scenarios['2'];
}

function checkPermit(zoneType) {
  if (!zoneType) {
    return {
      result: '미확인',
      reason: '용도지역을 먼저 확인해주세요',
      resultColor: 'result-unknown',
      conditions: [],
      checkList: []
    };
  }

  const isAllowed = (zone) => zoneType.includes(zone);

  // 허가 불가능
  if (isAllowed('보전녹지') || isAllowed('생산녹지') ||
      isAllowed('도시자연공원') || isAllowed('상수원보호') ||
      isAllowed('개발제한구역') || isAllowed('전용주거')) {
    return {
      result: '불가',
      resultColor: 'result-ng',
      reason: '세차장 설치가 금지된 지역입니다',
      conditions: ['보전 및 생산 녹지지역 불가', '상수원 보호구역 불가', '개발제한구역(그린벨트) 불가'],
      checkList: []
    };
  }

  // 조건부 가능
  if (isAllowed('제2종일반주거') || isAllowed('자연녹지')) {
    return {
      result: '조건부가능',
      resultColor: 'result-cond',
      reason: '일정 조건을 만족하면 허가 가능합니다',
      conditions: [
        '✓ 건폐율 60% 이하 확인 필요',
        '✓ 주차장 면적 (최소 6대) 확보',
        '✓ 폐수처리시설 설치 의무',
        '✓ 인접 주거지역 영향 최소화'
      ],
      checkList: [
        '☐ 토지이용계획확인원',
        '☐ 건축물대장',
        '☐ 사업계획서',
        '☐ 폐수배출시설 설치신고 신청서'
      ]
    };
  }

  // 허가 가능
  if (isAllowed('상업지역') || isAllowed('공업지역') ||
      isAllowed('준주거') || isAllowed('일반주거')) {
    return {
      result: '가능',
      resultColor: 'result-ok',
      reason: '세차장 설치가 가능한 지역입니다',
      conditions: [
        '✓ 폐수처리시설 설치 의무',
        '✓ 사업자 자격 확인',
        '✓ 환경 기준 준수'
      ],
      checkList: [
        '☐ 토지이용계획확인원',
        '☐ 건축물대장',
        '☐ 사업계획서',
        '☐ 폐수배출시설 설치신고서'
      ]
    };
  }

  return {
    result: '확인필요',
    resultColor: 'result-cond',
    reason: '정확한 판단을 위해 관할 관청에 직접 문의가 필요합니다',
    conditions: [],
    checkList: ['☐ 관할 구청 건축과 방문/전화 상담']
  };
}

function getNextSteps(result) {
  const steps = {
    '가능': ['1. 토지이용계획확인원 발급 (정부24)', '2. 폐수처리시설 설치신고 (구청 환경과)', '3. 자동차관련시설 건축허가 (구청 건축과)'],
    '조건부가능': ['1. 상세 조례 확인 필요', '2. 설계사무소 상담 (용도변경)', '3. 전문가 컨설팅 권고'],
    '불가': ['다른 위치 검토 필요', '토지 용도 변경 검토 (어려움)', '전문가 상담 (에스크로 회수 등)']
  };
  return steps[result] || [];
}

function getNextAction(result) {
  const actions = {
    '가능': '빅워시 컨설팅 서비스를 통해 세부 절차를 진행하세요',
    '조건부가능': '조건을 만족하는지 설계사무소/전문가와 상담하세요',
    '불가': '다른 부지를 찾거나 전문가 상담을 통해 대안을 검토하세요'
  };
  return actions[result] || '계속 진행하세요';
}

module.exports = router;
