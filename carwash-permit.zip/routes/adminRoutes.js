const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const db = require('../db/init');
const Logger = require('../utils/logger');

const router = express.Router();
const logger = new Logger('adminRoutes');

// ============ 설정 ============
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'carwash2024';
const validTokens = new Set(); // 메모리 토큰 저장소

// uploads 폴더 생성
const uploadsDir = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// multer 설정
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const name = `${Date.now()}-${crypto.randomBytes(4).toString('hex')}${ext}`;
    cb(null, name);
  }
});

const upload = multer({
  storage: storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
  fileFilter: (req, file, cb) => {
    const allowedMimes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    if (allowedMimes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('이미지 파일만 업로드 가능합니다'));
    }
  }
});

// ============ 미들웨어 ============

// Bearer 토큰 검증 미들웨어
function authMiddleware(req, res, next) {
  const token = req.headers.authorization?.replace('Bearer ', '');

  if (!token || !validTokens.has(token)) {
    return res.status(401).json({ success: false, error: '인증이 필요합니다' });
  }

  next();
}

// ✅ P1-2: 에러 응답 표준화
function errorResponse(res, statusCode, code, message, errorId = null) {
  res.status(statusCode).json({
    success: false,
    code,
    message,
    errorId: process.env.NODE_ENV === 'development' ? errorId : undefined,
    timestamp: new Date().toISOString()
  });
}

// ============ 로그인 ============

// POST /api/admin/login - 패스워드 확인 및 토큰 발급
router.post('/login', (req, res) => {
  try {
    const { password } = req.body;

    // ✅ P1-2: 파라미터 검증
    if (!password) {
      return errorResponse(res, 400, 'MISSING_PASSWORD', '패스워드가 필요합니다');
    }

    if (password !== ADMIN_PASSWORD) {
      return errorResponse(res, 401, 'INVALID_PASSWORD', '패스워드가 틀렸습니다');
    }

    // 토큰 생성 (32바이트 hex)
    const token = crypto.randomBytes(32).toString('hex');
    validTokens.add(token);

    // 1시간 후 토큰 자동 삭제
    setTimeout(() => validTokens.delete(token), 3600000);

    res.status(200).json({
      success: true,
      code: 'LOGIN_SUCCESS',
      data: { token }
    });
  } catch (err) {
    const errorId = logger.logError('로그인 실패', err);
    errorResponse(res, 500, 'LOGIN_ERROR', '로그인에 실패했습니다', errorId);
  }
});

// ============ 상품 관리 ============

// GET /api/admin/products - 전체 상품 목록 (비공개 포함)
router.get('/products', authMiddleware, (req, res) => {
  try {
    const products = db.prepare(`
      SELECT p.*, c.name as category_name
      FROM products p
      JOIN categories c ON p.category_id = c.id
      ORDER BY p.sort_order, p.id
    `).all();

    res.json({
      success: true,
      code: 'PRODUCTS_FOUND',
      data: products
    });
  } catch (err) {
    const errorId = logger.logError('상품 목록 조회 실패', err);
    errorResponse(res, 500, 'PRODUCT_LIST_ERROR', '상품 목록 조회에 실패했습니다', errorId);
  }
});

// POST /api/admin/products - 상품 추가
router.post('/products', authMiddleware, upload.single('image'), (req, res) => {
  try {
    const { name, description, category_id, price, stock, options, is_active } = req.body;
    const imageUrl = req.file ? `/uploads/${req.file.filename}` : null;

    // ✅ P1-2: 유효성 검사
    if (!name || !category_id) {
      return errorResponse(res, 400, 'VALIDATION_ERROR', '상품명(name)과 카테고리(category_id)는 필수입니다');
    }

    const result = db.prepare(`
      INSERT INTO products
      (category_id, name, description, price, stock, image_url, options, is_active)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      parseInt(category_id),
      name,
      description || null,
      parseInt(price) || 0,
      parseInt(stock) || 0,
      imageUrl,
      options || '[]',
      is_active === 'false' ? 0 : 1
    );

    res.status(201).json({
      success: true,
      code: 'PRODUCT_CREATED',
      data: { id: result.lastInsertRowid }
    });
  } catch (err) {
    const errorId = logger.logError('상품 생성 실패', err);
    errorResponse(res, 500, 'PRODUCT_CREATE_ERROR', '상품 생성에 실패했습니다', errorId);
  }
});

// PUT /api/admin/products/:id - 상품 수정
router.put('/products/:id', authMiddleware, upload.single('image'), (req, res) => {
  try {
    const { id } = req.params;
    const { name, description, category_id, price, stock, options, is_active } = req.body;

    // ✅ P1-2: 파라미터 검증
    if (!id || isNaN(parseInt(id))) {
      return errorResponse(res, 400, 'INVALID_PRODUCT_ID', '유효한 상품 ID가 필요합니다');
    }

    // 기존 상품 조회
    const product = db.prepare('SELECT * FROM products WHERE id = ?').get(id);
    if (!product) {
      return errorResponse(res, 404, 'PRODUCT_NOT_FOUND', '상품을 찾을 수 없습니다');
    }

    // 이미지 처리
    let imageUrl = product.image_url;
    if (req.file) {
      imageUrl = `/uploads/${req.file.filename}`;
      // 기존 이미지 삭제
      if (product.image_url && product.image_url.startsWith('/uploads/')) {
        const oldPath = path.join(uploadsDir, path.basename(product.image_url));
        if (fs.existsSync(oldPath)) {
          fs.unlinkSync(oldPath);
        }
      }
    }

    db.prepare(`
      UPDATE products
      SET category_id = ?, name = ?, description = ?, price = ?,
          stock = ?, image_url = ?, options = ?, is_active = ?,
          updated_at = datetime('now','localtime')
      WHERE id = ?
    `).run(
      parseInt(category_id) || product.category_id,
      name || product.name,
      description !== undefined ? description : product.description,
      price !== undefined ? parseInt(price) : product.price,
      stock !== undefined ? parseInt(stock) : product.stock,
      imageUrl,
      options !== undefined ? options : product.options,
      is_active === 'false' ? 0 : (is_active !== undefined ? 1 : product.is_active),
      id
    );

    res.json({
      success: true,
      code: 'PRODUCT_UPDATED',
      data: { message: '상품이 수정되었습니다' }
    });
  } catch (err) {
    const errorId = logger.logError('상품 수정 실패', err);
    errorResponse(res, 500, 'PRODUCT_UPDATE_ERROR', '상품 수정에 실패했습니다', errorId);
  }
});

// DELETE /api/admin/products/:id - 상품 삭제
router.delete('/products/:id', authMiddleware, (req, res) => {
  try {
    const { id } = req.params;

    // ✅ P1-2: 파라미터 검증
    if (!id || isNaN(parseInt(id))) {
      return errorResponse(res, 400, 'INVALID_PRODUCT_ID', '유효한 상품 ID가 필요합니다');
    }

    const product = db.prepare('SELECT * FROM products WHERE id = ?').get(id);
    if (!product) {
      return errorResponse(res, 404, 'PRODUCT_NOT_FOUND', '상품을 찾을 수 없습니다');
    }

    // 이미지 삭제
    if (product.image_url && product.image_url.startsWith('/uploads/')) {
      const imagePath = path.join(uploadsDir, path.basename(product.image_url));
      if (fs.existsSync(imagePath)) {
        fs.unlinkSync(imagePath);
      }
    }

    db.prepare('DELETE FROM products WHERE id = ?').run(id);

    res.json({
      success: true,
      code: 'PRODUCT_DELETED',
      data: { message: '상품이 삭제되었습니다' }
    });
  } catch (err) {
    const errorId = logger.logError('상품 삭제 실패', err);
    errorResponse(res, 500, 'PRODUCT_DELETE_ERROR', '상품 삭제에 실패했습니다', errorId);
  }
});

// ============ 주문 관리 ============

// GET /api/admin/orders - 주문 목록
router.get('/orders', authMiddleware, (req, res) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;
    const offset = (Math.max(1, parseInt(page)) - 1) * Math.min(100, parseInt(limit));

    let sql = 'SELECT * FROM orders WHERE 1=1';
    const params = [];

    if (status) {
      sql += ' AND status = ?';
      params.push(status);
    }

    sql += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
    params.push(Math.min(100, parseInt(limit)), offset);

    const orders = db.prepare(sql).all(...params);

    // 각 주문의 아이템 조회
    const enrichedOrders = orders.map(order => {
      const items = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(order.id);
      return { ...order, items };
    });

    res.json({
      success: true,
      code: 'ORDERS_FOUND',
      data: enrichedOrders
    });
  } catch (err) {
    const errorId = logger.logError('주문 목록 조회 실패', err);
    errorResponse(res, 500, 'ORDER_LIST_ERROR', '주문 목록 조회에 실패했습니다', errorId);
  }
});

// PATCH /api/admin/orders/:id/status - 주문 상태 변경
router.patch('/orders/:id/status', authMiddleware, (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    // ✅ P1-2: 파라미터 검증
    if (!id || isNaN(parseInt(id))) {
      return errorResponse(res, 400, 'INVALID_ORDER_ID', '유효한 주문 ID가 필요합니다');
    }

    if (!status) {
      return errorResponse(res, 400, 'MISSING_STATUS', '상태(status)가 필요합니다');
    }

    const validStatuses = ['pending', 'confirmed', 'shipped', 'delivered', 'cancelled'];
    if (!validStatuses.includes(status)) {
      return errorResponse(res, 400, 'INVALID_STATUS', `유효하지 않은 상태입니다. 가능한 값: ${validStatuses.join(', ')}`);
    }

    const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(id);
    if (!order) {
      return errorResponse(res, 404, 'ORDER_NOT_FOUND', '주문을 찾을 수 없습니다');
    }

    db.prepare(`
      UPDATE orders SET status = ?, updated_at = datetime('now','localtime')
      WHERE id = ?
    `).run(status, id);

    res.json({
      success: true,
      code: 'ORDER_STATUS_UPDATED',
      data: { message: '주문 상태가 변경되었습니다', orderId: id, status }
    });
  } catch (err) {
    const errorId = logger.logError('주문 상태 변경 실패', err);
    errorResponse(res, 500, 'ORDER_STATUS_ERROR', '주문 상태 변경에 실패했습니다', errorId);
  }
});

// ============ 관리자 대시보드 (NEW) ============

// GET /api/admin/dashboard - 대시보드 통계
router.get('/dashboard', authMiddleware, (req, res) => {
  try {
    // 로컬 시간 기준 오늘 날짜
    const today = db.prepare("SELECT date('now','localtime') as date").get().date;

    const stats = {
      // 검색 통계
      totalSearches: db.prepare(`
        SELECT COUNT(*) as count FROM workflow_search_logs
        WHERE date(created_at) = ?
      `).get(today)?.count || 0,

      searchesByType: db.prepare(`
        SELECT search_type, COUNT(*) as count FROM workflow_search_logs
        WHERE date(created_at) = ?
        GROUP BY search_type
      `).all(today),

      uniqueIps: db.prepare(`
        SELECT COUNT(DISTINCT ip_address) as count FROM workflow_search_logs
        WHERE date(created_at) = ?
      `).get(today)?.count || 0,

      // 워크플로우 세션
      activeSessions: db.prepare(`
        SELECT COUNT(*) as count FROM workflow_sessions
        WHERE status = 'active' AND date(created_at) = ?
      `).get(today)?.count || 0,

      completedWorkflows: db.prepare(`
        SELECT COUNT(*) as count FROM workflow_sessions
        WHERE status = 'completed' AND date(created_at) = ?
      `).get(today)?.count || 0,

      // IP별 상위 검색자
      topIps: db.prepare(`
        SELECT ip_address, COUNT(*) as count FROM workflow_search_logs
        WHERE date(created_at) = ?
        GROUP BY ip_address
        ORDER BY count DESC
        LIMIT 10
      `).all(today) || [],

      // 시간별 검색 추이
      hourlyStats: db.prepare(`
        SELECT
          substr(created_at, 12, 2) as hour,
          COUNT(*) as count
        FROM workflow_search_logs
        WHERE date(created_at) = ?
        GROUP BY hour
        ORDER BY hour
      `).all(today) || []
    };

    res.json({
      success: true,
      date: today,
      stats: stats
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ============ 검색 로그 조회 (NEW) ============

// GET /api/admin/search-logs - 검색 로그 페이지 조회
router.get('/search-logs', authMiddleware, (req, res) => {
  try {
    const { page = 1, limit = 20, ip_address, search_type, date_from, date_to } = req.query;
    const offset = (Math.max(1, parseInt(page)) - 1) * Math.min(100, parseInt(limit));

    // WHERE 절 동적 생성
    let where = '1=1';
    const params = [];

    if (ip_address) {
      where += ' AND ip_address LIKE ?';
      params.push(`%${ip_address}%`);
    }

    if (search_type) {
      where += ' AND search_type = ?';
      params.push(search_type);
    }

    if (date_from) {
      where += ' AND date(created_at) >= ?';
      params.push(date_from);
    }

    if (date_to) {
      where += ' AND date(created_at) <= ?';
      params.push(date_to);
    }

    // 전체 개수
    const totalQuery = `SELECT COUNT(*) as count FROM workflow_search_logs WHERE ${where}`;
    const totalResult = db.prepare(totalQuery).get(...params);

    // 페이지 데이터
    const dataQuery = `
      SELECT * FROM workflow_search_logs
      WHERE ${where}
      ORDER BY created_at DESC
      LIMIT ? OFFSET ?
    `;
    const logs = db.prepare(dataQuery).all(...params, Math.min(100, parseInt(limit)), offset);

    res.json({
      success: true,
      total: totalResult.count,
      page: Math.max(1, parseInt(page)),
      limit: Math.min(100, parseInt(limit)),
      totalPages: Math.ceil(totalResult.count / Math.min(100, parseInt(limit))),
      logs: logs
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/admin/ip/:ip - IP별 상세 조회
router.get('/ip/:ip', authMiddleware, (req, res) => {
  try {
    const { ip } = req.params;

    const logs = db.prepare(`
      SELECT * FROM workflow_search_logs
      WHERE ip_address = ?
      ORDER BY created_at DESC
    `).all(ip);

    // IP 통계
    const stats = db.prepare(`
      SELECT
        COUNT(*) as total_searches,
        COUNT(DISTINCT session_id) as unique_sessions,
        COUNT(DISTINCT date(created_at)) as active_days,
        MIN(created_at) as first_access,
        MAX(created_at) as last_access,
        GROUP_CONCAT(DISTINCT search_type) as search_types,
        GROUP_CONCAT(DISTINCT device_type) as device_types
      FROM workflow_search_logs
      WHERE ip_address = ?
    `).get(ip);

    res.json({
      success: true,
      ip_address: ip,
      stats: stats || {},
      logs: logs
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
