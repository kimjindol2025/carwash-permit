const express = require('express');
const regulationsDb = require('../db/init').regulationsDb;

const router = express.Router();

if (!regulationsDb) {
  console.warn('⚠️ 규정 DB를 사용할 수 없습니다');
}

// ========== 용도지역별 허가 기준 ==========
router.get('/land-use-zones', (req, res) => {
  try {
    const zones = regulationsDb.prepare(`
      SELECT id, zone_name, zone_code, car_wash_permit, reason, notes
      FROM land_use_zones
      ORDER BY id
    `).all();

    res.json({ success: true, data: zones });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 특정 용도지역의 허가 기준 조회
router.get('/land-use-zones/:zone_name', (req, res) => {
  try {
    const zone = regulationsDb.prepare(`
      SELECT * FROM land_use_zones
      WHERE zone_name = ?
    `).get(req.params.zone_name);

    if (!zone) {
      return res.status(404).json({ success: false, error: '해당 용도지역을 찾을 수 없습니다' });
    }

    res.json({ success: true, data: zone });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ========== 수질오염 배출 기준 ==========
router.get('/water-quality-standards', (req, res) => {
  try {
    const { region_type, pollutant_name } = req.query;
    let sql = 'SELECT * FROM water_quality_standards WHERE 1=1';
    const params = [];

    if (region_type) {
      sql += ' AND region_type = ?';
      params.push(region_type);
    }
    if (pollutant_name) {
      sql += ' AND pollutant_name = ?';
      params.push(pollutant_name);
    }

    sql += ' ORDER BY pollutant_name, region_type';

    const standards = regulationsDb.prepare(sql).all(...params);
    res.json({ success: true, data: standards });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ========== 폐수처리 시설 기준 ==========
router.get('/wastewater-facilities', (req, res) => {
  try {
    const facilities = regulationsDb.prepare(`
      SELECT * FROM wastewater_facility_standards
      ORDER BY category, capacity_range
    `).all();

    res.json({ success: true, data: facilities });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ========== 필수 제출 서류 ==========
router.get('/required-documents', (req, res) => {
  try {
    const { approval_stage } = req.query;
    let sql = 'SELECT * FROM required_documents WHERE 1=1';
    const params = [];

    if (approval_stage) {
      sql += ' AND approval_stage = ?';
      params.push(approval_stage);
    }

    sql += ' ORDER BY approval_stage, id';

    const docs = regulationsDb.prepare(sql).all(...params);
    res.json({ success: true, data: docs });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 승인 단계별 그룹화
router.get('/required-documents/grouped', (req, res) => {
  try {
    const docs = regulationsDb.prepare(`
      SELECT approval_stage, GROUP_CONCAT(document_name, '|') as documents, COUNT(*) as count
      FROM required_documents
      GROUP BY approval_stage
      ORDER BY approval_stage
    `).all();

    const grouped = docs.map(doc => ({
      approval_stage: doc.approval_stage,
      count: doc.count,
      documents: doc.documents.split('|')
    }));

    res.json({ success: true, data: grouped });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ========== 관공서 확인 사항 ==========
router.get('/regulatory-agencies', (req, res) => {
  try {
    const agencies = regulationsDb.prepare(`
      SELECT id, agency_name, agency_code, responsibility, restriction_authority, contact_note
      FROM regulatory_agencies
      ORDER BY id
    `).all();

    res.json({ success: true, data: agencies });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ========== 허가 판정 규칙 ==========
router.get('/permit-decision-rules', (req, res) => {
  try {
    const rules = regulationsDb.prepare(`
      SELECT rule_order, condition, check_item, pass_result, fail_result, is_critical
      FROM permit_decision_rules
      ORDER BY rule_order
    `).all();

    res.json({ success: true, data: rules });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ========== 운영 기준 ==========
router.get('/operation-standards', (req, res) => {
  try {
    const standards = regulationsDb.prepare(`
      SELECT standard_item, requirement, frequency, responsible_agency, penalty_type
      FROM operation_standards
      ORDER BY id
    `).all();

    res.json({ success: true, data: standards });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ========== 자동차관련시설 법적 정의 ==========
router.get('/automotive-facilities', (req, res) => {
  try {
    const facilities = regulationsDb.prepare(`
      SELECT facility_name, legal_basis, building_law_code, definition, subcategories
      FROM automotive_facility_types
      ORDER BY id
    `).all();

    res.json({ success: true, data: facilities });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ========== 시설별 용도지역 허가 매트릭스 ==========
router.get('/automotive-zoning/:facility_type', (req, res) => {
  try {
    const { facility_type } = req.params;
    const matrix = regulationsDb.prepare(`
      SELECT zone_name, zone_code, permission_status, law_reference, notes
      FROM facility_zoning_matrix
      WHERE facility_type = ?
      ORDER BY id
    `).all(facility_type);

    if (matrix.length === 0) {
      return res.status(404).json({ success: false, error: '해당 시설 유형을 찾을 수 없습니다' });
    }

    res.json({ success: true, facility_type, data: matrix });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ========== 시설별 건축법/기술 기준 ==========
router.get('/automotive-standards/:facility_type', (req, res) => {
  try {
    const { facility_type } = req.params;
    const standards = regulationsDb.prepare(`
      SELECT standard_item, minimum_value, maximum_value, unit, requirement_type, law_reference, notes
      FROM automotive_facility_standards
      WHERE facility_type = ?
      ORDER BY id
    `).all(facility_type);

    if (standards.length === 0) {
      return res.status(404).json({ success: false, error: '해당 시설 기준을 찾을 수 없습니다' });
    }

    res.json({ success: true, facility_type, data: standards });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ========== 시설별 환경 기준 ==========
router.get('/automotive-environment/:facility_type', (req, res) => {
  try {
    const { facility_type } = req.params;
    const environment = regulationsDb.prepare(`
      SELECT environmental_item, standard_value, unit, measurement_method, inspection_frequency, law_reference
      FROM automotive_facility_environment
      WHERE facility_type = ?
      ORDER BY id
    `).all(facility_type);

    if (environment.length === 0) {
      return res.status(404).json({ success: false, error: '해당 환경 기준을 찾을 수 없습니다' });
    }

    res.json({ success: true, facility_type, data: environment });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ========== 시설별 필수 등록/인허가 ==========
router.get('/facility-registrations/:facility_type', (req, res) => {
  try {
    const { facility_type } = req.params;
    const registrations = regulationsDb.prepare(`
      SELECT registration_name, issuing_authority, application_requirements, processing_period, annual_inspection, validity_period, law_reference
      FROM facility_registrations
      WHERE facility_type = ?
      ORDER BY id
    `).all(facility_type);

    if (registrations.length === 0) {
      return res.status(404).json({ success: false, error: '해당 인허가 정보를 찾을 수 없습니다' });
    }

    res.json({ success: true, facility_type, data: registrations });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ========== 시설별 폐수처리 의무 ==========
router.get('/facility-wastewater/:facility_type', (req, res) => {
  try {
    const { facility_type } = req.params;
    const wastewater = regulationsDb.prepare(`
      SELECT triggering_condition, wastewater_notification_required, treatment_facility_required, water_quality_inspection_required, inspection_frequency, estimated_daily_discharge, law_reference
      FROM facility_wastewater_obligations
      WHERE facility_type = ?
      ORDER BY id
    `).all(facility_type);

    if (wastewater.length === 0) {
      return res.status(404).json({ success: false, error: '해당 폐수처리 정보를 찾을 수 없습니다' });
    }

    res.json({ success: true, facility_type, data: wastewater });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ========== 지자체별 세차장 조례 ==========
router.get('/local-ordinances', (req, res) => {
  try {
    const { sido, region_code } = req.query;
    let sql = 'SELECT * FROM local_ordinances WHERE 1=1';
    const params = [];

    if (sido) {
      sql += ' AND sido_name = ?';
      params.push(sido);
    }
    if (region_code) {
      sql += ' AND region_code = ?';
      params.push(region_code);
    }

    sql += ' ORDER BY sido_name';

    const ordinances = regulationsDb.prepare(sql).all(...params);
    res.json({ success: true, data: ordinances });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 특정 지자체 상세 조회
router.get('/local-ordinances/:region_code', (req, res) => {
  try {
    const { region_code } = req.params;

    // 지자체 기본 정보
    const ordinance = regulationsDb.prepare(`
      SELECT * FROM local_ordinances WHERE region_code = ?
    `).get(region_code);

    if (!ordinance) {
      return res.status(404).json({ success: false, error: '해당 지자체 정보를 찾을 수 없습니다' });
    }

    // 폐수처리시설 기준
    const wastewaterStandards = regulationsDb.prepare(`
      SELECT facility_type, capacity_min, capacity_max, material_requirement, maintenance_frequency, inspection_requirement
      FROM regional_wastewater_standards
      WHERE region_code = ? OR region_code = '00000'
      ORDER BY facility_type
    `).all(region_code);

    // 담당 기관
    const authorities = regulationsDb.prepare(`
      SELECT * FROM regional_authorities WHERE region_code = ?
    `).get(region_code);

    res.json({
      success: true,
      ordinance: ordinance,
      wastewater_standards: wastewaterStandards,
      authorities: authorities
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ========== 지자체별 담당 기관 ==========
router.get('/regional-authorities/:region_code', (req, res) => {
  try {
    const { region_code } = req.params;
    const authority = regulationsDb.prepare(`
      SELECT * FROM regional_authorities WHERE region_code = ?
    `).get(region_code);

    if (!authority) {
      return res.status(404).json({ success: false, error: '해당 지자체 담당기관 정보를 찾을 수 없습니다' });
    }

    res.json({ success: true, data: authority });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ========== 세차장 허가 의사결정 엔진 ==========

// 기존 건축물 용도별 판정
router.get('/carwash/building-judgement/:building_purpose', (req, res) => {
  try {
    const { building_purpose } = req.params;
    const judgement = regulationsDb.prepare(`
      SELECT * FROM existing_building_judgement
      WHERE building_purpose = ?
    `).get(building_purpose);

    if (!judgement) {
      return res.status(404).json({ success: false, error: '해당 건축물 용도를 찾을 수 없습니다' });
    }

    // inspection_items를 JSON 파싱
    const result = {
      ...judgement,
      inspection_items: judgement.inspection_items ? JSON.parse(judgement.inspection_items) : []
    };

    res.json({ success: true, data: result });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 나대지 신축 규칙
router.get('/carwash/newland-rules/:initial_purpose', (req, res) => {
  try {
    const { initial_purpose } = req.params;
    const rules = regulationsDb.prepare(`
      SELECT * FROM newland_carwash_rules
      WHERE initial_purpose = ?
    `).get(initial_purpose);

    if (!rules) {
      return res.status(404).json({ success: false, error: '해당 신축 규칙을 찾을 수 없습니다' });
    }

    const result = {
      ...rules,
      required_design_items: rules.required_design_items ? JSON.parse(rules.required_design_items) : [],
      required_permits: rules.required_permits ? JSON.parse(rules.required_permits) : []
    };

    res.json({ success: true, data: result });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 기존 건축물 용도변경 규칙
router.get('/carwash/purpose-change/:from_purpose', (req, res) => {
  try {
    const { from_purpose } = req.params;
    const rules = regulationsDb.prepare(`
      SELECT * FROM building_purpose_change_rules
      WHERE from_purpose = ?
    `).get(from_purpose);

    if (!rules) {
      return res.status(404).json({ success: false, error: '해당 용도변경 규칙을 찾을 수 없습니다' });
    }

    const result = {
      ...rules,
      design_requirements: rules.design_requirements ? JSON.parse(rules.design_requirements) : [],
      approval_requirements: rules.approval_requirements ? JSON.parse(rules.approval_requirements) : []
    };

    res.json({ success: true, data: result });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 지역별 용도변경 규칙
router.get('/carwash/regional-rules/:region_code/:from_purpose', (req, res) => {
  try {
    const { region_code, from_purpose } = req.params;
    const rules = regulationsDb.prepare(`
      SELECT * FROM regional_purpose_change_rules
      WHERE region_code = ? AND from_purpose = ?
    `).get(region_code, from_purpose);

    if (!rules) {
      return res.status(404).json({ success: false, error: '해당 지역 용도변경 규칙을 찾을 수 없습니다' });
    }

    const result = {
      ...rules,
      special_conditions: rules.special_conditions ? JSON.parse(rules.special_conditions) : []
    };

    res.json({ success: true, data: result });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 검수 항목 체크리스트
router.get('/carwash/inspection-checklist/:category', (req, res) => {
  try {
    const { category } = req.params;
    const checklist = regulationsDb.prepare(`
      SELECT * FROM inspection_checklist
      WHERE category = ?
      ORDER BY id
    `).all(category);

    if (checklist.length === 0) {
      return res.status(404).json({ success: false, error: '해당 카테고리의 검수 항목을 찾을 수 없습니다' });
    }

    res.json({ success: true, category, data: checklist });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 세차장 최종 허가 판정
router.post('/carwash/final-assessment', (req, res) => {
  try {
    const {
      address,
      zone_code,
      building_purpose,
      building_type,
      region_code
    } = req.body;

    if (!address || !zone_code || !building_purpose || !building_type || !region_code) {
      return res.status(400).json({ success: false, error: '필수 정보가 부족합니다' });
    }

    // 1단계: 토지 용도 확인 (건축법 상 고정불변)
    const landZone = regulationsDb.prepare(`
      SELECT * FROM land_use_zones WHERE zone_code = ?
    `).get(zone_code);

    let landPermitStatus = 'ok';
    let landReason = '';

    if (!landZone) {
      landPermitStatus = 'denied';
      landReason = '해당 용도지역을 찾을 수 없습니다';
    } else if (landZone.car_wash_permit === 'denied') {
      landPermitStatus = 'denied';
      landReason = landZone.reason || '이 지역에서는 세차장 설치가 불가능합니다';
    } else if (landZone.car_wash_permit === 'conditional') {
      landPermitStatus = 'conditional';
      landReason = landZone.notes || '조건 충족 시 허가 가능';
    }

    // 토지 거부 시 관청 안내 (CONSULT)
    if (landPermitStatus === 'denied') {
      // 담당 관청 정보 조회
      const authorities = regulationsDb.prepare(`
        SELECT agency_name, contact_note, responsibility
        FROM regional_authorities
        WHERE region_code = ?
      `).all(region_code);

      return res.json({
        success: true,
        assessment_date: new Date().toISOString().split('T')[0],
        address,
        zone_code,
        building_purpose,
        building_type,
        land_permit_status: 'denied',
        land_reason: landReason,
        final_decision: 'consult',
        final_reason: '토지 용도 부적합 - 관청에 직접 확인 필요',
        next_step: '해당 지역 관청에 직접 문의하세요',
        authorities: authorities || []
      });
    }

    // 2단계: 건축물 판정 (설계로 변경 가능)
    let buildingPermitStatus = 'denied';
    let buildingReason = '';
    let requiresPurposeChange = false;
    let estimatedChangePeriod = '';
    let requiresCouncilReview = false;

    if (building_type === 'existing') {
      const buildingJudgement = regulationsDb.prepare(`
        SELECT * FROM existing_building_judgement
        WHERE building_purpose = ?
      `).get(building_purpose);

      if (buildingJudgement) {
        buildingPermitStatus = buildingJudgement.category === 'freepass' ? 'freepass' : 'inspection';
        buildingReason = buildingJudgement.notes || '';

        if (buildingJudgement.category === 'inspection') {
          requiresPurposeChange = true;

          // 용도변경 규칙 조회
          const changeRules = regulationsDb.prepare(`
            SELECT * FROM building_purpose_change_rules
            WHERE from_purpose = ? AND to_purpose = '자동차관련시설'
          `).get(building_purpose);

          if (changeRules) {
            estimatedChangePeriod = `${changeRules.change_period_min}~${changeRules.change_period_max}일`;
            requiresCouncilReview = changeRules.requires_council_review === 1;

            // 지역별 특수 조건 확인
            const regionalRules = regulationsDb.prepare(`
              SELECT * FROM regional_purpose_change_rules
              WHERE region_code = ? AND from_purpose = ?
            `).get(region_code, building_purpose);

            if (regionalRules) {
              estimatedChangePeriod = `${regionalRules.estimated_period_days}일`;
              requiresCouncilReview = regionalRules.council_review_required === 1;
            }
          }
        }
      }
    } else if (building_type === 'newland') {
      const newlandRules = regulationsDb.prepare(`
        SELECT * FROM newland_carwash_rules
        WHERE initial_purpose = ? AND is_allowed = 1
      `).get(building_purpose);

      if (newlandRules) {
        buildingPermitStatus = 'freepass';
        buildingReason = '나대지 신축으로 자동차관련시설 세차장 지정 가능';
      }
    }

    // 최종 판정 로직
    let finalDecision = 'go';
    let finalReason = '세차장 설치 허가 가능';

    if (buildingPermitStatus === 'denied') {
      finalDecision = 'stop';
      finalReason = '건축물 용도로는 세차장 설치 불가능';
    } else if (buildingPermitStatus === 'inspection') {
      finalDecision = 'caution';
      finalReason = requiresCouncilReview ?
        '용도변경 필수 + 의회 심의 필요' :
        '용도변경 필수 (설계사무소 상담)';
    } else if (landPermitStatus === 'conditional') {
      finalDecision = 'caution';
      finalReason = '토지 조건 확인 필요 + 건축물 검증';
    }

    // DB 저장
    const assessmentId = regulationsDb.prepare(`
      INSERT INTO carwash_assessment_results (
        assessment_date, address, zone_code, building_purpose, building_type,
        land_permit_status, land_reason,
        building_permit_status, building_reason,
        requires_purpose_change, estimated_change_period, requires_council_review,
        final_decision, final_reason, designer_consultation_required
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      new Date().toISOString().split('T')[0],
      address, zone_code, building_purpose, building_type,
      landPermitStatus, landReason,
      buildingPermitStatus, buildingReason,
      requiresPurposeChange ? 1 : 0, estimatedChangePeriod, requiresCouncilReview ? 1 : 0,
      finalDecision, finalReason, buildingPermitStatus === 'inspection' ? 1 : 0
    );

    res.json({
      success: true,
      assessment_date: new Date().toISOString().split('T')[0],
      address,
      zone_code,
      building_purpose,
      building_type,
      land_permit_status: landPermitStatus,
      land_reason: landReason,
      building_permit_status: buildingPermitStatus,
      building_reason: buildingReason,
      requires_purpose_change: requiresPurposeChange,
      estimated_change_period: estimatedChangePeriod,
      requires_council_review: requiresCouncilReview,
      final_decision: finalDecision,
      final_reason: finalReason,
      designer_consultation_required: buildingPermitStatus === 'inspection'
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ========== 통합 허가 심사 (새로운 기능) ==========
router.post('/permit-assessment', (req, res) => {
  try {
    const { zone_name, has_wastewater_plan, agencies_approved } = req.body;

    if (!zone_name || has_wastewater_plan === undefined || !agencies_approved) {
      return res.status(400).json({ success: false, error: '필수 정보가 부족합니다' });
    }

    // 1단계: 용도지역 확인
    const zone = regulationsDb.prepare('SELECT * FROM land_use_zones WHERE zone_name = ?')
      .get(zone_name);

    if (!zone) {
      return res.json({
        success: true,
        result: '거부',
        reason: '해당 용도지역을 찾을 수 없습니다',
        details: []
      });
    }

    if (zone.car_wash_permit === 'denied') {
      return res.json({
        success: true,
        result: '거부',
        reason: zone.reason || '해당 지역에서는 세차장 설치가 불가능합니다',
        details: [
          { item: '용도지역 확인', status: 'fail', message: zone.notes }
        ]
      });
    }

    // 2단계: 폐수처리 계획 확인
    if (!has_wastewater_plan) {
      return res.json({
        success: true,
        result: '거부',
        reason: '폐수처리시설 설치 계획이 필수입니다',
        details: [
          { item: '용도지역 확인', status: 'pass' },
          { item: '폐수처리 계획', status: 'fail', message: '폐수처리시설 설치 의무' }
        ]
      });
    }

    // 3단계: 관공서 승인 확인
    const requiredAgencies = ['ARCH', 'ENV', 'WATER', 'ROAD'];
    const missingAgencies = requiredAgencies.filter(a => !agencies_approved.includes(a));

    if (missingAgencies.length > 0) {
      const agencyNames = {
        ARCH: '건축과',
        ENV: '환경과',
        WATER: '상하수도사업소',
        ROAD: '도로과'
      };
      return res.json({
        success: true,
        result: '거부',
        reason: '필수 관공서 승인이 부족합니다',
        details: [
          { item: '용도지역 확인', status: 'pass' },
          { item: '폐수처리 계획', status: 'pass' },
          { item: '관공서 최종 확인', status: 'fail', message: `${missingAgencies.map(a => agencyNames[a]).join(', ')} 미승인` }
        ]
      });
    }

    // 모든 조건 통과
    const result = zone.car_wash_permit === 'conditional' ? '조건부 허가' : '허가';

    res.json({
      success: true,
      result: result,
      reason: zone.car_wash_permit === 'conditional' ?
        `조건부 허가 가능: ${zone.notes}` :
        '세차장 설치 허가 가능',
      details: [
        { item: '용도지역 확인', status: 'pass' },
        { item: '폐수처리 계획', status: 'pass' },
        { item: '관공서 최종 확인', status: 'pass' },
        { item: '최종 판정', status: 'pass', message: result }
      ]
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ========== 5개 법령 통합 API ==========

// 1. 법령 메타데이터 조회
router.get('/legal-frameworks', (req, res) => {
  try {
    const frameworks = regulationsDb.prepare(`
      SELECT framework_name, short_name, official_name, law_number, enforcement_date, description, carwash_relevance
      FROM legal_framework_metadata
      ORDER BY framework_name
    `).all();

    res.json({ success: true, data: frameworks });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 2. 도시계획법 기준 조회
router.get('/frameworks/urban-planning', (req, res) => {
  try {
    const { category } = req.query;
    let sql = 'SELECT * FROM urban_planning_standards WHERE 1=1';
    const params = [];

    if (category) {
      sql += ' AND category = ?';
      params.push(category);
    }

    sql += ' ORDER BY id';
    const data = regulationsDb.prepare(sql).all(...params);

    res.json({ success: true, framework: '도시계획법', data: data });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 3. 도로법 기준 조회
router.get('/frameworks/road-access', (req, res) => {
  try {
    const { category } = req.query;
    let sql = 'SELECT * FROM road_access_standards WHERE 1=1';
    const params = [];

    if (category) {
      sql += ' AND category = ?';
      params.push(category);
    }

    sql += ' ORDER BY id';
    const data = regulationsDb.prepare(sql).all(...params);

    res.json({ success: true, framework: '도로법', data: data });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 4. 상하수도법 기준 조회
router.get('/frameworks/water-sewerage', (req, res) => {
  try {
    const { category } = req.query;
    let sql = 'SELECT * FROM water_sewerage_standards WHERE 1=1';
    const params = [];

    if (category) {
      sql += ' AND category = ?';
      params.push(category);
    }

    sql += ' ORDER BY id';
    const data = regulationsDb.prepare(sql).all(...params);

    res.json({ success: true, framework: '상하수도법', data: data });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 5. 환경법(물환경보전법) 배출기준 조회
router.get('/frameworks/environmental-emission', (req, res) => {
  try {
    const { basin_name, region_code } = req.query;
    let sql = 'SELECT * FROM environmental_emission_standards WHERE 1=1';
    const params = [];

    if (basin_name) {
      sql += ' AND basin_name = ?';
      params.push(basin_name);
    }
    if (region_code) {
      sql += ' AND region_code LIKE ?';
      params.push(`%${region_code}%`);
    }

    sql += ' ORDER BY region_code';
    const data = regulationsDb.prepare(sql).all(...params);

    res.json({ success: true, framework: '물환경보전법/수질오염방지법', data: data });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 6. 세차장 통합 체크리스트 (9단계)
router.get('/frameworks/carwash-checklist', (req, res) => {
  try {
    const checklist = regulationsDb.prepare(`
      SELECT step_num, step_name, related_law, check_item, requirement, approval_body, duration_estimate, cost_estimate
      FROM carwash_integrated_checklist
      ORDER BY step_num
    `).all();

    res.json({ success: true, framework: '세차장 설립 9단계 통합 체크리스트', data: checklist });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 7. 특정 단계 상세 조회
router.get('/frameworks/carwash-checklist/:step_num', (req, res) => {
  try {
    const { step_num } = req.params;
    const step = regulationsDb.prepare(`
      SELECT * FROM carwash_integrated_checklist
      WHERE step_num = ?
    `).get(parseInt(step_num));

    if (!step) {
      return res.status(404).json({ success: false, error: '해당 단계를 찾을 수 없습니다' });
    }

    res.json({ success: true, data: step });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 8. 통합 법령 요약 (전체 요점)
router.get('/frameworks/summary', (req, res) => {
  try {
    const frameworks = regulationsDb.prepare('SELECT * FROM legal_framework_metadata ORDER BY framework_name').all();
    const upSummary = regulationsDb.prepare('SELECT COUNT(*) as count FROM urban_planning_standards').get();
    const roadSummary = regulationsDb.prepare('SELECT COUNT(*) as count FROM road_access_standards').get();
    const waterSummary = regulationsDb.prepare('SELECT COUNT(*) as count FROM water_sewerage_standards').get();
    const envSummary = regulationsDb.prepare('SELECT COUNT(*) as count FROM environmental_emission_standards').get();
    const checklistSummary = regulationsDb.prepare('SELECT COUNT(*) as count FROM carwash_integrated_checklist').get();

    const summary = {
      total_frameworks: frameworks.length,
      frameworks: frameworks,
      data_statistics: {
        urban_planning_standards: upSummary.count,
        road_access_standards: roadSummary.count,
        water_sewerage_standards: waterSummary.count,
        environmental_emission_standards: envSummary.count,
        carwash_checklist_steps: checklistSummary.count
      }
    };

    res.json({ success: true, data: summary });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ========== 실무 경험 기반 세차장 필수 조건 (9가지) ==========
// 9. 사용자의 실제 9개 세차장 필수 조건 조회
router.get('/actual-requirements', (req, res) => {
  try {
    const requirements = regulationsDb.prepare(`
      SELECT id, requirement_number, title, description, details, critical_notes, source
      FROM carwash_actual_requirements
      ORDER BY requirement_number ASC
    `).all();

    if (requirements.length === 0) {
      return res.status(404).json({
        success: false,
        error: '실제 요구사항 데이터를 찾을 수 없습니다',
        note: '데이터베이스가 아직 준비되지 않았을 수 있습니다'
      });
    }

    res.json({
      success: true,
      source: '빅워시 운영 경험 기반 (신뢰도: ⭐⭐⭐⭐⭐)',
      total_requirements: requirements.length,
      data: requirements
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 특정 요구사항 상세 조회
router.get('/actual-requirements/:requirement_num', (req, res) => {
  try {
    const { requirement_num } = req.params;
    const requirement = regulationsDb.prepare(`
      SELECT * FROM carwash_actual_requirements
      WHERE requirement_number = ?
    `).get(parseInt(requirement_num));

    if (!requirement) {
      return res.status(404).json({
        success: false,
        error: `${requirement_num}번 요구사항을 찾을 수 없습니다`
      });
    }

    res.json({ success: true, data: requirement });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ========== 유역별 폐수처리 기준 ==========
// 10. 유역별 폐수처리 기준 조회
router.get('/wastewater-standards', (req, res) => {
  try {
    const { region_code, facility_type } = req.query;
    let sql = 'SELECT id, region_code, facility_type, capacity_min, capacity_max, material_requirement, maintenance_frequency, inspection_requirement, law_reference FROM regional_wastewater_standards WHERE 1=1';
    const params = [];

    if (region_code) {
      sql += ' AND region_code = ?';
      params.push(region_code);
    }

    if (facility_type) {
      sql += ' AND facility_type LIKE ?';
      params.push(`%${facility_type}%`);
    }

    sql += ' ORDER BY region_code, facility_type';

    const standards = regulationsDb.prepare(sql).all(...params);

    if (standards.length === 0) {
      return res.status(404).json({
        success: false,
        error: '해당 조건의 폐수처리 기준을 찾을 수 없습니다',
        hint: 'region_code: 11000(서울), 28000(인천), 41000(경기), 26000(부산), 30000(대전) 등'
      });
    }

    res.json({
      success: true,
      total_standards: standards.length,
      filters_applied: { region_code: region_code || 'all', facility_type: facility_type || 'all' },
      data: standards
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 특정 지역의 유분분리기 기준 조회
router.get('/wastewater-standards/:region_code', (req, res) => {
  try {
    const { region_code } = req.params;
    const standards = regulationsDb.prepare(`
      SELECT * FROM regional_wastewater_standards
      WHERE region_code = ?
      ORDER BY facility_type
    `).all(region_code);

    if (standards.length === 0) {
      return res.status(404).json({
        success: false,
        error: `${region_code} 지역의 폐수처리 기준을 찾을 수 없습니다`
      });
    }

    // 지역 코드 매핑
    const regionMap = {
      '11000': '서울', '28000': '인천', '41000': '경기',
      '26000': '부산', '27000': '대구', '31000': '울산', '47000': '경북', '48000': '경남',
      '30000': '대전', '36000': '세종', '43000': '충북', '44000': '충남',
      '29000': '광주', '45000': '전북', '46000': '전남', '50000': '제주'
    };

    res.json({
      success: true,
      region: regionMap[region_code] || region_code,
      region_code: region_code,
      total_standards: standards.length,
      data: standards
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
