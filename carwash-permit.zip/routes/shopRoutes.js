const express = require('express');
const crypto = require('crypto');
const db = require('../db/init');
const { generateOrderNumber } = require('../db/init');
const Logger = require('../utils/logger');

const router = express.Router();
const logger = new Logger('shopRoutes');

// ✅ P1-1: 에러 응답 표준화
function errorResponse(res, statusCode, code, message, errorId = null) {
  res.status(statusCode).json({
    success: false,
    code,
    message,
    errorId: process.env.NODE_ENV === 'development' ? errorId : undefined,
    timestamp: new Date().toISOString()
  });
}

// ============ 공개 API ============

// GET /api/shop/categories - 카테고리 목록
router.get('/categories', (req, res) => {
  try {
    const categories = db.prepare(`
      SELECT id, name, slug, sort_order
      FROM categories
      ORDER BY sort_order, id
    `).all();
    res.json({
      success: true,
      code: 'CATEGORIES_FOUND',
      data: categories
    });
  } catch (err) {
    const errorId = logger.logError('카테고리 조회 실패', err);
    errorResponse(res, 500, 'CATEGORY_FETCH_ERROR', '카테고리 조회에 실패했습니다', errorId);
  }
});

// GET /api/shop/products - 상품 목록 (필터, 검색, 페이지네이션)
router.get('/products', (req, res) => {
  try {
    const { category_id, search, page = 1, limit = 20 } = req.query;
    const offset = (Math.max(1, parseInt(page)) - 1) * Math.min(100, parseInt(limit));

    let sql = `
      SELECT
        p.id, p.category_id, p.name, p.description, p.price, p.stock,
        p.image_url, p.options, p.sort_order,
        c.name as category_name
      FROM products p
      JOIN categories c ON p.category_id = c.id
      WHERE p.is_active = 1
    `;
    const params = [];

    if (category_id) {
      sql += ' AND p.category_id = ?';
      params.push(parseInt(category_id));
    }

    if (search) {
      sql += ' AND p.name LIKE ?';
      params.push(`%${search}%`);
    }

    sql += ' ORDER BY p.sort_order, p.id LIMIT ? OFFSET ?';
    params.push(Math.min(100, parseInt(limit)), offset);

    const products = db.prepare(sql).all(...params);

    // 전체 개수 조회
    let countSql = 'SELECT COUNT(*) as count FROM products WHERE is_active = 1';
    const countParams = [];
    if (category_id) {
      countSql += ' AND category_id = ?';
      countParams.push(parseInt(category_id));
    }
    if (search) {
      countSql += ' AND name LIKE ?';
      countParams.push(`%${search}%`);
    }
    const totalCount = db.prepare(countSql).get(...countParams).count;

    res.json({
      success: true,
      code: 'PRODUCTS_FOUND',
      data: products,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total: totalCount,
        pages: Math.ceil(totalCount / parseInt(limit))
      }
    });
  } catch (err) {
    const errorId = `ERR-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
    console.error(`[${errorId}] 상품 목록 조회 실패:`, err.stack);
    errorResponse(res, 500, 'PRODUCT_LIST_ERROR', '상품 목록 조회에 실패했습니다', errorId);
  }
});

// GET /api/shop/products/:id - 상품 상세
router.get('/products/:id', (req, res) => {
  try {
    const { id } = req.params;
    const product = db.prepare(`
      SELECT
        p.*, c.name as category_name
      FROM products p
      JOIN categories c ON p.category_id = c.id
      WHERE p.id = ? AND p.is_active = 1
    `).get(id);

    if (!product) {
      return errorResponse(res, 404, 'PRODUCT_NOT_FOUND', '상품을 찾을 수 없습니다');
    }

    // options 문자열 → 배열
    try {
      product.options = JSON.parse(product.options || '[]');
    } catch (e) {
      product.options = [];
    }

    res.json({
      success: true,
      code: 'PRODUCT_FOUND',
      data: product
    });
  } catch (err) {
    const errorId = `ERR-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
    console.error(`[${errorId}] 상품 상세 조회 실패:`, err.stack);
    errorResponse(res, 500, 'PRODUCT_DETAIL_ERROR', '상품 조회에 실패했습니다', errorId);
  }
});

// POST /api/shop/orders - 주문 생성
router.post('/orders', (req, res) => {
  try {
    const { customer_name, customer_phone, customer_addr, memo, items } = req.body;

    // ✅ P1-2: 유효성 검사 - 표준화된 에러 응답
    if (!customer_name || !customer_phone || !customer_addr || !items || items.length === 0) {
      return errorResponse(res, 400, 'VALIDATION_ERROR', '필수 정보가 부족합니다 (이름, 전화, 주소, 상품)');
    }

    // ✅ P1-2: 상품 존재 여부 미리 검증
    for (const item of items) {
      if (!item.product_id || !item.quantity) {
        return errorResponse(res, 400, 'INVALID_ITEM', '상품 ID와 수량이 필수입니다');
      }
      const product = db.prepare('SELECT id FROM products WHERE id = ?').get(item.product_id);
      if (!product) {
        return errorResponse(res, 404, 'PRODUCT_NOT_FOUND', `상품 ID ${item.product_id}를 찾을 수 없습니다`);
      }
    }

    // 트랜잭션으로 주문과 주문아이템 동시 저장
    const insertOrder = db.transaction((orderData) => {
      const { customer_name, customer_phone, customer_addr, memo, items } = orderData;

      // 주문 총액 계산
      let total = 0;
      const orderItems = [];
      for (const item of items) {
        const product = db.prepare('SELECT id, name, price FROM products WHERE id = ?').get(item.product_id);
        if (!product) {
          throw new Error(`상품 ${item.product_id}를 찾을 수 없습니다`);
        }
        const subtotal = product.price * item.quantity;
        total += subtotal;
        orderItems.push({
          product_id: product.id,
          product_name: product.name,
          unit_price: product.price,
          quantity: item.quantity,
          option_value: item.option || null,
          subtotal: subtotal
        });
      }

      // 주문 번호 생성
      const orderNumber = generateOrderNumber();

      // 주문 저장
      const result = db.prepare(`
        INSERT INTO orders
        (order_number, customer_name, customer_phone, customer_addr, memo, total_price, status)
        VALUES (?, ?, ?, ?, ?, ?, 'pending')
      `).run(orderNumber, customer_name, customer_phone, customer_addr, memo || '', total);

      const orderId = result.lastInsertRowid;

      // 주문아이템 저장
      const insertItem = db.prepare(`
        INSERT INTO order_items
        (order_id, product_id, product_name, unit_price, quantity, option_value, subtotal)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `);

      orderItems.forEach(item => {
        insertItem.run(
          orderId,
          item.product_id,
          item.product_name,
          item.unit_price,
          item.quantity,
          item.option_value,
          item.subtotal
        );
      });

      return { orderId, orderNumber, total };
    });

    const result = insertOrder({ customer_name, customer_phone, customer_addr, memo, items });

    res.status(201).json({
      success: true,
      code: 'ORDER_CREATED',
      data: {
        orderId: result.orderId,
        orderNumber: result.orderNumber,
        totalPrice: result.total,
        status: 'pending'
      }
    });
  } catch (err) {
    const errorId = `ERR-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
    console.error(`[${errorId}] 주문 생성 실패:`, err.stack);
    errorResponse(res, 500, 'ORDER_CREATE_ERROR', '주문 생성에 실패했습니다', errorId);
  }
});

// GET /api/shop/orders/:orderNumber - 주문 조회
router.get('/orders/:orderNumber', (req, res) => {
  try {
    const { orderNumber } = req.params;

    // ✅ P1-2: 파라미터 검증
    if (!orderNumber || typeof orderNumber !== 'string') {
      return errorResponse(res, 400, 'INVALID_ORDER_NUMBER', '유효한 주문번호가 필요합니다');
    }

    const order = db.prepare(`
      SELECT * FROM orders WHERE order_number = ?
    `).get(orderNumber);

    if (!order) {
      return errorResponse(res, 404, 'ORDER_NOT_FOUND', '주문을 찾을 수 없습니다');
    }

    const items = db.prepare(`
      SELECT * FROM order_items WHERE order_id = ?
    `).all(order.id);

    res.json({
      success: true,
      code: 'ORDER_FOUND',
      data: {
        ...order,
        items: items
      }
    });
  } catch (err) {
    const errorId = `ERR-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
    console.error(`[${errorId}] 주문 조회 실패:`, err.stack);
    errorResponse(res, 500, 'ORDER_FETCH_ERROR', '주문 조회에 실패했습니다', errorId);
  }
});

module.exports = router;
