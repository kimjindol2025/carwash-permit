# 🎯 carwash-permit 완전 API 통합 가이드 (2026-03-30)

## 📊 전체 API 구조 (25개 엔드포인트)

### API 분류

| 분류 | 개수 | 설명 |
|------|------|------|
| 🛍️ **쇼핑몰** | 5개 | 공개 (상품/주문) |
| 👨‍💼 **어드민** | 7개 | 인증 필수 (상품/주문 관리) |
| ⚖️ **허가 규정** | 6개 | 법령 및 요구사항 |
| 🔄 **워크플로우** | 7개 | **NEW** - 순차적 허가 체크 |
| **합계** | **25개** | ✅ 모두 프로덕션 레디 |

---

## 🔄 워크플로우 API (NEW - 7개)

**경로**: `/api/workflow/`
**특징**: 사용자가 순서대로 진행하는 과정을 추적 & 저장

| 메서드 | 엔드포인트 | 설명 | 상태 |
|--------|-----------|------|------|
| POST | `/start` | 새 워크플로우 시작 (sessionId 발급) | ✅ |
| GET | `/:sessionId/status` | 진행 상황 및 진행도 확인 | ✅ |
| POST | `/:sessionId/step/1` | Step 1: 지번 검색 저장 | ✅ |
| POST | `/:sessionId/step/2` | Step 2: 토지이용 확인 (VWorld API) | ✅ |
| POST | `/:sessionId/step/3` | Step 3: 건축물 확인 | ✅ |
| POST | `/:sessionId/step/4` | Step 4: 최종 허가 체크 + 리포트 생성 | ✅ |
| GET | `/:sessionId/report` | 생성된 최종 리포트 조회 | ✅ |

### 워크플로우 흐름도

```
시작 → Step 1 지번 → Step 2 토지 → Step 3 건축 → Step 4 허가 → 리포트
(sessionId)  ↓       ↓         ↓        ↓       ↓
            저장    자동조회   입력    종합판정 생성
                   (VWorld)
```

### 데이터 흐름

```javascript
// 세션 시작
POST /api/workflow/start
↓ sessionId: "dd79adf7..."

// Step 1: 주소 저장
POST /api/workflow/dd79adf7.../step/1
Body: { roadAddr, sigunguCd, bjdongCd, pnu }
↓ step1_completed = 1

// Step 2: VWorld API로 자동 조회
POST /api/workflow/dd79adf7.../step/2
↓ step2_zone_type = "제2종일반주거지역"

// Step 3: 건축물 정보 저장
POST /api/workflow/dd79adf7.../step/3
Body: { buildingName, purposeNm, floorArea }
↓ step3_completed = 1

// Step 4: 최종 판정 (모든 정보 종합)
POST /api/workflow/dd79adf7.../step/4
↓ final_report = { address, zoneType, building, permitResult, conditions, ... }

// 리포트 조회
GET /api/workflow/dd79adf7.../report
↓ 최종 리포트 반환 (다운로드/인쇄 가능)
```

---

## 🛍️ 쇼핑몰 API (5개)

**경로**: `/api/shop/`

| 메서드 | 엔드포인트 | 설명 | 상태 |
|--------|-----------|------|------|
| GET | `/categories` | 카테고리 목록 | ✅ |
| GET | `/products?category_id=&search=` | 상품 목록 (필터, 검색) | ✅ |
| GET | `/products/:id` | 상품 상세 | ✅ |
| POST | `/orders` | 주문 생성 (트랜잭션) | ✅ |
| GET | `/orders/:orderNumber` | 주문 조회 | ✅ |

**데이터:**
```
카테고리: 4개 (세차용품, 세차장비, 컨설팅, 기타)
상품: 8개 (폼, 왁스, 건조기, 분무기, 상담, 사업계획서, 가이드, 앱)
```

---

## 👨‍💼 어드민 API (7개)

**경로**: `/api/admin/`
**인증**: Bearer 토큰 (Authorization 헤더)

| 메서드 | 엔드포인트 | 설명 | 인증 | 상태 |
|--------|-----------|------|------|------|
| POST | `/login` | 로그인 (패스워드) | ❌ | ✅ |
| GET | `/products` | 상품 목록 (전체) | ✅ | ✅ |
| POST | `/products` | 상품 추가 (이미지) | ✅ | ✅ |
| PUT | `/products/:id` | 상품 수정 | ✅ | ✅ |
| DELETE | `/products/:id` | 상품 삭제 | ✅ | ✅ |
| GET | `/orders` | 주문 목록 (상태 필터) | ✅ | ✅ |
| PATCH | `/orders/:id/status` | 주문 상태 변경 | ✅ | ✅ |

**인증 흐름:**
```
1. POST /api/admin/login { password: "carwash2024" }
   ↓ token 발급 (32바이트 hex, 1시간 유효)

2. 모든 어드민 API에서
   Header: Authorization: Bearer {token}
   ↓ 검증 후 작업 실행
```

---

## ⚖️ 허가 규정 API (6개)

**경로**: `/api/regulations/`

| 메서드 | 엔드포인트 | 설명 | 상태 |
|--------|-----------|------|------|
| GET | `/actual-requirements` | 9개 실제 요구사항 목록 | ✅ |
| GET | `/actual-requirements/:num` | 특정 요구사항 상세 | ✅ |
| GET | `/wastewater-standards` | 유역별 폐수 기준 전체 | ✅ |
| GET | `/wastewater-standards/:code` | 지역별 폐수 기준 | ✅ |
| POST | `/permit/check` | 허가 판정 (용도지역 기반) | ✅ |
| GET | `/offices?region=...` | 관공서 연락처 | ✅ |

**데이터:**
```
9개 실제 요구사항 (빅워시 운영 경험)
  1. 토지 용도지역 확인
  2. 건물 용도 (자동차관련시설)
  3. 하수도/우수 연결
  4. 폐수처리시설 (필수)
  5. 폐수배출 신고 vs 허가
  6. 설치 기한 (1년)
  7. 등록업체만 가능
  8. 설치완료 신고
  9. 운영 (직영 vs 위탁)

12개 유역별 폐수 기준
  - 한강 (서울, 경기, 강원, 인천)
  - 낙동강 (부산, 대구, 경북, 경남)
  - 금강 (대전, 충북, 충남)
```

---

## 📊 데이터베이스 (2개)

### shop.db
```sql
categories (4)
products (8)
orders
order_items
workflow_sessions  ← NEW (워크플로우 추적)
```

### regulations.db
```sql
carwash_actual_requirements (9)
regional_wastewater_standards (12)
land_use_zones
legal_frameworks
local_ordinances
...
```

---

## 🚀 통합 워크플로우 예제

### 클라이언트 코드 (JavaScript)

```javascript
// ============ 전체 워크플로우 ============

class CarwashPermitWorkflow {
  constructor() {
    this.sessionId = null;
  }

  // 1단계: 시작
  async start() {
    const res = await fetch('/api/workflow/start', { method: 'POST' });
    const { sessionId } = await res.json();
    this.sessionId = sessionId;
    console.log('✅ 워크플로우 시작:', sessionId);
  }

  // 2단계: 주소 검색 (다음 우편번호)
  async searchAddress() {
    return new Promise((resolve) => {
      new daum.Postcode({
        oncomplete: async (data) => {
          const res = await fetch(`/api/workflow/${this.sessionId}/step/1`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              roadAddr: data.roadAddress,
              sigunguCd: data.sigunguCode,
              bjdongCd: data.bcode.slice(5),
              pnu: data.bcode + '...'
            })
          });
          const result = await res.json();
          console.log('✅ Step 1 완료:', result.message);
          resolve(result);
        }
      }).open();
    });
  }

  // 3단계: 토지이용 확인
  async confirmLandUse() {
    const res = await fetch(`/api/workflow/${this.sessionId}/step/2`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({})
    });
    const { data, permitPreview } = await res.json();
    console.log('✅ Step 2 완료:', data.zoneType, '→', permitPreview.result);
    return { data, permitPreview };
  }

  // 4단계: 건축물 확인
  async confirmBuilding(buildingInfo) {
    const res = await fetch(`/api/workflow/${this.sessionId}/step/3`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(buildingInfo)
    });
    const result = await res.json();
    console.log('✅ Step 3 완료:', result.message);
    return result;
  }

  // 5단계: 최종 허가 체크
  async checkPermit() {
    const res = await fetch(`/api/workflow/${this.sessionId}/step/4`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({})
    });
    const { report, nextAction } = await res.json();
    console.log('✅ Step 4 완료:', report.permitResult);
    return { report, nextAction };
  }

  // 최종 리포트
  async getReport() {
    const res = await fetch(`/api/workflow/${this.sessionId}/report`);
    const { data } = await res.json();
    return data;
  }

  // 진행 상황
  async getStatus() {
    const res = await fetch(`/api/workflow/${this.sessionId}/status`);
    const status = await res.json();
    console.log(`진행도: ${status.progress.percentage}%`);
    return status;
  }
}

// 사용 예
(async () => {
  const workflow = new CarwashPermitWorkflow();

  await workflow.start();                           // Step 0
  await workflow.searchAddress();                   // Step 1
  const { data } = await workflow.confirmLandUse(); // Step 2
  await workflow.confirmBuilding({
    buildingName: '테스트빌딩',
    purposeNm: '제1종근린생활시설'
  });                                               // Step 3
  const { report } = await workflow.checkPermit(); // Step 4

  console.log('최종 결과:', report.permitResult);
  console.log('다음 단계:', report.nextSteps);
})();
```

---

## 📋 API 테스트 체크리스트

```bash
# 1️⃣ 워크플로우 시작
curl -X POST http://localhost:40090/api/workflow/start
# 응답: { sessionId: "..." }

# 2️⃣ Step 1
curl -X POST http://localhost:40090/api/workflow/{sessionId}/step/1 \
  -d '{"roadAddr":"...", "sigunguCd":"11680"}'

# 3️⃣ Step 2
curl -X POST http://localhost:40090/api/workflow/{sessionId}/step/2

# 4️⃣ Step 3
curl -X POST http://localhost:40090/api/workflow/{sessionId}/step/3 \
  -d '{"buildingName":"..."}'

# 5️⃣ Step 4
curl -X POST http://localhost:40090/api/workflow/{sessionId}/step/4

# 6️⃣ 리포트
curl http://localhost:40090/api/workflow/{sessionId}/report

# 7️⃣ 쇼핑몰 테스트
curl http://localhost:40090/api/shop/categories
curl http://localhost:40090/api/shop/products

# 8️⃣ 어드민 로그인
curl -X POST http://localhost:40090/api/admin/login \
  -d '{"password":"carwash2024"}'

# 9️⃣ 규정 API
curl http://localhost:40090/api/regulations/actual-requirements
curl http://localhost:40090/api/regulations/wastewater-standards
```

---

## 📈 배포 상태

| 항목 | 상태 | 상세 |
|------|------|------|
| 로컬 | ✅ Online | http://localhost:40090 |
| 프로덕션 | ✅ Online | https://carwash.dclub.kr |
| PM2 프로세스 | ✅ 실행중 | ID: 8, 메모리: 57.4MB |
| DB 테이블 | ✅ 완성 | shop.db + regulations.db |
| API 엔드포인트 | ✅ 25개 | 모두 정상 작동 |

---

## 🔐 보안 체크리스트

- [x] Bearer 토큰 인증 (어드민 API)
- [x] 세션 ID 암호화 (32바이트 hex)
- [x] SQL Injection 방지 (Prepared Statement)
- [x] CORS 설정 (공개 API)
- [x] 이미지 파일 검증 (MIME type)
- [x] 파일 크기 제한 (5MB)

---

## 📚 문서

| 문서 | 설명 |
|------|------|
| [WORKFLOW_API_GUIDE.md](./WORKFLOW_API_GUIDE.md) | 워크플로우 상세 가이드 |
| [API_INTEGRATION_COMPLETE.md](./API_INTEGRATION_COMPLETE.md) | 쇼핑몰 API 가이드 |
| [LEGAL_FRAMEWORKS_API_GUIDE.md](./LEGAL_FRAMEWORKS_API_GUIDE.md) | 허가 규정 API 가이드 |
| [PROJECT_OVERVIEW.md](./PROJECT_OVERVIEW.md) | 프로젝트 개요 |

---

## ✅ 완료 항목

- [x] 쇼핑몰 API (5개) ✅
- [x] 어드민 API (7개) ✅
- [x] 허가 규정 API (6개) ✅
- [x] **워크플로우 API (7개) ✅ NEW**
- [x] DB 스키마 (workflow_sessions 추가)
- [x] 데이터 검증 (모든 API 테스트 완료)
- [x] 배포 (PM2 실행중)
- [x] 문서화 (4개 가이드)

---

## 🚀 다음 단계 (선택사항)

1. **프론트엔드 통합**: index.html에 워크플로우 UI 구현
2. **PDF 리포트**: 최종 리포트 PDF 생성
3. **이메일 전송**: 리포트 자동 메일링
4. **분석 대시보드**: 워크플로우 통계 시각화
5. **결제 통합**: 쇼핑몰 결제 시스템

---

**버전**: v2.0 (워크플로우 완전 통합)
**마지막 업데이트**: 2026-03-30 23:52
**상태**: 🟢 **Production Ready**
