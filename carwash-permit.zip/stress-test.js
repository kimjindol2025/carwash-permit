/**
 * 스트레스 테스트 - 세차장 허가 API
 *
 * 테스트 항목:
 * 1. 카테고리 조회 (읽기 집약적)
 * 2. 상품 목록 조회 (DB 쿼리)
 * 3. 주문 생성 (쓰기 작업)
 * 4. 동시 요청 처리
 */

const http = require('http');

const BASE_URL = 'http://localhost:40090';

// 테스트 설정
const TESTS = [
  {
    name: '카테고리 조회',
    method: 'GET',
    path: '/api/shop/categories',
    requests: 100,
    concurrent: 10
  },
  {
    name: '상품 목록 조회',
    method: 'GET',
    path: '/api/shop/products?limit=20',
    requests: 50,
    concurrent: 5
  },
  {
    name: '주문 생성',
    method: 'POST',
    path: '/api/shop/orders',
    body: {
      customer_name: '테스트 고객',
      customer_phone: '010-1234-5678',
      customer_addr: '서울시 강남구',
      items: [
        { product_id: 1, quantity: 1 }
      ]
    },
    requests: 20,
    concurrent: 2
  }
];

class StressTest {
  constructor(test) {
    this.test = test;
    this.results = {
      success: 0,
      error: 0,
      totalTime: 0,
      responseTimes: [],
      errors: []
    };
  }

  makeRequest() {
    return new Promise((resolve) => {
      const url = new URL(this.test.path, BASE_URL);
      const startTime = Date.now();

      const options = {
        hostname: url.hostname,
        port: url.port,
        path: url.pathname + url.search,
        method: this.test.method,
        headers: {
          'Content-Type': 'application/json'
        }
      };

      const req = http.request(options, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          const responseTime = Date.now() - startTime;
          this.results.responseTimes.push(responseTime);
          this.results.totalTime += responseTime;

          if (res.statusCode >= 200 && res.statusCode < 300) {
            this.results.success++;
          } else {
            this.results.error++;
            this.results.errors.push({
              status: res.statusCode,
              time: responseTime
            });
          }
          resolve();
        });
      });

      req.on('error', (err) => {
        this.results.error++;
        this.results.errors.push(err.message);
        resolve();
      });

      if (this.test.body) {
        req.write(JSON.stringify(this.test.body));
      }
      req.end();
    });
  }

  async run() {
    console.log(`\n📊 테스트: ${this.test.name}`);
    console.log(`   총 요청: ${this.test.requests}, 동시 요청: ${this.test.concurrent}`);

    const start = Date.now();
    const queue = [];
    let completed = 0;

    for (let i = 0; i < this.test.requests; i++) {
      const promise = this.makeRequest().then(() => {
        completed++;
        process.stdout.write(`\r   진행률: ${completed}/${this.test.requests}`);
      });

      queue.push(promise);

      if (queue.length >= this.test.concurrent) {
        await Promise.race(queue);
        queue.splice(queue.findIndex(p => p.resolved), 1);
      }
    }

    await Promise.all(queue);
    const totalTime = Date.now() - start;

    // 결과 계산
    const responseTimes = this.results.responseTimes.sort((a, b) => a - b);
    const min = responseTimes[0];
    const max = responseTimes[responseTimes.length - 1];
    const avg = this.results.totalTime / this.test.requests;
    const p50 = responseTimes[Math.floor(responseTimes.length * 0.5)];
    const p95 = responseTimes[Math.floor(responseTimes.length * 0.95)];
    const p99 = responseTimes[Math.floor(responseTimes.length * 0.99)];
    const rps = (this.test.requests / totalTime * 1000).toFixed(2);

    console.log(`\n   ✅ 결과:`);
    console.log(`      성공: ${this.results.success} | 실패: ${this.results.error}`);
    console.log(`      응답시간: min=${min}ms, avg=${avg.toFixed(2)}ms, max=${max}ms`);
    console.log(`      백분위: p50=${p50}ms, p95=${p95}ms, p99=${p99}ms`);
    console.log(`      처리량: ${rps} req/s`);
    console.log(`      총 소요시간: ${totalTime}ms`);

    if (this.results.errors.length > 0) {
      console.log(`      에러: ${this.results.errors.length}개`);
    }

    return {
      test: this.test.name,
      success: this.results.success,
      error: this.results.error,
      min,
      max,
      avg: parseFloat(avg.toFixed(2)),
      p95,
      p99,
      rps: parseFloat(rps)
    };
  }
}

async function runAllTests() {
  console.log('🚀 세차장 허가 API 스트레스 테스트 시작');
  console.log(`   대상: ${BASE_URL}`);
  console.log(`   테스트: ${TESTS.length}개`);

  const results = [];

  for (const test of TESTS) {
    const tester = new StressTest(test);
    const result = await tester.run();
    results.push(result);
  }

  // 최종 결과
  console.log('\n\n📈 최종 결과 요약');
  console.log('═'.repeat(80));
  console.log(`${'테스트'.padEnd(20)} | ${'성공'.padEnd(8)} | ${'실패'.padEnd(8)} | ${'평균(ms)'.padEnd(12)} | ${'P95(ms)'.padEnd(12)} | ${'RPS'.padEnd(8)}`);
  console.log('─'.repeat(80));

  results.forEach(r => {
    console.log(`${r.test.padEnd(20)} | ${r.success.toString().padEnd(8)} | ${r.error.toString().padEnd(8)} | ${r.avg.toString().padEnd(12)} | ${r.p95.toString().padEnd(12)} | ${r.rps.toString().padEnd(8)}`);
  });

  console.log('═'.repeat(80));

  const totalSuccess = results.reduce((a, r) => a + r.success, 0);
  const totalError = results.reduce((a, r) => a + r.error, 0);
  const avgRps = (results.reduce((a, r) => a + r.rps, 0) / results.length).toFixed(2);

  console.log(`\n✅ 전체 성공: ${totalSuccess}`);
  console.log(`❌ 전체 실패: ${totalError}`);
  console.log(`📊 평균 처리량: ${avgRps} req/s`);

  if (totalError === 0) {
    console.log('\n🎉 모든 테스트 통과!');
  } else {
    console.log(`\n⚠️  ${totalError}개 요청 실패`);
  }
}

runAllTests().catch(err => {
  console.error('테스트 실행 중 오류:', err);
  process.exit(1);
});
