const fs = require('fs');
const path = require('path');
const readline = require('readline');
const iconv = require('iconv-lite');
require('dotenv').config();

const db = require('./db/init');

// CSV 파일 경로
const csvFile = '/home/kimjin/다운로드/개발행위허가정보_20260316_전국.csv';

// ⭐ P1-1: 테이블은 db/schema.sql에서 생성됨 (중복 제거)
// CSV 파일 로드 (테이블 생성은 스킵)
async function loadCSV() {
  return new Promise((resolve, reject) => {
    let count = 0;
    let skipCount = 0;
    const insertStmt = db.prepare(`
      INSERT OR IGNORE INTO development_permits
      (pnu, location_name, land_type, area, zone_type, zone_district, local_code, local_name, dev_code, dev_name, main_dev_code, main_dev_name, apply_date, permit_date, dev_purpose)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    // EUC-KR 인코딩된 파일을 UTF-8로 변환
    const fileStream = fs.createReadStream(csvFile);
    const convertStream = fileStream.pipe(iconv.decodeStream('EUC-KR'));
    const rl = readline.createInterface({
      input: convertStream,
      crlfDelay: Infinity
    });

    let isHeader = true;

    rl.on('line', (line) => {
      if (isHeader) {
        isHeader = false;
        return;
      }

      try {
        // CSV 파싱 (EUC-KR 인코딩)
        const cols = line.split(',');

        if (cols.length < 15) return;

        const pnu = cols[0].trim();
        const locationName = cols[1].trim();
        const landType = cols[2].trim();
        const area = parseFloat(cols[3].trim()) || 0;
        const zoneType = cols[4].trim();
        const zoneDistrict = cols[5].trim();
        const localCode = cols[6].trim();
        const localName = cols[7].trim();
        const devCode = cols[8].trim();
        const devName = cols[9].trim();
        const mainDevCode = cols[10].trim();
        const mainDevName = cols[11].trim();
        const applyDate = cols[12].trim();
        const permitDate = cols[13].trim();
        const devPurpose = cols[14].trim();

        // 양주시(31) 또는 경기도 전체(41)로 필터링
        if (!localCode.startsWith('31') && !localCode.startsWith('41')) {
          skipCount++;
          return;
        }

        insertStmt.run(
          pnu, locationName, landType, area, zoneType, zoneDistrict,
          localCode, localName, devCode, devName, mainDevCode, mainDevName,
          applyDate, permitDate, devPurpose
        );

        count++;
        if (count % 1000 === 0) {
          console.log(`⏳ 처리 중... ${count}개 (스킵: ${skipCount}개)`);
        }
      } catch (err) {
        console.error('❌ 라인 처리 오류:', err.message);
      }
    });

    rl.on('close', () => {
      console.log(`\n✅ 완료!`);
      console.log(`📊 삽입: ${count}개`);
      console.log(`⏭️  스킵: ${skipCount}개 (지역 필터링)`);
      resolve();
    });

    rl.on('error', reject);
  });
}

async function main() {
  try {
    console.log('🚀 개발행위허가정보 데이터베이스 로딩 시작...\n');

    // ⭐ P1-1: 테이블 생성은 schema.sql에서 수행됨
    await loadCSV();

    // 통계 확인
    const stats = db.prepare('SELECT COUNT(*) as count FROM development_permits').get();
    console.log(`\n📈 데이터베이스 통계:`);
    console.log(`   총 레코드: ${stats.count}개`);

    // 지역별 통계
    const byLocal = db.prepare(`
      SELECT local_name, COUNT(*) as count
      FROM development_permits
      GROUP BY local_name
      ORDER BY count DESC
      LIMIT 5
    `).all();

    console.log(`\n🏙️  상위 5개 지역:`);
    byLocal.forEach(row => {
      console.log(`   ${row.local_name}: ${row.count}개`);
    });

    // 용도지역별 통계
    const byZone = db.prepare(`
      SELECT zone_type, COUNT(*) as count
      FROM development_permits
      WHERE zone_type != ''
      GROUP BY zone_type
      ORDER BY count DESC
      LIMIT 5
    `).all();

    console.log(`\n📍 상위 용도지역:`);
    byZone.forEach(row => {
      console.log(`   ${row.zone_type}: ${row.count}개`);
    });

    console.log('\n✅ 데이터 로딩 완료!\n');
  } catch (err) {
    console.error('❌ 오류:', err);
    process.exit(1);
  }
}

// ⭐ P1-1: 모듈로 export (init.js에서 호출 가능)
module.exports = { loadCSV, main };

// 직접 실행 시: node load-dev-data.js
if (require.main === module) {
  main();
}
