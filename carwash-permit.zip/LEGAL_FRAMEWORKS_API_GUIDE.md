# 🏛️ 5개 법령 통합 API 가이드

**생성일**: 2026-03-30
**데이터 총량**: 90개 항목 (32 도시계획법 + 20 도로법 + 25 상하수도법 + 4 환경법 + 9 체크리스트)
**저장소**: `regulations.db` (SQLite)

---

## 📋 API 엔드포인트 목록

### 1️⃣ 법령 메타데이터 조회
```bash
GET /api/regulations/legal-frameworks
```

**응답 예시**:
```json
{
  "success": true,
  "data": [
    {
      "framework_name": "도시계획법",
      "short_name": "도계법",
      "official_name": "국토의 계획 및 이용에 관한 법률",
      "law_number": "법률 제18949호",
      "enforcement_date": "2023-03-28",
      "description": "국토 이용의 기본 원칙 및 도시계획 관련 규정",
      "carwash_relevance": "용도지역 확인, 용도변경 절차, 건폐율/용적률 제한"
    }
  ]
}
```

**용도**: 5개 법령의 기본 정보 확인

---

### 2️⃣ 도시계획법 기준 조회
```bash
GET /api/regulations/frameworks/urban-planning
GET /api/regulations/frameworks/urban-planning?category=용도지역_허용
```

**쿼리 파라미터**:
- `category`: 용도지역_허용, 용도지역_조건부, 용도지역_불가, 용도변경_절차, 건폐율_기준, 용적률_기준, 공공시설협력금

**응답 데이터**:
- 용도지역 분류 (32개 항목)
- 용도변경 절차 단계별 설명
- 건폐율/용적률 지역별 기준
- 공공시설협력금 산정 방식

**사용 예시**:
```bash
# 모든 도시계획법 기준 조회
curl http://localhost:40090/api/regulations/frameworks/urban-planning

# 용도지역 허용 항목만
curl http://localhost:40090/api/regulations/frameworks/urban-planning?category=용도지역_허용

# 용도변경 절차
curl http://localhost:40090/api/regulations/frameworks/urban-planning?category=용도변경_절차
```

---

### 3️⃣ 도로법 기준 조회
```bash
GET /api/regulations/frameworks/road-access
GET /api/regulations/frameworks/road-access?category=진출입_기준
```

**쿼리 파라미터**:
- `category`: 진출입_기준, 진출입_제한, 도로점용허가, 교통영향평가

**응답 데이터**:
- 진출입구 너비/거리 규정
- 도로 종류별 제한사항 (고속도로, 간선도로 등)
- 도로점용허가 절차 및 료금
- 교통영향평가 대상 판정 기준 (20개 항목)

**사용 예시**:
```bash
# 모든 도로법 기준
curl http://localhost:40090/api/regulations/frameworks/road-access

# 진출입 기준만
curl http://localhost:40090/api/regulations/frameworks/road-access?category=진출입_기준
```

---

### 4️⃣ 상하수도법 기준 조회
```bash
GET /api/regulations/frameworks/water-sewerage
GET /api/regulations/frameworks/water-sewerage?category=상수도_연결
```

**쿼리 파라미터**:
- `category`: 상수도_연결, 상수도_공사비, 하수도_연결, 수질_기준

**응답 데이터**:
- 상수도 본관 거리별 비용 분담 (100m당 37,000~103,000원)
- 하수도 공공/개별 선택 기준
- 공공하수도 가입금 범위
- 개별폐수처리시설 비용 (5,000만원~1억원)
- 수질검사 항목별 기준

**사용 예시**:
```bash
# 상수도 연결 비용
curl http://localhost:40090/api/regulations/frameworks/water-sewerage?category=상수도_연결

# 하수도 처리 방식
curl http://localhost:40090/api/regulations/frameworks/water-sewerage?category=하수도_연결
```

---

### 5️⃣ 환경법(물환경보전법) 배출기준 조회
```bash
GET /api/regulations/frameworks/environmental-emission
GET /api/regulations/frameworks/environmental-emission?basin_name=한강유역환경청(최엄격)
GET /api/regulations/frameworks/environmental-emission?region_code=11000
```

**쿼리 파라미터**:
- `basin_name`: 한강유역환경청(최엄격), 낙동강유역환경청(상수원보호), 금강유역환경청, 영산강·섬진강유역환경청
- `region_code`: 지역 코드 (11000 서울, 26000 부산 등)

**응답 데이터** (4개 유역):
```json
{
  "region_name": "서울/경기/인천/강원",
  "basin_name": "한강유역환경청(최엄격)",
  "region_code": "11000,28000,41000",
  "oil_standard_mg_l": 1.0,
  "facility_requirement": "코알레서 또는 익스트랙션 타입 (효율 85% 이상)",
  "maintenance_requirement": "월 1회 이상",
  "inspection_requirement": "분기 1회 정기점검, 폐유 처리 기록 필수"
}
```

**유분 배출 기준** (핵심):
```
한강        → 1.0 mg/L   (최엄격)
낙동강      → 1.5 mg/L   (상수원 보호)
금강/영산강 → 2.0 mg/L   (표준)
```

**사용 예시**:
```bash
# 모든 유역 기준
curl http://localhost:40090/api/regulations/frameworks/environmental-emission

# 한강 기준
curl http://localhost:40090/api/regulations/frameworks/environmental-emission?basin_name=한강유역환경청\(최엄격\)

# 경기도(코드 41000)
curl http://localhost:40090/api/regulations/frameworks/environmental-emission?region_code=41000
```

---

### 6️⃣ 세차장 9단계 통합 체크리스트
```bash
GET /api/regulations/frameworks/carwash-checklist
GET /api/regulations/frameworks/carwash-checklist/1
```

**전체 단계**:
1. 토지용도 확인 (도시계획법) - 1-2주, 무료
2. 건물용도 판정 (건축법) - 2-3주, 무료
3. 용도변경 심의 (도시계획법) - 3-4개월, 1,500~3,000만원
4. 진출입로 확보 (도로법) - 즉시, 도로점용료
5. 상수도 연결 (상하수도법) - 3-4주, 100m당 100~300만원
6. 하수도 처리 (상하수도법) - 4주/6개월, 1,000~1억원
7. 폐수배출신고 (수질오염방지법) - 2-3주, 30만원
8. 건축신고/허가 (건축법) - 1-4주, 100만원
9. 운영 기준 준수 (수질오염방지법) - 지속 운영, 100만원/연

**응답 예시** (단계 1):
```json
{
  "step_num": 1,
  "step_name": "토지용도 확인",
  "related_law": "도시계획법",
  "check_item": "토지 용도지역 확인 (불가능 지역 필터링)",
  "requirement": "상업/공업/준주거/1/3종주거 지역만 가능",
  "approval_body": "시/군청 도시계획부",
  "duration_estimate": "1-2주",
  "cost_estimate": "무료(토지이용계획확인원 발급료 3만원)"
}
```

**사용 예시**:
```bash
# 모든 단계
curl http://localhost:40090/api/regulations/frameworks/carwash-checklist | jq '.data'

# 특정 단계 (3번)
curl http://localhost:40090/api/regulations/frameworks/carwash-checklist/3
```

---

### 7️⃣ 통합 법령 요약
```bash
GET /api/regulations/frameworks/summary
```

**응답 데이터**:
- 5개 법령 메타데이터
- 각 법령별 데이터 통계
  - 도시계획법: 32개 항목
  - 도로법: 20개 항목
  - 상하수도법: 25개 항목
  - 환경법: 4개 유역 기준
  - 체크리스트: 9단계

**사용 예시**:
```bash
curl http://localhost:40090/api/regulations/frameworks/summary | jq '.data.data_statistics'
```

---

## 📊 DB 테이블 구조

### 1. `legal_framework_metadata` (5행)
```sql
framework_name      -- 도시계획법, 도로법, 상하수도법, 물환경보전법, 환경정책기본법
short_name         -- 도계법, 도법, 상도법, 물보법, 환기법
official_name      -- 정식 명칭
law_number         -- 법률 번호
enforcement_date   -- 시행일
description        -- 법령 설명
carwash_relevance  -- 세차장과의 연관성
```

### 2. `urban_planning_standards` (32행)
```sql
category    -- 용도지역_허용, 용도지역_조건부, 용도지역_불가, 용도변경_절차, 건폐율_기준, 용적률_기준, 공공시설협력금
item        -- 상업지역_전체, 2종_일반주거지역, 용도변경_단계1, 상업지역_중심 등
detail      -- 지역 설명
requirement -- 세차장 가능 여부 및 조건
reference   -- 법령 조항 및 근거
```

### 3. `road_access_standards` (20행)
```sql
category    -- 진출입_기준, 진출입_제한, 도로점용허가, 교통영향평가
item        -- 진출입구_너비, 고속도로, 점용_허가기간, 평가_대상_일반 등
detail      -- 상세 설명
requirement -- 규정 내용
unit_cost   -- 비용 정보 (있는 경우)
reference   -- 법령 근거
```

### 4. `water_sewerage_standards` (25행)
```sql
category    -- 상수도_연결, 상수도_공사비, 하수도_연결, 수질_기준
item        -- 상수도_필수, 거리_100m이내, 공공하수도_연결, 자체검사 등
detail      -- 상세 조건
requirement -- 규정 사항
unit_cost   -- 금액/단가
reference   -- 법령 근거
```

### 5. `environmental_emission_standards` (4행)
```sql
region_name         -- 서울/경기/인천/강원 등
basin_name          -- 한강유역환경청(최엄격) 등
region_code         -- 11000, 26000 등 (콤마로 구분된 복수)
oil_standard_mg_l   -- 유분 기준 (1.0, 1.5, 2.0)
facility_requirement-- 폐수처리시설 사양
maintenance_requirement -- 유지보수 주기
inspection_requirement  -- 검사 요건
reference           -- 법령 근거
```

### 6. `carwash_integrated_checklist` (9행)
```sql
step_num            -- 1-9
step_name           -- 토지용도 확인, 건물용도 판정 등
related_law         -- 해당 법령
check_item          -- 확인 항목
requirement         -- 요구사항
approval_body       -- 승인 기관
duration_estimate   -- 소요 기간
cost_estimate       -- 예상 비용
```

---

## 🔌 Frontend 사용 예시

### React에서 도시계획법 조회
```javascript
async function getUrbanPlanningRules() {
  const response = await fetch('/api/regulations/frameworks/urban-planning?category=용도지역_허용');
  const data = await response.json();
  console.log(data.data); // 32개 도시계획법 항목
}
```

### JavaScript로 환경 기준 조회 (지역별)
```javascript
async function getWastewaterStandardByRegion(regionCode) {
  const response = await fetch(`/api/regulations/frameworks/environmental-emission?region_code=${regionCode}`);
  const data = await response.json();
  const oilStandard = data.data[0].oil_standard_mg_l;
  return `지역의 유분 기준: ${oilStandard} mg/L`;
}

// 예: 한강 지역 (11000)
getWastewaterStandardByRegion('11000'); // "1.0 mg/L"
```

### Vue.js로 체크리스트 렌더링
```javascript
async function loadCarwashChecklist() {
  const response = await fetch('/api/regulations/frameworks/carwash-checklist');
  const data = await response.json();
  this.checklist = data.data; // 9단계 렌더링
}
```

---

## 📈 데이터 통계

| 법령 | 항목 수 | 주요 내용 |
|------|--------|---------|
| **도시계획법** | 32 | 용도지역(12) + 용도변경절차(7) + 건폐율(7) + 용적률(2) + 협력금(4) |
| **도로법** | 20 | 진출입기준(4) + 제한사항(5) + 점용허가(4) + 교통평가(7) |
| **상하수도법** | 25 | 상수도(10) + 하수도(10) + 수질(5) |
| **환경법** | 4 | 유역별 기준 (한강 1.0 / 낙동강 1.5 / 금강·영산강 2.0 mg/L) |
| **체크리스트** | 9 | 세차장 설립 9단계 (총 소요: 3~10개월, 비용: 1,600~1억4,100만원) |
| **총계** | **90** | 5개 법령 통합 |

---

## ✅ API 테스트 명령어

```bash
# 1. 모든 법령 조회
curl http://localhost:40090/api/regulations/legal-frameworks

# 2. 도시계획법 (용도지역)
curl http://localhost:40090/api/regulations/frameworks/urban-planning?category=용도지역_허용

# 3. 도로법 (진출입 기준)
curl http://localhost:40090/api/regulations/frameworks/road-access?category=진출입_기준

# 4. 상하수도법 (상수도 비용)
curl http://localhost:40090/api/regulations/frameworks/water-sewerage?category=상수도_공사비

# 5. 환경법 (유분 기준)
curl http://localhost:40090/api/regulations/frameworks/environmental-emission

# 6. 체크리스트 (전체 9단계)
curl http://localhost:40090/api/regulations/frameworks/carwash-checklist

# 7. 최종 요약
curl http://localhost:40090/api/regulations/frameworks/summary
```

---

## 🎯 UI 탭별 API 연계

| 탭 | 기존 | 신규 추가 API | 용도 |
|----|-----|-------------|------|
| Tab 1: 주소검색 | ✓ | - | 주소 → 좌표 변환 |
| Tab 2: 토지이용 | ✓ | `/frameworks/urban-planning` | 용도지역 상세 정보 |
| Tab 3: 건축물 | ✓ | `/frameworks/urban-planning?category=용도변경_절차` | 용도변경 절차 안내 |
| Tab 4: 연락처 | ✓ | `/frameworks/environmental-emission` | 유역환경청별 기준 |
| Tab 5: 허가판단 | ✓ | `/frameworks/carwash-checklist` | 9단계 체크리스트 |
| Tab 6: 절차안내 | ✓ | `/frameworks/summary` | 법령별 요약 정보 |
| **신규** | - | `/frameworks/road-access` | 도로법 진출입/교통 평가 |
| **신규** | - | `/frameworks/water-sewerage` | 상하수도 연결 및 비용 |

---

## 📝 주의사항

1. **유분 배출 기준**: 한강(1.0) ≠ 낙동강(1.5) ≠ 기타(2.0) - 지역별로 상이
2. **용도변경 기간**: 일반 심의 3-4개월 + 협력금 1,500~3,000만원 (서울 기준)
3. **상수도 비용**: 100m마다 100~300만원 추가 (포장 상태별 상이)
4. **하수도 선택**: 공공(1,000~5,000만원 가입금) vs 개별(5,000~1억원 시설비)
5. **정기 검사**: 공공하수도(월 1회) vs 개별처리(분기 1회) 자체검사 의무

---

**생성**: 2026-03-30 WebSearch + DB 통합
**버전**: v1.1 (5개 법령 + 실무경험 9조건 + 유역별 기준, 111개 항목, 11개 API)

---

## 🔥 신규 추가 (v1.1)

### 9. 실무 경험 기반 세차장 필수 조건 (9가지)

**출처**: 빅워시 운영 경험 (신뢰도: ⭐⭐⭐⭐⭐)

#### 엔드포인트

```
GET /api/regulations/actual-requirements
GET /api/regulations/actual-requirements/:requirement_num
```

#### 사용 예

```bash
# 모든 9개 조건 조회
curl http://localhost:40090/api/regulations/actual-requirements

# 특정 조건 상세 (예: 2번 - 건물 용도)
curl http://localhost:40090/api/regulations/actual-requirements/2
```

#### 9개 조건 요약

| # | 제목 | 핵심 | 중요도 |
|---|------|------|--------|
| 1 | 토지 용도지역 확인 | 변경 불가 필터링 | ⭐⭐⭐⭐⭐ |
| 2 | 건물 용도 (자동차관련시설) | 설계사무소 변경 가능 | ⭐⭐⭐⭐⭐ |
| 3 | 하수도/우수 연결 | 배수설비 필증 필요 | ⭐⭐⭐⭐ |
| 4 | 폐수처리시설 설치 | 100% 필수 (유분분리기 필수) | ⭐⭐⭐⭐⭐ |
| 5 | 폐수배출신고 (vs 허가) | 용도변경 시 허가 필수 (4~6주) | ⭐⭐⭐⭐⭐ |
| 6 | 폐수처리기 설치 (1년 내) | ⭐ 1년 기한 초과 시 재허가 필요 | ⭐⭐⭐⭐⭐ |
| 7 | 등록업체만 가능 | 개인업체 불가, 환경부 등록 확인 필수 | ⭐⭐⭐⭐⭐ |
| 8 | 설치완료신고 (2단계) | 설치 전 + 설치 후 신고 | ⭐⭐⭐⭐ |
| 9 | 운영 (직영 vs 위탁) | 99%는 전문업체 위탁 권장 | ⭐⭐⭐ |

---

### 10. 유역별 폐수처리 기준 (한강/낙동강/금강/영산강)

**출처**: 환경부 유역환경청 폐수배출시설 기준

#### 엔드포인트

```
GET /api/regulations/wastewater-standards
GET /api/regulations/wastewater-standards?region_code=11000&facility_type=유분분리기
GET /api/regulations/wastewater-standards/:region_code
```

#### 지역 코드 (유분배출 기준)

| 구분 | 지역코드 | 지역명 | 유분기준 |
|------|---------|--------|---------|
| **한강** | 11000 | 서울 | 1.0 mg/L (엄격) |
| | 28000 | 인천 | 1.0 mg/L |
| | 41000 | 경기 | 1.0 mg/L |
| **낙동강** | 26000 | 부산 | 1.5 mg/L |
| | 27000 | 대구 | 1.5 mg/L |
| | 31000 | 울산 | 1.5 mg/L |
| | 47000 | 경북 | 1.5 mg/L |
| | 48000 | 경남 | 1.5 mg/L |
| **금강** | 30000 | 대전 | 2.0 mg/L |
| | 36000 | 세종 | 2.0 mg/L |
| | 43000 | 충북 | 2.0 mg/L |
| | 44000 | 충남 | 2.0 mg/L |
| **영산강** | 29000 | 광주 | 2.0 mg/L |
| | 45000 | 전북 | 2.0 mg/L |
| | 46000 | 전남 | 2.0 mg/L |
| | 50000 | 제주 | 2.0 mg/L |

#### 사용 예

```bash
# 서울(11000)의 모든 폐수처리 시설 기준
curl http://localhost:40090/api/regulations/wastewater-standards/11000

# 유분분리기만 필터링
curl "http://localhost:40090/api/regulations/wastewater-standards?region_code=11000&facility_type=유분분리기"

# 부산(26000) 전체 기준
curl http://localhost:40090/api/regulations/wastewater-standards/26000
```

---

## 📊 통합 데이터 통계 (v1.1)

| 분류 | 항목 수 | 설명 |
|------|--------|------|
| **법령 기반** | 90 | 도시계획법(32) + 도로법(20) + 상하수도법(25) + 환경법(4) + 체크리스트(9) |
| **실무경험** | 9 | 빅워시 9개 필수 조건 |
| **유역별기준** | 12+ | 한강/낙동강/금강/영산강 시설별 기준 |
| **총계** | **111+** | 법령 + 실무 + 유역별 통합 |

---

## ✅ 신규 API 테스트

```bash
# 9개 실제 요구사항
curl http://localhost:40090/api/regulations/actual-requirements

# 특정 요구사항 (예: 3번)
curl http://localhost:40090/api/regulations/actual-requirements/3

# 서울의 폐수처리 기준
curl http://localhost:40090/api/regulations/wastewater-standards/11000

# 부산의 유분분리기만 조회
curl "http://localhost:40090/api/regulations/wastewater-standards?region_code=26000&facility_type=유분분리기"
```

---

**업데이트**: 2026-03-30 (v1.1)
**변경사항**:
- ✅ 9개 실무경험 기반 세차장 필수조건 API 추가
- ✅ 유역별 폐수처리 시설 기준 API 추가
- ✅ 총 11개 API 엔드포인트 (기존 7개 + 신규 4개)
