# 세차장 폐수처리 기준 API 가이드

## 개요

이 API는 물환경보전법에 따른 세차장 폐수처리 배출기준, 필요시설, 점검 기준을 조회할 수 있는 엔드포인트를 제공합니다.

**기본 URL**: `https://carwash.dclub.kr` 또는 `http://localhost:35000`

---

## 🌐 API 엔드포인트

### 1. 폐수처리 기준 조회

#### 1.1 기본 메타데이터 조회

```bash
GET /api/wastewater/standards
```

**설명**: 전체 메타데이터 및 분류 정보 반환

**응답 예**:
```json
{
  "success": true,
  "metadata": {
    "source": "물환경보전법 시행규칙 별표13",
    "lastUpdated": "2026-03-30",
    "legalBasis": ["물환경보전법 시행규칙 제35조 별표13", "..."],
    "validFrom": "2024-01-01"
  },
  "classification": {
    "zones": [
      {
        "zoneCode": "A",
        "zoneName": "청정지역",
        "description": "..."
      },
      {
        "zoneCode": "B",
        "zoneName": "가지역",
        "description": "..."
      },
      {
        "zoneCode": "C",
        "zoneName": "나지역",
        "description": "..."
      }
    ],
    "basins": [
      {
        "basin": "한강유역",
        "regions": ["서울", "경기", "인천", "강원 일부"]
      },
      {
        "basin": "낙동강유역",
        "regions": ["부산", "대구", "울산", "경북", "경남"]
      },
      {
        "basin": "금강유역",
        "regions": ["대전", "세종", "충북", "충남"]
      },
      {
        "basin": "영산강유역",
        "regions": ["광주", "전북", "전남", "제주"]
      }
    ]
  }
}
```

---

#### 1.2 지역 및 구역별 배출기준 조회

```bash
GET /api/wastewater/standards?basin=한강유역&zoneType=가지역
```

**파라미터**:
- `basin` (필수): 한강유역, 낙동강유역, 금강유역, 영산강유역
- `zoneType` (필수): 청정지역, 가지역, 나지역 (또는 코드: A, B, C)

**응답 예**:
```json
{
  "success": true,
  "basin": "한강유역",
  "zone": {
    "code": "B",
    "name": "가지역",
    "description": "수질이 좋은 지역 (상수원 취수지점 상류, 시가지)"
  },
  "standards": {
    "BOD": 5,
    "COD": 15,
    "SS": 10,
    "유분": 1,
    "총질소": 20,
    "총인": 1,
    "색도": 40,
    "pH": "6.5~8.0"
  },
  "additionalRequirements": [
    "유분분리기 필수 설치",
    "침전지 및 여과시설 병행",
    "분기별 오일 제거 기록 유지",
    "정기 수질검사 (분기 1회)",
    "폐유처리 계약서 제출"
  ],
  "unit": "mg/L (유분, 색도 제외)"
}
```

**사용 예**:
```bash
# 한강유역 가지역 기준
curl -s 'https://carwash.dclub.kr/api/wastewater/standards?basin=한강유역&zoneType=가지역' | jq '.'

# 낙동강유역 청정지역 기준
curl -s 'https://carwash.dclub.kr/api/wastewater/standards?basin=낙동강유역&zoneType=청정지역' | jq '.'
```

---

#### 1.3 일일 배출량별 신고 기준 조회

```bash
GET /api/wastewater/standards?dailyDischarge=30
```

**파라미터**:
- `dailyDischarge` (필수): 일일 폐수배출량 (ton/day)

**응답 예**:
```json
{
  "success": true,
  "dailyDischarge": "30",
  "requirement": "지자체 신고 + 시도청 보고",
  "requiredFacilities": [
    "침전지 (2단계 이상)",
    "유분분리기 필수",
    "침전지 용량 = 일일배출량/10",
    "정기점검 기록부 관리"
  ],
  "inspectionSchedule": "분기 1회 (지자체) + 반기 1회 (시도청)"
}
```

**사용 예**:
```bash
# 20ton/day 미만
curl -s 'https://carwash.dclub.kr/api/wastewater/standards?dailyDischarge=10' | jq '.'

# 20~50ton/day
curl -s 'https://carwash.dclub.kr/api/wastewater/standards?dailyDischarge=35' | jq '.'

# 50ton/day 이상
curl -s 'https://carwash.dclub.kr/api/wastewater/standards?dailyDischarge=80' | jq '.'
```

---

### 2. 폐수처리 시설 정보 조회

#### 2.1 전체 시설 목록

```bash
GET /api/wastewater/facilities
```

**응답 예**:
```json
{
  "success": true,
  "description": "필수 폐수처리시설 기준",
  "facilities": [
    {
      "name": "침전지 (Settling Tank)",
      "type": "1차 처리",
      "function": "SS 및 부유물 제거"
    },
    {
      "name": "유분분리기 (Oil Separator/Coalescer)",
      "type": "1차 처리 (고급)",
      "function": "유류 제거"
    },
    {
      "name": "여과시설 (Filtration)",
      "type": "2차 처리",
      "function": "미세입자 및 부유물 제거"
    },
    {
      "name": "조정조 (Equalization Tank)",
      "type": "보조시설",
      "function": "폐수의 일정한 흐름 유지"
    },
    {
      "name": "비상저류조 (Emergency Storage)",
      "type": "보조시설",
      "function": "처리시설 고장 시 폐수 임시 저장"
    }
  ]
}
```

---

#### 2.2 특정 시설 상세 정보

```bash
GET /api/wastewater/facilities?type=침전지
```

**파라미터**:
- `type` (선택): 침전지, 유분분리기, 여과시설, 조정조, 비상저류조

**응답 예**:
```json
{
  "success": true,
  "facility": {
    "name": "침전지 (Settling Tank)",
    "type": "1차 처리",
    "function": "SS 및 부유물 제거",
    "specifications": {
      "minimumRetentionTime": "2시간",
      "depthRange": "1.0~1.5m",
      "oilSlickRemovalFrequency": "주 1회 이상",
      "sludgeRemovalCycle": "월 1회 이상",
      "capacityFormula": "일일배출량(ton) / 10 (m³)"
    },
    "standards": [
      "침전지 깊이: 최소 1.0m",
      "표면적 부하율: 0.5~1.0 m³/m²/h",
      "슬러지 침적 높이: 30cm 이상 시 제거",
      "오일 층 높이: 10cm 이상 시 제거"
    ]
  }
}
```

**사용 예**:
```bash
# 유분분리기 정보
curl -s 'https://carwash.dclub.kr/api/wastewater/facilities?type=유분분리기' | jq '.'

# 여과시설 정보
curl -s 'https://carwash.dclub.kr/api/wastewater/facilities?type=여과시설' | jq '.'
```

---

### 3. 점검 및 유지관리 기준

#### 3.1 전체 점검 기준

```bash
GET /api/wastewater/inspection
```

**응답 예**:
```json
{
  "success": true,
  "inspectionSchedule": [
    {
      "dailyDischarge": "< 20ton/day",
      "officialInspection": "연 1회 (자체 점검 권장)",
      "selfInspection": {
        "frequency": "주 2회",
        "items": [
          "침전지 오일층 확인 및 제거",
          "침전지 슬러지 깊이 측정",
          "처리시설 누수 여부",
          "유분분리기 필터 상태",
          "배출수 색도 및 냄새 확인"
        ]
      }
    },
    {
      "dailyDischarge": "20~50ton/day",
      "officialInspection": "분기 1회 (지자체) + 반기 1회 (시도청)",
      "selfInspection": {
        "frequency": "주 3회",
        "items": [
          "침전지 오일층 제거 (매 점검)",
          "슬러지 깊이 기록",
          "유분분리기 필터 상태",
          "배출구 샘플링 및 기록",
          "약품 투입량 기록 (사용 시)"
        ]
      },
      "professionalInspection": "반기 1회 (수질검사 전문기관)"
    },
    {
      "dailyDischarge": "> 50ton/day",
      "officialInspection": "월 1회 (지자체) + 분기 1회 (환경청)",
      "selfInspection": {
        "frequency": "매일 또는 자동 모니터링",
        "items": [
          "실시간 유량 및 수질 모니터링",
          "침전지/유분분리기 상태 기록",
          "배출수 수질 자동 기록",
          "장비 가동 시간 기록"
        ]
      },
      "professionalInspection": "월 1회 (수질검사 전문기관)"
    }
  ],
  "recordManagement": {
    "requiredDocuments": [
      "폐수배출시설 신고증",
      "처리시설 설계도서",
      "점검 일지 및 기록부",
      "수질검사 성적서",
      "폐유 인수증",
      "약품 투입 기록",
      "슬러지/오일 제거 기록"
    ],
    "retentionPeriod": "3년",
    "auditRisk": {
      "high": "기록 미보관 시 과태료 최대 1000만원",
      "medium": "기준 초과 배출 시 개선명령 + 과태료",
      "low": "점검 기록 부분 미흡 시 시정명령"
    }
  }
}
```

---

#### 3.2 배출량별 점검 기준

```bash
GET /api/wastewater/inspection?dailyDischarge=35
```

**파라미터**:
- `dailyDischarge` (필수): 일일 폐수배출량 (ton/day)

**응답 예**:
```json
{
  "success": true,
  "dailyDischarge": "35",
  "inspectionSchedule": {
    "dailyDischarge": "20~50ton/day",
    "officialInspection": "분기 1회 (지자체) + 반기 1회 (시도청)",
    "selfInspection": {
      "frequency": "주 3회",
      "items": [
        "침전지 오일층 제거 (매 점검)",
        "슬러지 깊이 기록",
        "유분분리기 필터 상태",
        "배출구 샘플링 및 기록",
        "약품 투입량 기록 (사용 시)"
      ]
    },
    "professionalInspection": "반기 1회 (수질검사 전문기관)"
  }
}
```

---

### 4. 세차장별 사례 및 체크리스트

#### 4.1 전체 사례 및 체크리스트

```bash
GET /api/wastewater/cases
```

**응답 예**:
```json
{
  "success": true,
  "caseSamples": [
    {
      "type": "소규모 손세차장",
      "dailyDischarge": "5~10ton/day",
      "location": "강남구 상업지역",
      "basin": "한강유역",
      "zoneType": "가지역",
      "appliedStandard": {
        "BOD": 5,
        "COD": 15,
        "SS": 10,
        "유분": 2,
        "총질소": 20,
        "총인": 1
      },
      "requiredFacilities": [
        "침전지 (약 0.5~1.0m³, 2시간 체류)",
        "폐유통 (오일만 수거)"
      ],
      "inspection": "연 1회 자체점검, 연 1회 지자체 공식검사",
      "cost": "월 50~100만원 (관리비)"
    },
    {
      "type": "중규모 자동세차장",
      "dailyDischarge": "30ton/day",
      "location": "수원시 상업지역",
      "basin": "한강유역",
      "zoneType": "가지역",
      "appliedStandard": {
        "BOD": 5,
        "COD": 15,
        "SS": 10,
        "유분": 1,
        "총질소": 20,
        "총인": 1
      },
      "requiredFacilities": [
        "침전지 (2단계, 약 3m³)",
        "유분분리기 (코알레서 타입)",
        "조정조"
      ],
      "inspection": "분기 1회 지자체 + 반기 1회 시도청, 분기 1회 수질검사",
      "cost": "월 200~300만원 (관리 + 검사)"
    },
    {
      "type": "대규모 24시간 세차장",
      "dailyDischarge": "80ton/day",
      "location": "강남 주요 가로변",
      "basin": "한강유역",
      "zoneType": "가지역 또는 나지역",
      "appliedStandard": {
        "BOD": 5,
        "COD": 15,
        "SS": 10,
        "유분": 1,
        "총질소": 20,
        "총인": 1
      },
      "requiredFacilities": [
        "침전지 (3단계, 약 8m³)",
        "유분분리기 (고급형)",
        "여과시설",
        "비상저류조",
        "자동모니터링 시스템"
      ],
      "inspection": "월 1회 지자체 + 분기 1회 환경청, 월 1회 수질검사",
      "cost": "월 500만원 이상 (전산 모니터링 포함)"
    }
  ],
  "checklist": {
    "preApplicationChecklist": [
      {
        "item": "1. 시설 규모 파악",
        "details": [
          "일일 폐수배출량 정확히 계산 (ton/day)",
          "세차 타입 결정 (자동/수동/혼합)",
          "운영 시간 확인 (연중무휴 여부)"
        ]
      },
      {
        "item": "2. 위치 및 지역 확인",
        "details": [
          "시군구 및 법정동 확인",
          "용도지역 확인 (상업/일반/기타)",
          "해당 유역환경청 확인",
          "해당 수계 및 지역 (청정/가/나지역) 확인"
        ]
      }
    ]
  },
  "notes": {
    "important": [
      "세차장은 '폐수배출시설'에 해당하여 반드시 신고 필요",
      "일일 배출량 20ton 미만도 신고 대상",
      "유분은 세차장에서 가장 엄격한 기준 항목",
      "한강유역의 유분 기준(1mg/L)이 전국에서 가장 엄격"
    ]
  }
}
```

---

#### 4.2 특정 세차장 타입 사례

```bash
GET /api/wastewater/cases?carwashType=자동세차장
```

**파라미터**:
- `carwashType` (선택): 자동세차장, 손세차장, 대규모 세차장 등

**응답 예**:
```json
{
  "success": true,
  "caseData": {
    "type": "중규모 자동세차장",
    "dailyDischarge": "30ton/day",
    "location": "수원시 상업지역",
    "basin": "한강유역",
    "zoneType": "가지역",
    "appliedStandard": {
      "BOD": 5,
      "COD": 15,
      "SS": 10,
      "유분": 1,
      "총질소": 20,
      "총인": 1
    },
    "requiredFacilities": [
      "침전지 (2단계, 약 3m³)",
      "유분분리기 (코알레서 타입)",
      "조정조"
    ],
    "inspection": "분기 1회 지자체 + 반기 1회 시도청, 분기 1회 수질검사",
    "cost": "월 200~300만원 (관리 + 검사)"
  }
}
```

---

## 📊 API 요청 예시

### cURL 예시

```bash
# 1. 한강유역 가지역 기준 조회
curl -s 'https://carwash.dclub.kr/api/wastewater/standards?basin=한강유역&zoneType=가지역' | jq '.'

# 2. 30ton/day 배출량의 신고 기준
curl -s 'https://carwash.dclub.kr/api/wastewater/standards?dailyDischarge=30' | jq '.'

# 3. 침전지 시설 정보
curl -s 'https://carwash.dclub.kr/api/wastewater/facilities?type=침전지' | jq '.'

# 4. 35ton/day 점검 기준
curl -s 'https://carwash.dclub.kr/api/wastewater/inspection?dailyDischarge=35' | jq '.'

# 5. 자동세차장 사례
curl -s 'https://carwash.dclub.kr/api/wastewater/cases?carwashType=자동세차장' | jq '.'
```

### JavaScript/Node.js 예시

```javascript
// 1. 배출기준 조회
async function getStandards(basin, zoneType) {
  const response = await fetch(
    `/api/wastewater/standards?basin=${basin}&zoneType=${zoneType}`
  );
  return response.json();
}

// 2. 배출량별 신고 기준
async function getNotificationRequirement(dailyDischarge) {
  const response = await fetch(
    `/api/wastewater/standards?dailyDischarge=${dailyDischarge}`
  );
  return response.json();
}

// 3. 처리시설 정보
async function getFacilityInfo(type) {
  const response = await fetch(
    `/api/wastewater/facilities?type=${type}`
  );
  return response.json();
}

// 4. 점검 기준
async function getInspectionSchedule(dailyDischarge) {
  const response = await fetch(
    `/api/wastewater/inspection?dailyDischarge=${dailyDischarge}`
  );
  return response.json();
}

// 5. 세차장 사례
async function getCarwashCase(carwashType) {
  const response = await fetch(
    `/api/wastewater/cases?carwashType=${carwashType}`
  );
  return response.json();
}

// 사용 예
getStandards('한강유역', '가지역')
  .then(data => console.log(data))
  .catch(err => console.error(err));
```

---

## 🔍 조회 시나리오

### 시나리오 1: 강남구 상업지역 자동세차장 (30ton/day)

```bash
# 1. 배출기준 조회
curl -s 'https://carwash.dclub.kr/api/wastewater/standards?basin=한강유역&zoneType=가지역'

# 2. 신고 기준 조회
curl -s 'https://carwash.dclub.kr/api/wastewater/standards?dailyDischarge=30'

# 3. 필요 시설 조회
curl -s 'https://carwash.dclub.kr/api/wastewater/facilities'

# 4. 점검 기준 조회
curl -s 'https://carwash.dclub.kr/api/wastewater/inspection?dailyDischarge=30'

# 5. 유사 사례 조회
curl -s 'https://carwash.dclub.kr/api/wastewater/cases?carwashType=자동세차장'
```

**예상 결과**:
- BOD: 5 mg/L
- COD: 15 mg/L
- SS: 10 mg/L
- **유분: 1 mg/L (강화)** ← 한강유역 강화
- 필수 시설: 침전지 (3m³) + 유분분리기 + 조정조
- 점검: 분기 1회 지자체 + 반기 1회 시도청
- 비용: 월 200~300만원

---

### 시나리오 2: 대규모 세차장 (80ton/day) 모니터링

```bash
# 1. 배출기준 (나지역인 경우)
curl -s 'https://carwash.dclub.kr/api/wastewater/standards?basin=한강유역&zoneType=나지역'

# 2. 신고 기준 (50ton/day 이상)
curl -s 'https://carwash.dclub.kr/api/wastewater/standards?dailyDischarge=80'

# 3. 점검 기준 (엄격함)
curl -s 'https://carwash.dclub.kr/api/wastewater/inspection?dailyDischarge=80'
```

**예상 결과**:
- 신고: 환경청 신고 (국가 관리)
- 점검: **월 1회 지자체 + 분기 1회 환경청 + 월 1회 수질검사**
- 필수 시설: 침전지 (3단계) + 유분분리기 (고급) + 여과 + 비상저류 + 자동모니터링

---

## 📝 에러 처리

모든 요청 실패 시 다음과 같이 응답됩니다:

```json
{
  "success": false,
  "error": "에러 메시지"
}
```

**예시**:
```bash
# 잘못된 지역
curl -s 'https://carwash.dclub.kr/api/wastewater/standards?basin=잘못된지역&zoneType=가지역'
# → {"success": false, "error": "..."}

# 파라미터 누락
curl -s 'https://carwash.dclub.kr/api/wastewater/standards'
# → 메타데이터만 반환
```

---

## 📞 지원

문제가 발생하면 다음 유역환경청에 문의하세요:

- **한강유역환경청**: www.hanriver.go.kr
- **낙동강유역환경청**: www.nakdongriver.go.kr
- **금강유역환경청**: www.keum.go.kr
- **영산강유역환경청**: www.yeongsan.go.kr

---

**문서 버전**: v1.0
**작성일**: 2026-03-30
**마지막 수정**: 2026-03-30
