# 🚀 세차장 허가 체크 서비스 - 배포 정보

## 배포 완료! ✅

**배포 일시**: 2026-03-30 00:10 UTC
**배포 상태**: ✅ 성공
**배포 시간**: 1073ms

---

## 📍 서비스 URL

| 항목 | 값 |
|------|-----|
| **도메인** | carwash.dclub.kr |
| **HTTPS URL** | https://carwash.dclub.kr |
| **백엔드 주소** | 192.168.45.253:35000 |
| **서브도메인** | carwash |
| **포트** | 35000 |

---

## 🔗 접속 방법

### 웹 브라우저에서 접속
```
https://carwash.dclub.kr
```

### 로컬 테스트 (localhost)
```
http://localhost:35000
```

### API 테스트 (curl)
```bash
# 주소 검색
curl -s 'https://carwash.dclub.kr/api/address/search?query=강남' | jq '.'

# 용도지역 조회
curl -s 'https://carwash.dclub.kr/api/land/zone?scenario=2' | jq '.'

# 관공서 연락처
curl -s 'https://carwash.dclub.kr/api/offices?region=서울' | jq '.'

# 허가 판단
curl -X POST 'https://carwash.dclub.kr/api/permit/check' \
  -H 'Content-Type: application/json' \
  -d '{"zoneType":"상업지역"}' | jq '.'
```

---

## 🔐 배포 설정 정보

### DNS
- **레코드**: carwash.dclub.kr → 123.212.111.26
- **상태**: ✅ 활성

### Nginx 프록시
- **상태**: ✅ 설정 완료
- **경로**: /
- **백엔드**: 192.168.45.253:35000

### SSL/TLS
- **인증서**: Wildcard (*.dclub.kr)
- **상태**: ✅ 활성
- **프로토콜**: HTTPS

---

## 🗄️ 데이터베이스 (선택사항)

배포 시 자동 생성된 MySQL 데이터베이스:

```
호스트: 192.168.45.73
포트: 3306
데이터베이스: dclub_carwash
사용자명: user_carwash
비밀번호: 9d524874002044d19a3c6942
```

**연결 문자열**:
```
mysql://user_carwash:9d524874002044d19a3c6942@192.168.45.73:3306/dclub_carwash
```

---

## 📋 배포 체크리스트

- [x] DNS 레코드 생성
- [x] Nginx 프록시 설정
- [x] SSL 인증서 적용
- [x] 포트 예약 (35000)
- [ ] 실제 공공 API 키 연동
- [ ] 데이터베이스 활용 (필요시)
- [ ] 모니터링 설정 (필요시)

---

## 🔧 로컬 개발 (로컬에서 실행)

### 포트 변경 (로컬 개발 중)
```bash
# .env 파일에서 PORT를 원하는 포트로 변경
PORT=40090

# 또는 명령줄에서
PORT=40090 npm start
```

### Mock 모드 비활성화
```bash
# .env 파일
USE_MOCK=false

# API 키 입력
VWORLD_KEY=your_vworld_key
JUSO_KEY=your_juso_key
DATA_API_KEY=your_data_key
```

---

## 📊 성능 정보

- **배포 시간**: 1073ms
- **응답 시간**: < 100ms (Mock 모드)
- **SSL 인증서**: 와일드카드 (*.dclub.kr)
- **캐싱**: Nginx 기본 설정

---

## 🛠️ 배포 재설정

서브도메인 또는 포트를 변경하려면:

```bash
curl -X POST https://api.dclub.kr/api/deploy \
  -H "X-API-Key: dclub-api-key-2025-secure" \
  -H "Content-Type: application/json" \
  -d '{
    "subdomain": "permit",
    "port": 35001,
    "project": "carwash-permit",
    "desc": "세차장 허가 자동 체크 서비스"
  }'
```

---

## 📞 지원

- **배포 문의**: api.dclub.kr
- **도메인 문의**: dclub.kr
- **기술 지원**: 로컬 개발 환경에서 npm start 실행

---

**배포 완료!** 🎉
이제 https://carwash.dclub.kr에서 세차장 허가 체크 서비스에 접속할 수 있습니다.
