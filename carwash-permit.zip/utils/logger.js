/**
 * ✅ P1-3: 통합 로깅 시스템
 * 모든 라우트에서 일관된 로깅 제공
 * JSON 형식으로 구조화된 로깅 출력
 */

const crypto = require('crypto');

class Logger {
  constructor(moduleName = 'app') {
    this.moduleName = moduleName;
  }

  /**
   * 기본 로그 메서드 (JSON 형식)
   */
  log(level, message, data = null) {
    const timestamp = new Date().toISOString();
    const logEntry = {
      timestamp,
      level,
      module: this.moduleName,
      message,
      ...(data && { data })
    };
    console.log(JSON.stringify(logEntry));
  }

  /**
   * 정보 레벨 로깅
   */
  info(message, data = null) {
    this.log('INFO', message, data);
  }

  /**
   * 경고 레벨 로깅
   */
  warn(message, data = null) {
    this.log('WARN', message, data);
  }

  /**
   * 에러 레벨 로깅
   */
  error(message, data = null) {
    this.log('ERROR', message, data);
  }

  /**
   * 디버그 레벨 로깅 (개발 모드에서만)
   */
  debug(message, data = null) {
    if (process.env.NODE_ENV === 'development') {
      this.log('DEBUG', message, data);
    }
  }

  /**
   * API 요청 로깅 (진입)
   */
  logRequest(req, endpoint, params = null) {
    this.info(`[${req.method}] ${endpoint} - 요청 시작`, {
      method: req.method,
      path: req.path,
      ip: req.ip || req.connection.remoteAddress,
      userAgent: req.get('user-agent'),
      params
    });
  }

  /**
   * API 응답 로깅 (종료)
   */
  logResponse(endpoint, statusCode, responseTime = 0, data = null) {
    this.info(`[${statusCode}] ${endpoint} - 응답 완료`, {
      statusCode,
      responseTime: `${responseTime}ms`,
      ...(data && { summary: data })
    });
  }

  /**
   * 에러 로깅 with 추적 ID
   */
  logError(message, error, context = null) {
    const errorId = `ERR-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
    this.error(`[${errorId}] ${message}`, {
      errorId,
      message: error.message,
      stack: error.stack,
      ...context
    });
    return errorId;
  }

  /**
   * 데이터베이스 작업 로깅
   */
  logDatabase(operation, table, duration = 0, rowCount = 0) {
    this.info(`[DB] ${operation} on ${table}`, {
      operation,
      table,
      duration: `${duration}ms`,
      rowsAffected: rowCount
    });
  }

  /**
   * 성능 측정 로깅
   */
  logPerformance(operation, duration, threshold = 1000) {
    const level = duration > threshold ? 'WARN' : 'INFO';
    const logMethod = level === 'WARN' ? this.warn : this.info;
    logMethod.call(this, `[PERF] ${operation}`, {
      duration: `${duration}ms`,
      slow: duration > threshold
    });
  }
}

module.exports = Logger;
