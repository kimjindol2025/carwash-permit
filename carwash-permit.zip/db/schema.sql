-- SQLite 쇼핑몰 DB 스키마
-- 정규화된 테이블 구조

CREATE TABLE IF NOT EXISTS categories (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  name       TEXT    NOT NULL UNIQUE,
  slug       TEXT    NOT NULL UNIQUE,
  sort_order INTEGER DEFAULT 0,
  created_at TEXT    DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS products (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  category_id INTEGER NOT NULL REFERENCES categories(id),
  name        TEXT    NOT NULL,
  description TEXT,
  price       INTEGER NOT NULL DEFAULT 0,
  stock       INTEGER NOT NULL DEFAULT 0,
  image_url   TEXT,
  options     TEXT,
  is_active   INTEGER NOT NULL DEFAULT 1,
  sort_order  INTEGER DEFAULT 0,
  created_at  TEXT DEFAULT (datetime('now','localtime')),
  updated_at  TEXT DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS orders (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  order_number   TEXT    NOT NULL UNIQUE,
  customer_name  TEXT    NOT NULL,
  customer_phone TEXT    NOT NULL,
  customer_addr  TEXT    NOT NULL,
  memo           TEXT,
  total_price    INTEGER NOT NULL DEFAULT 0,
  status         TEXT    NOT NULL DEFAULT 'pending',
  created_at     TEXT DEFAULT (datetime('now','localtime')),
  updated_at     TEXT DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS order_items (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id     INTEGER NOT NULL REFERENCES orders(id),
  product_id   INTEGER NOT NULL REFERENCES products(id),
  product_name TEXT    NOT NULL,
  unit_price   INTEGER NOT NULL,
  quantity     INTEGER NOT NULL DEFAULT 1,
  option_value TEXT,
  subtotal     INTEGER NOT NULL
);

-- 인덱스 (검색 성능 향상)
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_is_active ON products(is_active);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON order_items(order_id);

-- ===== 워크플로우 세션 (허가 체크 프로세스 추적) =====
CREATE TABLE IF NOT EXISTS workflow_sessions (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id       TEXT    NOT NULL UNIQUE,
  current_step     INTEGER DEFAULT 0,
  status           TEXT    DEFAULT 'active',

  -- 단계별 저장 데이터
  step1_address    TEXT,
  step1_sigungu_cd TEXT,
  step1_bjdong_cd  TEXT,
  step1_pnu        TEXT,
  step1_completed  INTEGER DEFAULT 0,

  step2_zone_type  TEXT,
  step2_zone_code  TEXT,
  step2_jimok      TEXT,
  step2_area       TEXT,
  step2_source     TEXT,
  step2_completed  INTEGER DEFAULT 0,

  step3_building_nm TEXT,
  step3_purpose_cd  TEXT,
  step3_purpose_nm  TEXT,
  step3_floor_ar    TEXT,
  step3_completed   INTEGER DEFAULT 0,

  step4_result      TEXT,
  step4_reason      TEXT,
  step4_conditions  TEXT,
  step4_checklist   TEXT,
  step4_completed   INTEGER DEFAULT 0,

  final_report      TEXT,
  created_at        TEXT DEFAULT (datetime('now','localtime')),
  updated_at        TEXT DEFAULT (datetime('now','localtime')),
  expires_at        TEXT
);

CREATE INDEX IF NOT EXISTS idx_workflow_session_id ON workflow_sessions(session_id);
CREATE INDEX IF NOT EXISTS idx_workflow_status ON workflow_sessions(status);

-- ===== 관리자 시스템 =====
CREATE TABLE IF NOT EXISTS admin_users (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  username   TEXT NOT NULL UNIQUE,
  password   TEXT NOT NULL,
  role       TEXT DEFAULT 'admin',
  is_active  INTEGER DEFAULT 1,
  created_at TEXT DEFAULT (datetime('now','localtime')),
  updated_at TEXT DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS admin_sessions (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL REFERENCES admin_users(id),
  token      TEXT NOT NULL UNIQUE,
  ip_address TEXT,
  user_agent TEXT,
  expires_at TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

CREATE INDEX IF NOT EXISTS idx_admin_sessions_token ON admin_sessions(token);
CREATE INDEX IF NOT EXISTS idx_admin_sessions_expires ON admin_sessions(expires_at);

-- ===== 검색 로그 (IP 추적) =====
CREATE TABLE IF NOT EXISTS workflow_search_logs (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id      TEXT,
  step            INTEGER,
  search_type     TEXT,           -- 'address', 'land', 'building', 'permit'
  search_query    TEXT,
  search_result   TEXT,
  ip_address      TEXT NOT NULL,
  user_agent      TEXT,
  referer         TEXT,
  country         TEXT,           -- 국가 (선택)
  city            TEXT,            -- 도시 (선택)
  latitude        REAL,
  longitude       REAL,
  device_type     TEXT,            -- 'mobile', 'tablet', 'desktop'
  response_time   INTEGER,         -- 응답 시간 (ms)
  status_code     INTEGER DEFAULT 200,
  error_msg       TEXT,
  created_at      TEXT DEFAULT (datetime('now','localtime'))
);

CREATE INDEX IF NOT EXISTS idx_search_logs_ip ON workflow_search_logs(ip_address);
CREATE INDEX IF NOT EXISTS idx_search_logs_session ON workflow_search_logs(session_id);
CREATE INDEX IF NOT EXISTS idx_search_logs_created ON workflow_search_logs(created_at);
CREATE INDEX IF NOT EXISTS idx_search_logs_type ON workflow_search_logs(search_type);

-- ===== 정부 데이터 (175K + 183K) =====
-- P1-1: 용도지역정보 (zone_info)
CREATE TABLE IF NOT EXISTS zone_info (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  wevd_cd          TEXT UNIQUE,             -- 용도지역 코드
  sgg_cd           TEXT NOT NULL,           -- 시군구 코드
  wevd_ty_stcd     TEXT,                    -- 용도지역 타입
  lcls_cd          TEXT,                    -- 대분류 코드
  mcls_cd          TEXT,                    -- 중분류 코드
  area_m2          REAL,                    -- 면적 (㎡)
  created_at       TEXT DEFAULT (datetime('now','localtime'))
);

-- P1-1: 건축물대장/개발행위 (development_permits)
CREATE TABLE IF NOT EXISTS development_permits (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  pnu              TEXT UNIQUE,             -- 필지 고유번호
  location_name    TEXT,                    -- 위치명
  land_type        TEXT,                    -- 지목
  area             REAL,                    -- 면적
  zone_type        TEXT,                    -- 용도지역
  zone_district    TEXT,                    -- 용도지구
  local_code       TEXT NOT NULL,           -- 지역코드 (시군구)
  local_name       TEXT,                    -- 지역명
  dev_code         TEXT,                    -- 개발행위 코드
  dev_name         TEXT,                    -- 개발행위명
  main_dev_code    TEXT,                    -- 주요 개발 코드
  main_dev_name    TEXT,                    -- 주요 개발명
  apply_date       TEXT,                    -- 신청일자
  permit_date      TEXT,                    -- 허가일자
  dev_purpose      TEXT,                    -- 개발 목적
  created_at       TEXT DEFAULT (datetime('now','localtime'))
);

-- P1-1: 필수 인덱스 (성능 향상 30%)
-- zone_info: 시군구 코드 기반 조회 최적화
CREATE INDEX IF NOT EXISTS idx_zone_sgg_cd ON zone_info(sgg_cd);
-- zone_info: 용도지역 분류 기반 통계 조회 최적화
CREATE INDEX IF NOT EXISTS idx_zone_mcls_cd ON zone_info(mcls_cd);
-- development_permits: 지역코드 기반 개발이력 조회 최적화
CREATE INDEX IF NOT EXISTS idx_devperm_local ON development_permits(local_code);
-- development_permits: 주요 개발명 기반 필터링 최적화
CREATE INDEX IF NOT EXISTS idx_devperm_type ON development_permits(main_dev_name);
