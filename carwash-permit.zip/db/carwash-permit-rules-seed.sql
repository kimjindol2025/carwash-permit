-- ===== 세차장 허가 의사결정 엔진 시드 데이터 =====

-- ===== 1. 기존 건축물 용도별 세차장 허가 판정 =====

-- 프리패스: 주차장
INSERT INTO existing_building_judgement (building_purpose, category, freepass_reason, notes)
VALUES ('주차장', 'freepass', '주차장', '자동차관련시설로 이미 분류, 별도 검수 불필요');

-- 프리패스: 1급 공업사
INSERT INTO existing_building_judgement (building_purpose, category, freepass_reason, notes)
VALUES ('1급공업사', 'freepass', '1급공업사', '자동차정비 1급 사업장, 세차장 운영 적격');

-- 프리패스: 2급 공업사
INSERT INTO existing_building_judgement (building_purpose, category, freepass_reason, notes)
VALUES ('2급공업사', 'freepass', '2급공업사', '자동차정비 2급 사업장, 세차장 운영 적격');

-- 프리패스: 세차장
INSERT INTO existing_building_judgement (building_purpose, category, freepass_reason, notes)
VALUES ('세차장', 'freepass', '세차장', '이미 세차장 용도, 별도 검수 불필요');

-- 검수 필요: 제1종근린생활시설
INSERT INTO existing_building_judgement (building_purpose, category, inspection_items, notes)
VALUES (
  '제1종근린생활시설',
  'inspection',
  '["폐수처리시설", "상하수도 연결", "주차장 확보", "소음 기준"]',
  '근린생활시설에서 세차장으로 변경 가능 (용도변경 필요)'
);

-- 검수 필요: 제2종근린생활시설
INSERT INTO existing_building_judgement (building_purpose, category, inspection_items, notes)
VALUES (
  '제2종근린생활시설',
  'inspection',
  '["폐수처리시설", "상하수도 연결", "주차장 확보", "소음 기준"]',
  '근린생활시설에서 세차장으로 변경 가능 (용도변경 필요)'
);

-- 비적용: 단독주택
INSERT INTO existing_building_judgement (building_purpose, category, not_applicable_reason, notes)
VALUES (
  '단독주택',
  'inspection',
  '주택용도',
  '용도변경 가능하지만 검수 필요 (주거지역에서 용도변경 시 민원 가능)'
);

-- 비적용: 공동주택
INSERT INTO existing_building_judgement (building_purpose, category, not_applicable_reason, notes)
VALUES (
  '공동주택',
  'inspection',
  '주택용도',
  '용도변경 가능하지만 검수 필요 (주거지역에서 용도변경 시 민원 가능)'
);

-- 검수 필요: 창고
INSERT INTO existing_building_judgement (building_purpose, category, inspection_items, notes)
VALUES (
  '창고',
  'inspection',
  '["폐수처리시설", "상하수도 연결", "바닥 내구성"]',
  '창고에서 세차장으로 변경 가능 (개축 필요)'
);

-- 검수 필요: 상가
INSERT INTO existing_building_judgement (building_purpose, category, inspection_items, notes)
VALUES (
  '상가',
  'inspection',
  '["폐수처리시설", "상하수도 연결", "주차장 확보"]',
  '상가에서 세차장으로 변경 가능 (용도변경 필요)'
);

-- ===== 2. 나대지 신축 세차장 규칙 =====

-- 나대지: 창고 신축 후 세차장 용도로 최초 지정
INSERT INTO newland_carwash_rules (initial_purpose, is_allowed, final_purpose, required_design_items, required_permits, notes)
VALUES (
  '창고',
  1,
  '자동차관련시설 세차장',
  '["건축법 설계", "폐수처리시설 설계", "상하수도 설계", "방수 및 바닥재"]',
  '["건축허가", "토목설계승인", "건축구조승인", "폐수배출시설 신고"]',
  '창고 신축 시 최초 용도를 반드시 자동차관련시설 세차장으로 지정'
);

-- 나대지: 상가 신축 후 세차장 용도로 최초 지정
INSERT INTO newland_carwash_rules (initial_purpose, is_allowed, final_purpose, required_design_items, required_permits, notes)
VALUES (
  '상가',
  1,
  '자동차관련시설 세차장',
  '["건축법 설계", "폐수처리시설 설계", "상하수도 설계", "방수 및 배수"]',
  '["건축허가", "토목설계승인", "건축구조승인", "폐수배출시설 신고"]',
  '상가 신축 시 최초 용도를 반드시 자동차관련시설 세차장으로 지정'
);

-- ===== 3. 기존 건축물 용도변경 규칙 =====

-- 근린생활시설 → 자동차관련시설 세차장
INSERT INTO building_purpose_change_rules (
  from_purpose, to_purpose, is_changeable, change_period_min, change_period_max,
  requires_council_review, council_review_probability,
  design_requirements, approval_requirements, notes
)
VALUES (
  '근린생활시설', '자동차관련시설',
  1,  -- 변경 가능
  30,  -- 최소 1개월
  90,  -- 최대 3개월
  0,   -- 일반적으로 의회 심의 불필요
  '낮음',
  '["용도변경 설계", "폐수처리시설 추가", "상하수도 보강"]',
  '["용도변경 건축허가", "환경과 폐수신고", "토목설계승인"]',
  '근생 → 세차장 용도변경, 설계사무소에서 실시'
);

-- 주택 → 자동차관련시설 세차장
INSERT INTO building_purpose_change_rules (
  from_purpose, to_purpose, is_changeable, change_period_min, change_period_max,
  requires_council_review, council_review_probability,
  design_requirements, approval_requirements, notes
)
VALUES (
  '주택', '자동차관련시설',
  1,  -- 변경 가능
  30,  -- 최소 1개월
  90,  -- 최대 3개월
  1,   -- 주거지역 용도변경은 의회 심의 필요할 가능성
  '중간',
  '["용도변경 설계", "폐수처리시설 신설", "상하수도 설치", "이웃 민원 검토"]',
  '["용도변경 건축허가", "건축심의", "환경과 폐수신고", "의회 심의(경우에 따라)"]',
  '주택 → 세차장 용도변경, 설계사무소에서 실시, 민원 가능성 높음'
);

-- ===== 4. 시군구별 용도변경 추가 규정 =====

-- 서울시: 근린생활 → 세차장
INSERT INTO regional_purpose_change_rules (
  region_code, region_name, from_purpose,
  council_review_required, estimated_period_days, special_conditions, approval_path, notes
)
VALUES (
  '11000', '서울특별시', '근린생활시설',
  0,  -- 의회 심의 불필요
  60,  -- 예상 2개월
  '["용도지역 확인", "도시계획관련 협의"]',
  '건축과 → 환경과 → 사업자등록청',
  '서울시는 근린생활 용도변경이 상대적으로 용이'
);

-- 서울시: 주택 → 세차장
INSERT INTO regional_purpose_change_rules (
  region_code, region_name, from_purpose,
  council_review_required, estimated_period_days, special_conditions, approval_path, notes
)
VALUES (
  '11000', '서울특별시', '주택',
  1,  -- 의회 심의 필수
  90,  -- 예상 3개월
  '["주거지역 용도변경 전문 검토", "이웃 민원 서명", "건축심의회 개최"]',
  '건축과 → 건축심의회 → 의회 → 환경과',
  '서울시 주택 용도변경은 의회 심의 필수, 기간 장소요'
);

-- 부산시: 근린생활 → 세차장
INSERT INTO regional_purpose_change_rules (
  region_code, region_name, from_purpose,
  council_review_required, estimated_period_days, special_conditions, approval_path, notes
)
VALUES (
  '26000', '부산광역시', '근린생활시설',
  0,
  60,
  '["폐수배출시설 입지 검토"]',
  '건축과 → 낙동강유역환경청 협의 → 환경과',
  '부산시는 낙동강 수질관리 강화, 폐수 기준 엄격'
);

-- 부산시: 주택 → 세차장
INSERT INTO regional_purpose_change_rules (
  region_code, region_name, from_purpose,
  council_review_required, estimated_period_days, special_conditions, approval_path, notes
)
VALUES (
  '26000', '부산광역시', '주택',
  1,
  90,
  '["주거지역 특수성", "낙동강 수질영향 검토"]',
  '건축과 → 의회 → 환경과 → 낙동강청',
  '부산시 주택 용도변경 + 낙동강 수질 고려'
);

-- ===== 5. 검수 항목 체크리스트 =====

-- 기존 건축물: 폐수처리시설
INSERT INTO inspection_checklist (category, item_name, requirement, inspection_method, responsible_dept)
VALUES (
  'existing_building',
  '폐수처리시설',
  '일 100m³ 처리 능력의 침전지 또는 유분분리기',
  '설계도면 검토 + 시공 검사',
  '환경과'
);

-- 기존 건축물: 상하수도 연결
INSERT INTO inspection_checklist (category, item_name, requirement, inspection_method, responsible_dept)
VALUES (
  'existing_building',
  '상하수도 연결',
  '기존 상수도 연결 + 하수도 배출',
  '상하수도사업소 협의',
  '상하수도사업소'
);

-- 기존 건축물: 주차장
INSERT INTO inspection_checklist (category, item_name, requirement, inspection_method, responsible_dept)
VALUES (
  'existing_building',
  '주차장 확보',
  '대지 3.3m² 당 1면 이상',
  '건축물대장 + 현장 확인',
  '건축과'
);

-- 나대지: 건축법 설계
INSERT INTO inspection_checklist (category, item_name, requirement, inspection_method, responsible_dept)
VALUES (
  'newland',
  '건축법 설계',
  '자동차관련시설 세차장으로 설계',
  '구조/건축 설계 승인',
  '건축과'
);

-- 나대지: 폐수처리시설 설계
INSERT INTO inspection_checklist (category, item_name, requirement, inspection_method, responsible_dept)
VALUES (
  'newland',
  '폐수처리시설 설계',
  '침전지 + 유분분리기 신설',
  '환경과 폐수배출시설 신고',
  '환경과'
);
