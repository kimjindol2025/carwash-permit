/**
 * 공공데이터 건축물 정보 로더
 * 강남구 + 양주시 샘플 건축물 데이터 생성
 */
const Database = require('better-sqlite3');
const path = require('path');

const dbPath = path.join(__dirname, 'init.db');
const db = new Database(dbPath);

// 테이블 생성
db.exec(`
  CREATE TABLE IF NOT EXISTS buildings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pnu TEXT NOT NULL UNIQUE,
    sido_name TEXT NOT NULL,
    sigungu_cd TEXT NOT NULL,
    bjdong_cd TEXT NOT NULL,
    road_address TEXT,
    jibun_address TEXT,
    building_name TEXT,
    main_purpose TEXT,
    main_purpose_code TEXT,
    detail_purpose TEXT,
    detail_purpose_code TEXT,
    total_area REAL,
    building_area REAL,
    approval_date TEXT,
    construction_date TEXT,
    basement_floor INTEGER,
    above_floor INTEGER,
    created_at DATETIME DEFAULT (datetime('now','localtime'))
  );

  CREATE INDEX IF NOT EXISTS idx_pnu ON buildings(pnu);
  CREATE INDEX IF NOT EXISTS idx_sigungu ON buildings(sigungu_cd);
  CREATE INDEX IF NOT EXISTS idx_address ON buildings(road_address);
`);

// 샘플 데이터: 강남구 (11680)
const gangnamBuildings = [
  {
    pnu: '11680100100000010000',
    sigungu_cd: '11680',
    bjdong_cd: '10100',
    road_address: '서울시 강남구 테헤란로 123',
    jibun_address: '서울시 강남구 역삼동 123',
    building_name: '테헤란빌딩',
    main_purpose: '업무시설',
    main_purpose_code: 'OFC',
    detail_purpose: '일반사무실',
    total_area: 15000,
    building_area: 8000,
    approval_date: '2010-05-15',
    construction_date: '2010-08-20',
    basement_floor: 3,
    above_floor: 10
  },
  {
    pnu: '11680100100000020000',
    sigungu_cd: '11680',
    bjdong_cd: '10100',
    road_address: '서울시 강남구 테헤란로 125',
    jibun_address: '서울시 강남구 역삼동 125',
    building_name: '강남상가',
    main_purpose: '상업시설',
    main_purpose_code: 'COM',
    detail_purpose: '근린상업시설',
    total_area: 5000,
    building_area: 3000,
    approval_date: '2008-03-10',
    construction_date: '2008-06-30',
    basement_floor: 1,
    above_floor: 5
  },
  {
    pnu: '11680100100000030000',
    sigungu_cd: '11680',
    bjdong_cd: '10100',
    road_address: '서울시 강남구 테헤란로 127',
    jibun_address: '서울시 강남구 역삼동 127',
    building_name: '강남아파트',
    main_purpose: '주거시설',
    main_purpose_code: 'RES',
    detail_purpose: '아파트',
    total_area: 25000,
    building_area: 12000,
    approval_date: '2005-06-20',
    construction_date: '2005-10-15',
    basement_floor: 2,
    above_floor: 20
  },
  {
    pnu: '11680100100000040000',
    sigungu_cd: '11680',
    bjdong_cd: '10100',
    road_address: '서울시 강남구 강남대로 456',
    jibun_address: '서울시 강남구 역삼동 456',
    building_name: '삼성전자강남사업소',
    main_purpose: '산업시설',
    main_purpose_code: 'IND',
    detail_purpose: '제조업시설',
    total_area: 35000,
    building_area: 20000,
    approval_date: '2000-01-10',
    construction_date: '2000-05-20',
    basement_floor: 2,
    above_floor: 8
  },
  {
    pnu: '11680100100000050000',
    sigungu_cd: '11680',
    bjdong_cd: '10100',
    road_address: '서울시 강남구 강남대로 500',
    jibun_address: '서울시 강남구 역삼동 500',
    building_name: '강남공영주차장',
    main_purpose: '교통시설',
    main_purpose_code: 'TRN',
    detail_purpose: '주차장',
    total_area: 8000,
    building_area: 2000,
    approval_date: '2015-04-01',
    construction_date: '2015-06-30',
    basement_floor: 3,
    above_floor: 0
  }
];

// 샘플 데이터: 경기 양주시 (31000)
const yangjuBuildings = [
  {
    pnu: '31000002100000010000',
    sigungu_cd: '31000',
    bjdong_cd: '00021',
    road_address: '경기도 양주시 감악산로 123',
    jibun_address: '경기도 양주시 상우동 123',
    building_name: '감악산로 상가',
    main_purpose: '상업시설',
    main_purpose_code: 'COM',
    detail_purpose: '일반음식점',
    total_area: 2500,
    building_area: 1500,
    approval_date: '2012-08-10',
    construction_date: '2012-11-20',
    basement_floor: 1,
    above_floor: 3
  },
  {
    pnu: '31000002100000020000',
    sigungu_cd: '31000',
    bjdong_cd: '00021',
    road_address: '경기도 양주시 감악산로 125',
    jibun_address: '경기도 양주시 상우동 125',
    building_name: '양주 산업단지 공장',
    main_purpose: '산업시설',
    main_purpose_code: 'IND',
    detail_purpose: '제조업시설',
    total_area: 8500,
    building_area: 5000,
    approval_date: '2010-02-15',
    construction_date: '2010-05-30',
    basement_floor: 1,
    above_floor: 2
  },
  {
    pnu: '31000002100000030000',
    sigungu_cd: '31000',
    bjdong_cd: '00021',
    road_address: '경기도 양주시 감악산로 127',
    jibun_address: '경기도 양주시 상우동 127',
    building_name: '감악산 주거용 주택',
    main_purpose: '주거시설',
    main_purpose_code: 'RES',
    detail_purpose: '단독주택',
    total_area: 1200,
    building_area: 700,
    approval_date: '2008-06-20',
    construction_date: '2008-09-10',
    basement_floor: 0,
    above_floor: 2
  },
  {
    pnu: '31000002100000040000',
    sigungu_cd: '31000',
    bjdong_cd: '00021',
    road_address: '경기도 양주시 동국대로 456',
    jibun_address: '경기도 양주시 상우동 456',
    building_name: '양주시청별관',
    main_purpose: '공공시설',
    main_purpose_code: 'PUB',
    detail_purpose: '행정기관',
    total_area: 5000,
    building_area: 3000,
    approval_date: '2014-01-10',
    construction_date: '2014-04-20',
    basement_floor: 1,
    above_floor: 4
  },
  {
    pnu: '31000002100000050000',
    sigungu_cd: '31000',
    bjdong_cd: '00021',
    road_address: '경기도 양주시 덕계로 789',
    jibun_address: '경기도 양주시 상우동 789',
    building_name: '양주 신경영쇼핑',
    main_purpose: '상업시설',
    main_purpose_code: 'COM',
    detail_purpose: '도매시장',
    total_area: 12000,
    building_area: 8000,
    approval_date: '2009-07-15',
    construction_date: '2009-10-30',
    basement_floor: 1,
    above_floor: 3
  }
];

// 데이터 삽입
const insertStmt = db.prepare(`
  INSERT INTO buildings (
    pnu, sido_name, sigungu_cd, bjdong_cd, road_address, jibun_address,
    building_name, main_purpose, main_purpose_code, detail_purpose,
    total_area, building_area, approval_date, construction_date,
    basement_floor, above_floor
  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
`);

const allBuildings = [
  ...gangnamBuildings.map(b => ({ ...b, sido_name: '서울특별시' })),
  ...yangjuBuildings.map(b => ({ ...b, sido_name: '경기도' }))
];

try {
  db.exec('BEGIN');
  allBuildings.forEach(building => {
    insertStmt.run(
      building.pnu,
      building.sido_name,
      building.sigungu_cd,
      building.bjdong_cd,
      building.road_address,
      building.jibun_address,
      building.building_name,
      building.main_purpose,
      building.main_purpose_code,
      building.detail_purpose,
      building.total_area,
      building.building_area,
      building.approval_date,
      building.construction_date,
      building.basement_floor,
      building.above_floor
    );
  });
  db.exec('COMMIT');
  console.log(`✅ ${allBuildings.length}개 건축물 정보 로드 완료`);
} catch (err) {
  console.error('❌ 데이터 로드 실패:', err.message);
}

// 검증
const count = db.prepare('SELECT COUNT(*) as cnt FROM buildings').get();
console.log(`📊 총 ${count.cnt}개 건축물이 DB에 저장되었습니다`);

db.close();
