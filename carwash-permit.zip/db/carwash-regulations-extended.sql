-- ===== 세차장 허가 - 확장 테이블 (통합 매트릭스용) =====
-- 작성일: 2026-03-30
-- 목적: 5개 신규 테이블 추가 (지역별 절차, 용도변경, 도로기준, 상하수도, 비용추정)

-- ===== Table 1: region_approval_procedures (지역별 승인 절차 및 소요시간) =====
CREATE TABLE IF NOT EXISTS region_approval_procedures (
  id INTEGER PRIMARY KEY AUTOINCREMENT,

  -- 기본 정보
  region_code TEXT NOT NULL UNIQUE,        -- 'SEOUL', 'BUSAN', 'GYEONGGI' 등
  region_name TEXT NOT NULL,               -- '서울시', '부산시' 등
  province TEXT,                           -- '경기도', '강원도' 등

  -- 승인 기관
  primary_authority TEXT,                  -- 주담당: 도시계획과
  environment_authority TEXT,              -- 환경청/도청
  road_authority TEXT,                     -- 도로교통과

  -- 절차별 소요시간 (Phase별)
  phase_1_name TEXT DEFAULT '입지선정',
  phase_1_time_days_min INTEGER,
  phase_1_time_days_max INTEGER,

  phase_2_name TEXT DEFAULT '건축판정',
  phase_2_time_days_min INTEGER,
  phase_2_time_days_max INTEGER,

  phase_3_name TEXT DEFAULT '도로접근',
  phase_3_time_days_min INTEGER,
  phase_3_time_days_max INTEGER,

  phase_4_name TEXT DEFAULT '주차외부시설',
  phase_4_time_days_min INTEGER,
  phase_4_time_days_max INTEGER,

  phase_5_name TEXT DEFAULT '폐수신고',
  phase_5_time_days_min INTEGER,
  phase_5_time_days_max INTEGER,

  total_time_min INTEGER,                  -- 최소 일수
  total_time_max INTEGER,                  -- 최대 일수

  -- 지역 특성 (성공확률)
  success_rate_industrial_pct REAL,        -- 준공업지역 성공률 (%)
  success_rate_commercial_pct REAL,        -- 상업지역 성공률 (%)
  success_rate_semi_residential_pct REAL,  -- 준주택지역 성공률 (%)

  housing_distance_critical_m INTEGER,     -- 주택 임계 거리 (m)
  housing_distance_safe_m INTEGER,         -- 주택 안전 거리 (m)

  -- 특수 조건 (JSON)
  special_requirements TEXT,               -- JSON: 지역별 특화 조건

  -- 환경 난이도
  environmental_difficulty TEXT,           -- 'very_easy', 'easy', 'medium', 'hard', 'very_hard'
  basin TEXT,                              -- '한강', '낙동강', '금강', '영산강'

  -- 비용
  estimated_cost_min_man_won INTEGER,      -- 최소 비용 (만원)
  estimated_cost_max_man_won INTEGER,      -- 최대 비용 (만원)

  -- 메타데이터
  notes TEXT,
  last_updated DATE,
  created_at TEXT DEFAULT (datetime('now','localtime')),
  updated_at TEXT DEFAULT (datetime('now','localtime'))
);

-- 인덱스
CREATE INDEX IF NOT EXISTS idx_region_code ON region_approval_procedures(region_code);
CREATE INDEX IF NOT EXISTS idx_region_success_industrial ON region_approval_procedures(success_rate_industrial_pct DESC);
CREATE INDEX IF NOT EXISTS idx_region_basin ON region_approval_procedures(basin);

-- 샘플 데이터 삽입
INSERT OR IGNORE INTO region_approval_procedures (
  region_code, region_name, province, primary_authority, environment_authority, road_authority,
  phase_1_time_days_min, phase_1_time_days_max,
  phase_2_time_days_min, phase_2_time_days_max,
  phase_3_time_days_min, phase_3_time_days_max,
  phase_4_time_days_min, phase_4_time_days_max,
  phase_5_time_days_min, phase_5_time_days_max,
  total_time_min, total_time_max,
  success_rate_industrial_pct, success_rate_commercial_pct, success_rate_semi_residential_pct,
  housing_distance_critical_m, housing_distance_safe_m,
  environmental_difficulty, basin,
  estimated_cost_min_man_won, estimated_cost_max_man_won,
  notes
) VALUES
  ('GYEONGGI', '경기도', '경기도', '도시계획과', '환경청', '도로교통과',
   1, 2, 15, 30, 7, 14, 5, 10, 10, 15,
   35, 50, 90, 75, 40, 200, 200,
   'easy', '한강/영산강', 5000, 8000,
   '준공업지역 충분, 입지 선택 여유'),

  ('SEOUL', '서울시', '서울시', '도시계획과', '환경청', '도로교통과',
   2, 3, 20, 40, 7, 15, 7, 14, 10, 20,
   45, 90, 65, 60, 35, 150, 200,
   'hard', '한강', 8000, 13000,
   '주택근접, 환경기준 최엄격'),

  ('BUSAN', '부산시', '부산광역시', '도시계획과', '환경청', '도로교통과',
   1, 2, 15, 30, 7, 14, 5, 10, 10, 15,
   45, 70, 75, 70, 35, 200, 200,
   'medium', '낙동강', 6500, 10000,
   '공단발달, 도로접면 용이'),

  ('DAEJEON', '대전시', '대전광역시', '도시계획과', '환경청', '도로교통과',
   1, 2, 12, 25, 5, 10, 5, 10, 10, 15,
   40, 55, 85, 80, 50, 200, 250,
   'very_easy', '금강', 6000, 9000,
   '준공업 충분, 환경기준 표준');

---

-- ===== Table 2: zone_usage_change_process (용도변경 프로세스) =====
CREATE TABLE IF NOT EXISTS zone_usage_change_process (
  id INTEGER PRIMARY KEY AUTOINCREMENT,

  -- 변경 정보
  from_zone_code TEXT NOT NULL,            -- 'residential', 'commercial', 'industrial' 등
  from_zone_name TEXT,                     -- '주택지역' →
  to_zone_code TEXT NOT NULL,              -- '준공업지역' 등
  to_zone_name TEXT,

  region_code TEXT,                        -- 지자체 코드

  -- 변경 가능성
  change_possible INTEGER DEFAULT 0,       -- 1: 가능, 0: 불가능
  change_difficulty TEXT,                  -- 'very_easy', 'easy', 'hard', 'impossible'

  -- 절차 정보
  required_approval TEXT,                  -- 'none', 'local_council', 'provincial_gov', 'ministry'
  procedure_steps TEXT,                    -- JSON: 단계별 절차

  -- 소요 시간/비용
  time_days_min INTEGER,
  time_days_max INTEGER,
  cost_min_man_won INTEGER,                -- 만원
  cost_max_man_won INTEGER,

  -- 법적 근거
  legal_basis TEXT,                        -- '도시계획법 §13' 등

  -- 판례/사례
  precedent_count INTEGER,
  success_rate_pct REAL,                   -- 성공률

  -- 메타데이터
  notes TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

-- 인덱스
CREATE INDEX IF NOT EXISTS idx_zone_change ON zone_usage_change_process(from_zone_code, to_zone_code);
CREATE INDEX IF NOT EXISTS idx_change_difficulty ON zone_usage_change_process(change_difficulty);

-- 샘플 데이터
INSERT OR IGNORE INTO zone_usage_change_process (
  from_zone_code, from_zone_name, to_zone_code, to_zone_name, region_code,
  change_possible, change_difficulty, required_approval,
  time_days_min, time_days_max, cost_min_man_won, cost_max_man_won,
  legal_basis, success_rate_pct, notes
) VALUES
  ('residential', '주택지역', 'commercial', '상업지역', 'SEOUL',
   1, 'hard', 'provincial_gov', 60, 120, 1000, 3000,
   '도시계획법 §13', 5,
   '주택→상업: 매우 어려움, 도시계획위원회 심의 필수'),

  ('semi_residential', '준주택지역', 'industrial', '준공업지역', 'INCHEON',
   1, 'easy', 'local_council', 30, 60, 500, 1500,
   '도시계획법 §13', 85,
   '준주택→준공업: 비교적 용이, 인천시 선례 다수'),

  ('commercial', '상업지역', 'industrial', '준공업지역', 'BUSAN',
   1, 'very_easy', 'local_council', 15, 30, 300, 1000,
   '도시계획법 §13', 95,
   '상업→준공업: 쉬움'),

  ('warehouse', '창고용', 'commercial', '상업지역', 'GYEONGGI',
   1, 'easy', 'local_council', 20, 40, 400, 1200,
   '도시계획법 §13', 90,
   '창고→상업: 비교적 용이');

---

-- ===== Table 3: road_access_standards (도로 접면 기준) =====
CREATE TABLE IF NOT EXISTS road_access_standards (
  id INTEGER PRIMARY KEY AUTOINCREMENT,

  -- 도로 정보
  road_type TEXT NOT NULL,                 -- 'highway', 'provincial_road', 'local_road', 'village_road'
  road_category TEXT,                      -- '고속도로', '국도', '지방도', '시도도', '군도', '리도'
  road_name TEXT,                          -- '경부고속도로', '제1호 지방도' 등

  -- 접면 기준
  required_width_meters INTEGER,           -- 필수 최소 도로 접면 (8m)
  optional_width_meters INTEGER,           -- 권장 (10m)
  minimum_front_length_m INTEGER,          -- 최소 전면 길이 (m)

  -- 진출입 요구사항
  driveway_width_min_m REAL,               -- 2.5m 이상
  driveway_width_recommended_m REAL,       -- 3.5m 이상
  driveway_type TEXT,                      -- 'exclusive' (전용), 'shared' (공유), 'access_route' (접근로)

  -- 기타 요구사항
  safety_requirements TEXT,                -- JSON: 안전펜스, 신호등 등
  visibility_meters INTEGER,               -- 최소 시야확보거리 (30m)
  traffic_control TEXT,                    -- '신호등', '일시정지', '없음'

  -- 도로점용 허가
  occupation_permit_required INTEGER,      -- 1: 필수, 0: 불필요
  occupation_permit_cost_man_won INTEGER,  -- 만원
  occupation_permit_days INTEGER,          -- 소요일수 (7~14일)

  -- 설계 기준
  design_standard_code TEXT,               -- '도로법 §40' 등

  -- 제한 사항
  prohibited_scenarios TEXT,               -- JSON: 불가능한 시나리오
  problem_level TEXT,                      -- 'critical' (즉시실패), 'warning' (주의), 'minor' (작음)

  -- 메타데이터
  legal_basis TEXT,
  notes TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

-- 인덱스
CREATE INDEX IF NOT EXISTS idx_road_type ON road_access_standards(road_type);
CREATE INDEX IF NOT EXISTS idx_required_width ON road_access_standards(required_width_meters);

-- 샘플 데이터
INSERT OR IGNORE INTO road_access_standards (
  road_type, road_category, required_width_meters, optional_width_meters,
  driveway_width_min_m, driveway_width_recommended_m, driveway_type,
  visibility_meters, occupation_permit_required, occupation_permit_days,
  design_standard_code, legal_basis, notes
) VALUES
  ('provincial_road', '지방도', 8, 10, 2.5, 3.5, 'exclusive',
   30, 1, 7, '도로법 §40', '도로법 §37',
   '지방도 접면: 안전도로접근 필수'),

  ('local_road', '시도도', 6, 8, 2.5, 3.5, 'shared',
   20, 0, 0, '도로법 §40', '도로법 §37',
   '시도도 접면: 비교적 유리'),

  ('village_road', '리도/골목길', 4, 6, 2.0, 2.5, 'shared',
   15, 0, 0, '도로법 §40', '도로법 §37',
   '골목길: 진출입로 문제, 추가심의 가능성 높음');

---

-- ===== Table 4: water_sewage_standards (상수도/하수도 연결 기준) =====
CREATE TABLE IF NOT EXISTS water_sewage_standards (
  id INTEGER PRIMARY KEY AUTOINCREMENT,

  -- 지역 정보
  region_code TEXT,                        -- '서울', '부산' 등
  region_name TEXT,
  basin TEXT,                              -- '한강', '낙동강', '금강', '영산강'

  -- 상수도 연결
  water_supply_available INTEGER,          -- 1: 가능, 0: 불가능
  water_supply_coverage_pct REAL,          -- 보급률 (%)
  water_connection_cost_min_man_won INTEGER,
  water_connection_cost_max_man_won INTEGER,
  water_connection_days INTEGER,

  -- 공공하수도 연결
  public_sewage_available INTEGER,         -- 1: 가능, 0: 불가능
  public_sewage_coverage_pct REAL,
  public_connection_cost_min_man_won INTEGER,
  public_connection_cost_max_man_won INTEGER,
  public_connection_days INTEGER,

  -- 정화조 (공공하수도 불가 시)
  septic_tank_required INTEGER,            -- 1: 필수, 0: 선택
  septic_tank_capacity_formula TEXT,       -- '일일배출량/10'
  septic_tank_cost_min_man_won INTEGER,
  septic_tank_cost_max_man_won INTEGER,

  -- 폐수 처리 기준 (수질환경보전법)
  emission_standard_zone TEXT,             -- 'A' (청정), 'B' (가), 'C' (나)

  oil_content_limit_mg_l REAL,             -- 유분 mg/L
  ss_limit_mg_l REAL,                      -- 부유물질 SS mg/L
  bod_limit_mg_l REAL,                     -- 생화학산소요구량 BOD mg/L
  cod_limit_mg_l REAL,                     -- 화학산소요구량 COD mg/L
  total_nitrogen_mg_l REAL,                -- 전질소 mg/L
  total_phosphorus_mg_l REAL,              -- 전인 mg/L

  -- 검사 주기
  inspection_frequency TEXT,               -- 'quarterly', 'semi_annual', 'annual'
  inspection_cost_per_time_man_won INTEGER,

  -- 유지관리
  maintenance_frequency TEXT,
  maintenance_cost_per_time_man_won INTEGER,

  -- 메타데이터
  legal_basis TEXT,
  notes TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

-- 인덱스
CREATE INDEX IF NOT EXISTS idx_region_sewage ON water_sewage_standards(region_code);
CREATE INDEX IF NOT EXISTS idx_basin_standards ON water_sewage_standards(basin);

-- 샘플 데이터 (한강유역, 낙동강유역 등)
INSERT OR IGNORE INTO water_sewage_standards (
  region_code, region_name, basin,
  water_supply_available, water_supply_coverage_pct,
  public_sewage_available, public_sewage_coverage_pct,
  emission_standard_zone,
  oil_content_limit_mg_l, ss_limit_mg_l, bod_limit_mg_l, cod_limit_mg_l,
  inspection_frequency, inspection_cost_per_time_man_won,
  maintenance_frequency, maintenance_cost_per_time_man_won,
  legal_basis, notes
) VALUES
  ('SEOUL', '서울시', '한강', 1, 100, 1, 100, 'B',
   1, 15, 5, 15, 'quarterly', 100,
   'monthly', 100, '수질환경보전법 별표13', '한강유역 최엄격 (유분 1mg/L)'),

  ('BUSAN', '부산시', '낙동강', 1, 98, 1, 98, 'B',
   1.5, 18, 5, 15, 'quarterly', 80,
   'monthly', 80, '수질환경보전법 별표13', '낙동강유역 강화 (유분 1.5mg/L)'),

  ('DAEJEON', '대전시', '금강', 1, 99, 1, 99, 'B',
   2, 20, 5, 15, 'semi_annual', 50,
   'quarterly', 50, '수질환경보전법 별표13', '금강유역 표준 (유분 2mg/L)');

---

-- ===== Table 5: cost_estimation (지역별/상황별 비용 추정) =====
CREATE TABLE IF NOT EXISTS cost_estimation (
  id INTEGER PRIMARY KEY AUTOINCREMENT,

  -- 프로젝트 정보
  scenario_name TEXT NOT NULL,             -- '경기도 준공업', '서울 상업' 등
  scenario_code TEXT,
  region_code TEXT,
  zone_code TEXT,

  -- 초기투자 비용 (만원)
  land_building_cost_min_man_won INTEGER,
  land_building_cost_max_man_won INTEGER,

  wastewater_facility_cost_min_man_won INTEGER,
  wastewater_facility_cost_max_man_won INTEGER,

  parking_facility_cost_min_man_won INTEGER,
  parking_facility_cost_max_man_won INTEGER,

  external_facility_cost_min_man_won INTEGER,
  external_facility_cost_max_man_won INTEGER,

  environmental_assessment_cost_min_man_won INTEGER,
  environmental_assessment_cost_max_man_won INTEGER,

  design_consultation_cost_min_man_won INTEGER,
  design_consultation_cost_max_man_won INTEGER,

  legal_consultation_cost_min_man_won INTEGER,
  legal_consultation_cost_max_man_won INTEGER,

  -- 초기 투자 소계
  initial_investment_min_man_won INTEGER,
  initial_investment_max_man_won INTEGER,

  -- 월간 운영 비용 (만원/월)
  water_quality_test_monthly_man_won INTEGER,
  septic_cleaning_per_quarter_man_won INTEGER,
  environmental_technician_monthly_man_won INTEGER,
  environmental_insurance_monthly_man_won INTEGER,
  wastewater_treatment_monthly_man_won INTEGER,
  other_monthly_man_won INTEGER,

  -- 월간 합계
  monthly_operational_cost_min_man_won INTEGER,
  monthly_operational_cost_max_man_won INTEGER,

  -- 연간 합계
  annual_operational_cost_min_man_won INTEGER,
  annual_operational_cost_max_man_won INTEGER,

  -- 1년 전체 (초기+운영)
  total_first_year_min_man_won INTEGER,
  total_first_year_max_man_won INTEGER,

  -- 메타데이터
  success_rate_pct REAL,
  estimated_payback_years REAL,
  difficulty_level TEXT,                   -- 'very_easy', 'easy', 'medium', 'hard'

  notes TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

-- 인덱스
CREATE INDEX IF NOT EXISTS idx_cost_region ON cost_estimation(region_code);
CREATE INDEX IF NOT EXISTS idx_cost_zone ON cost_estimation(zone_code);

-- 샘플 데이터
INSERT OR IGNORE INTO cost_estimation (
  scenario_name, scenario_code, region_code, zone_code,
  land_building_cost_min_man_won, land_building_cost_max_man_won,
  wastewater_facility_cost_min_man_won, wastewater_facility_cost_max_man_won,
  parking_facility_cost_min_man_won, parking_facility_cost_max_man_won,
  external_facility_cost_min_man_won, external_facility_cost_max_man_won,
  environmental_assessment_cost_min_man_won, environmental_assessment_cost_max_man_won,
  design_consultation_cost_min_man_won, design_consultation_cost_max_man_won,
  initial_investment_min_man_won, initial_investment_max_man_won,
  water_quality_test_monthly_man_won,
  septic_cleaning_per_quarter_man_won,
  environmental_technician_monthly_man_won,
  environmental_insurance_monthly_man_won,
  wastewater_treatment_monthly_man_won,
  monthly_operational_cost_min_man_won, monthly_operational_cost_max_man_won,
  annual_operational_cost_min_man_won, annual_operational_cost_max_man_won,
  total_first_year_min_man_won, total_first_year_max_man_won,
  success_rate_pct, estimated_payback_years, difficulty_level, notes
) VALUES
  ('경기도 준공업지역 (Best)', 'GG_INDUSTRIAL_BEST', 'GYEONGGI', 'industrial',
   3000, 5000, 1500, 3000, 500, 800, 200, 400, 0, 0, 300, 500,
   5000, 8000,
   50, 50, 250, 30, 50,
   360, 500, 4320, 6000, 9500, 14000,
   90, 3.5, 'very_easy', '최상의 입지 (준공업+주택거리 확보)'),

  ('서울시 상업지역 (Medium)', 'SEOUL_COMMERCIAL_MEDIUM', 'SEOUL', 'commercial',
   5000, 8000, 2000, 4000, 800, 1200, 300, 500, 800, 1500, 500, 1000,
   8000, 13000,
   100, 100, 300, 50, 100,
   400, 550, 4800, 6600, 13500, 19700,
   65, 4.5, 'hard', '상업지역 + 주택근접 조건'),

  ('대전시 준공업지역 (Good)', 'DJ_INDUSTRIAL_GOOD', 'DAEJEON', 'industrial',
   3000, 5000, 1200, 2500, 500, 700, 200, 400, 0, 0, 200, 400,
   4500, 7500,
   50, 50, 250, 25, 50,
   340, 450, 4080, 5400, 8800, 12900,
   85, 3.2, 'easy', '양호한 입지 (충청지역)');

---

-- 전체 인덱스 생성 완료 확인
CREATE INDEX IF NOT EXISTS idx_cest_scenario ON cost_estimation(scenario_name);
CREATE INDEX IF NOT EXISTS idx_cest_difficulty ON cost_estimation(difficulty_level);

-- 테이블 통계
-- SELECT COUNT(*) FROM region_approval_procedures;
-- SELECT COUNT(*) FROM zone_usage_change_process;
-- SELECT COUNT(*) FROM road_access_standards;
-- SELECT COUNT(*) FROM water_sewage_standards;
-- SELECT COUNT(*) FROM cost_estimation;

-- 작성일: 2026-03-30
-- 상태: ✅ 확장 테이블 5개 정의 완료
