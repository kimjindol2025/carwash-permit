const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const DB_PATH = path.join(__dirname, 'shop.db');
const db = new Database(DB_PATH);

// WAL 모드 (동시 읽기 성능 향상)
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// 테이블 생성
const schema = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
db.exec(schema);

// P1-1: 정부 데이터 로드 (zone_info + development_permits)
const zoneCount = db.prepare('SELECT COUNT(*) as count FROM zone_info').get().count;
if (zoneCount === 0) {
  console.log('⏳ 정부 데이터 로드 중 (zone_info, development_permits)...');
  try {
    // zone_info CSV 로드 (175K 정부 데이터)
    const loadGovDataScript = path.join(__dirname, 'load-gov-data.js');
    if (fs.existsSync(loadGovDataScript)) {
      require('./load-gov-data');
    }

    // development_permits CSV 로드 (183K 건축물대장)
    const loadDevDataScript = path.join(__dirname, 'load-dev-data.js');
    if (fs.existsSync(loadDevDataScript)) {
      require('./load-dev-data');
    }

    const zoneLoaded = db.prepare('SELECT COUNT(*) as count FROM zone_info').get().count;
    const devLoaded = db.prepare('SELECT COUNT(*) as count FROM development_permits').get().count;
    console.log(`✅ 정부 데이터 로드 완료: zone_info ${zoneLoaded}개, development_permits ${devLoaded}개`);
  } catch (err) {
    console.warn('⚠️ 정부 데이터 로드 중 오류:', err.message.slice(0, 100));
  }
}

// 시드 데이터: 카테고리 2개 (장비 / 서비스)
const categories = [
  { name: '장비', slug: 'equipment', sort_order: 1 },
  { name: '서비스', slug: 'service', sort_order: 2 }
];

// 기존 카테고리 개수 확인
const categoryCount = db.prepare('SELECT COUNT(*) as count FROM categories').get().count;

if (categoryCount === 0) {
  const insertCategory = db.prepare(`
    INSERT INTO categories (name, slug, sort_order)
    VALUES (?, ?, ?)
  `);

  categories.forEach(cat => {
    insertCategory.run(cat.name, cat.slug, cat.sort_order);
  });

  // 시드 상품: 7개 (장비 3개 + 서비스 4개)
  const sampleProducts = [
    // 장비 (category_id=1)
    {
      category_id: 1,
      name: '폐수처리기',
      description: '세차장 필수 장비. 자동차 세차 폐수 정화 처리기 (용량: 500L/일)',
      price: 4500000,
      stock: 10,
      image_url: null,
      options: '["300L", "500L", "800L"]',
      is_active: 1,
      sort_order: 1
    },
    {
      category_id: 1,
      name: '진공청소기',
      description: '고급형 업소용 진공청소기. 카펫 및 내부 청소용 (용량: 60L)',
      price: 1800000,
      stock: 8,
      image_url: null,
      options: '["60L", "100L"]',
      is_active: 1,
      sort_order: 2
    },
    {
      category_id: 1,
      name: '고압세척기',
      description: '고압분무 세척기. 차체 및 바닥 세척용 (압력: 120-150bar)',
      price: 5200000,
      stock: 5,
      image_url: null,
      options: '["120bar", "150bar"]',
      is_active: 1,
      sort_order: 3
    },
    // 서비스 (category_id=2)
    {
      category_id: 2,
      name: '설계비 (용도변경)',
      description: '건축물대장 용도변경 설계 및 신청 절차. 전문가 설계도 작성 포함',
      price: 1500000,
      stock: 999,
      image_url: null,
      options: '["기본형", "상세형"]',
      is_active: 1,
      sort_order: 1
    },
    {
      category_id: 2,
      name: '인허가비 (폐수인허가)',
      description: '폐수배출시설 설치신고 및 인허가 전담. 관청 처리 일체',
      price: 8000000,
      stock: 999,
      image_url: null,
      options: '["신규", "변경"]',
      is_active: 1,
      sort_order: 2
    },
    {
      category_id: 2,
      name: '인테리어',
      description: '세차장 시공 및 인테리어. 매장 설계부터 완공까지',
      price: 12000000,
      stock: 999,
      image_url: null,
      options: '["기본형 (20평)", "프리미엄 (30평)"]',
      is_active: 1,
      sort_order: 3
    },
    {
      category_id: 2,
      name: '토목공사',
      description: '세차장 부지 정지, 배수, 포장 등 토목공사. 현장 실측 및 설계 포함',
      price: 30000000,
      stock: 999,
      image_url: null,
      options: '["소규모 (200㎡)", "대규모 (500㎡)"]',
      is_active: 1,
      sort_order: 4
    }
  ];

  const insertProduct = db.prepare(`
    INSERT INTO products
    (category_id, name, description, price, stock, image_url, options, is_active, sort_order)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  sampleProducts.forEach(prod => {
    insertProduct.run(
      prod.category_id,
      prod.name,
      prod.description,
      prod.price,
      prod.stock,
      prod.image_url,
      prod.options,
      prod.is_active,
      prod.sort_order
    );
  });

  console.log('✅ DB 초기화 완료: 카테고리 2개 (장비/서비스), 상품 7개');
}

// 유틸리티: 주문번호 생성
function generateOrderNumber() {
  const date = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const count = db.prepare('SELECT COUNT(*) as c FROM orders WHERE order_number LIKE ?')
    .get(`ORD-${date}-%`).c + 1;
  return `ORD-${date}-${String(count).padStart(4, '0')}`;
}

// ===== 관리자 시스템 초기화 =====
const crypto = require('crypto');

// 기본 관리자 계정 생성
const adminCount = db.prepare('SELECT COUNT(*) as count FROM admin_users').get().count;
if (adminCount === 0) {
  const adminPassword = crypto.createHash('sha256').update('carwash2024').digest('hex');
  db.prepare(`
    INSERT INTO admin_users (username, password, role, is_active)
    VALUES (?, ?, ?, ?)
  `).run('admin', adminPassword, 'admin', 1);
  console.log('✅ 관리자 계정 생성: admin / carwash2024');
}

// ===== 규정 데이터베이스 초기화 =====
const REGULATIONS_DB_PATH = path.join(__dirname, 'regulations.db');
let regulationsDb = null;

try {
  regulationsDb = new Database(REGULATIONS_DB_PATH);
  regulationsDb.pragma('journal_mode = WAL');
  regulationsDb.pragma('foreign_keys = ON');

  // 규정 스키마 생성
  const regulationSchema = fs.readFileSync(path.join(__dirname, 'carwash-regulations.sql'), 'utf8');
  regulationsDb.exec(regulationSchema);

  // 자동차관련시설 상세 스키마 생성
  const automotiveFacilitiesSchema = fs.readFileSync(path.join(__dirname, 'automotive-facilities-detailed.sql'), 'utf8');
  regulationsDb.exec(automotiveFacilitiesSchema);

  // 규정 시드 데이터 입력 (테이블이 비어있을 때만)
  const zoneCount = regulationsDb.prepare('SELECT COUNT(*) as count FROM land_use_zones').get().count;
  if (zoneCount === 0) {
    const regulationSeed = fs.readFileSync(path.join(__dirname, 'carwash-regulations-seed.sql'), 'utf8');
    regulationsDb.exec(regulationSeed);
    console.log('✅ 규정 DB 초기화 완료: 용도지역 19개, 수질기준 20개, 필수서류 20개, 관공서 6개, 판정규칙 6개');
  }

  // 자동차시설 시드 데이터 입력 (테이블이 비어있을 때만)
  const facilityCount = regulationsDb.prepare('SELECT COUNT(*) as count FROM automotive_facility_types').get().count;
  if (facilityCount === 0) {
    const automotiveSeed = fs.readFileSync(path.join(__dirname, 'automotive-facilities-seed.sql'), 'utf8');
    regulationsDb.exec(automotiveSeed);
    console.log('✅ 자동차시설 DB 초기화 완료: 주차장/세차장/정비공장 법률기준, 40개 용도지역 매트릭스, 환경기준, 인허가 규정');
  }

  // 지자체 조례 스키마 생성
  const localOrdinancesSchema = fs.readFileSync(path.join(__dirname, 'local-ordinances.sql'), 'utf8');
  regulationsDb.exec(localOrdinancesSchema);

  // 지자체 조례 시드 데이터 입력 (테이블이 비어있을 때만)
  const ordinanceCount = regulationsDb.prepare('SELECT COUNT(*) as count FROM local_ordinances').get().count;
  if (ordinanceCount === 0) {
    const ordinanceSeed = fs.readFileSync(path.join(__dirname, 'local-ordinances-seed.sql'), 'utf8');
    regulationsDb.exec(ordinanceSeed);
    console.log('✅ 지자체 조례 DB 초기화 완료: 17개 시도/광역시, 폐수처리시설 기준, 담당부서 정보');
  }

  // 세차장 허가 의사결정 엔진 스키마 생성
  const carwashPermitSchema = fs.readFileSync(path.join(__dirname, 'carwash-permit-rules.sql'), 'utf8');
  regulationsDb.exec(carwashPermitSchema);

  // 세차장 허가 의사결정 엔진 시드 데이터 입력 (테이블이 비어있을 때만)
  const buildingJudgementCount = regulationsDb.prepare('SELECT COUNT(*) as count FROM existing_building_judgement').get().count;
  if (buildingJudgementCount === 0) {
    const carwashPermitSeed = fs.readFileSync(path.join(__dirname, 'carwash-permit-rules-seed.sql'), 'utf8');
    regulationsDb.exec(carwashPermitSeed);
    console.log('✅ 세차장 허가 의사결정 엔진 초기화 완료: 기존건물 판정, 나대지 규칙, 용도변경 프로세스, 시군 조례');
  }

  // 법령 통합 데이터베이스 스키마 로드
  try {
    const legalFrameworkSchema = fs.readFileSync(path.join(__dirname, 'legal-frameworks.sql'), 'utf8');
    regulationsDb.exec(legalFrameworkSchema);
    console.log('✅ 법령 통합 데이터 로드 완료: 5개 법령, 90개 항목');
  } catch (err) {
    console.warn('⚠️ 법령 데이터 로드 중 주의:', err.message.slice(0, 100));
  }

  // 유역별 폐수처리 기준 테이블 생성 (이미 존재하는 경우 스킵)
  try {
    regulationsDb.exec(`
      CREATE TABLE IF NOT EXISTS carwash_actual_requirements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        requirement_number INTEGER NOT NULL,
        title TEXT NOT NULL,
        description TEXT,
        details TEXT,
        critical_notes TEXT,
        source TEXT DEFAULT '빅워시 운영 경험',
        created_at TEXT DEFAULT (datetime('now','localtime'))
      );
    `);
    console.log('✅ 세차장 실제 요구사항 테이블 생성 완료');
  } catch (err) {
    // 테이블이 이미 존재하는 경우 무시
  }

  // 사용자 9개 실제 요구사항 데이터 입력 (테이블이 비어있을 때만)
  try {
    const actualRequirementsCount = regulationsDb.prepare('SELECT COUNT(*) as count FROM carwash_actual_requirements').get().count;
    if (actualRequirementsCount === 0) {
      const actualRequirementsData = [
        { num: 1, title: '토지 용도지역 확인', desc: '토지 용도는 고정되어 있어 변경 불가능', details: '✅ 가능: 자연지역(협의), 관리지역, 상업지역, 준공업지역, 공업지역', notes: '첫 번째 필터링' },
        { num: 2, title: '건물 용도 (자동차관련시설)', desc: '건축물 용도가 자동차관련시설로 등록되어야 함', details: '기존 건물: 용도변경 신고/허가 필요 (건축과)', notes: '설계사무소에서 변경 가능' },
        { num: 3, title: '하수도/우수 연결', desc: '공공 하수도 또는 우수 연결 필수', details: '배수설비 필증 신청: 시/군/구청 상하수도과', notes: '기존 허가증 있으면 재신청 불필요' },
        { num: 4, title: '폐수처리시설 설치 (필수)', desc: '세차장은 100% 폐수처리시설 필수', details: '침전지 → 유분분리기 → 여과시설 → 배출', notes: '유분분리기는 코알레서 권장' },
        { num: 5, title: '폐수배출신고 (vs 허가)', desc: '신축 시 신고, 용도변경 후 세차장 시 허가 필수', details: '신고 1주 vs 허가 4~6주', notes: '용도변경 시 반드시 허가, 신고 아님' },
        { num: 6, title: '폐수처리기 설치 (1년 내)', desc: '신고/허가 획득 후 1년 이내 설치 완료 필수', details: '1년 경과 시 신고/허가 실효', notes: '⭐ 정확히 1년 계산하여 설치완료신고' },
        { num: 7, title: '등록업체만 가능', desc: '환경부 등록 폐수처리시설 설치업체만 가능', details: '개인업체/미등록 업체 불가능', notes: '미등록 업체 계약 시 공사 무효' },
        { num: 8, title: '설치완료신고 (2단계)', desc: '설치 전 신고 + 설치 완료 신고', details: '설치완료신고서 제출 → 현장 확인 (2주)', notes: '필수 첨부: 사진, 기술기준, 설명서' },
        { num: 9, title: '운영 (직영 vs 위탁)', desc: '2가지 선택: 직영(월 100~150만원) vs 위탁(월 50~150만원)', details: '대부분 전문업체 위탁 권장', notes: '99%는 전문업체 위탁 선택' }
      ];

      const insertActualReq = regulationsDb.prepare(`
        INSERT INTO carwash_actual_requirements
        (requirement_number, title, description, details, critical_notes, source)
        VALUES (?, ?, ?, ?, ?, '빅워시 운영 경험')
      `);

      actualRequirementsData.forEach(req => {
        insertActualReq.run(req.num, req.title, req.desc, req.details, req.notes);
      });

      console.log('✅ 9개 세차장 실제 요구사항 로드 완료');
    }
  } catch (err) {
    console.warn('⚠️ 실제 요구사항 로드 중 주의:', err.message.slice(0, 100));
  }

  // 유역별 폐수처리 기준 테이블 생성 및 데이터 로드
  try {
    regulationsDb.exec(`
      CREATE TABLE IF NOT EXISTS regional_wastewater_standards (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        region_code TEXT NOT NULL,
        facility_type TEXT NOT NULL,
        capacity_min REAL,
        capacity_max REAL,
        material_requirement TEXT,
        maintenance_frequency TEXT,
        inspection_requirement TEXT,
        law_reference TEXT,
        created_at TEXT DEFAULT (datetime('now','localtime'))
      );
    `);

    const wasteWaterCount = regulationsDb.prepare('SELECT COUNT(*) as count FROM regional_wastewater_standards').get().count;
    if (wasteWaterCount === 0) {
      const wasteWaterData = [
        { rc: '11000', ft: '유분분리기', cmin: 0.5, cmax: 100, mat: '코알레서 또는 익스트랙션 타입 (효율 85% 이상)', maint: '월 1회 이상', insp: '분기 1회 정기점검, 폐유 처리 기록 필수', ref: '한강유역환경청' },
        { rc: '11000', ft: '침전지', cmin: 1, cmax: 500, mat: '콘크리트 구조, 2시간 체류 가능 용량', maint: '월 1회 청소', insp: '분기 1회 수질검사', ref: '한강 (1.0 mg/L)' },
        { rc: '11000', ft: '여과시설', cmin: 0.5, cmax: 100, mat: '모래+활성탄 2단 필터', maint: '월 1회 필터 교체', insp: '분기 1회 정기점검', ref: '한강' },
        { rc: '28000', ft: '유분분리기', cmin: 0.5, cmax: 100, mat: '코알레서 또는 익스트랙션 타입 (효율 85% 이상)', maint: '월 1회 이상', insp: '분기 1회 정기점검', ref: '한강유역 (인천)' },
        { rc: '28000', ft: '침전지', cmin: 1, cmax: 500, mat: '콘크리트 구조, 2시간 체류 가능 용량', maint: '월 1회 청소', insp: '분기 1회 수질검사', ref: '한강 (1.0 mg/L)' },
        { rc: '41000', ft: '유분분리기', cmin: 0.5, cmax: 100, mat: '코알레서 또는 익스트랙션 타입 (효율 85% 이상)', maint: '월 1회 이상', insp: '분기 1회 정기점검', ref: '한강유역 (경기)' },
        { rc: '41000', ft: '침전지', cmin: 1, cmax: 500, mat: '콘크리트 구조, 2시간 체류 가능 용량', maint: '월 1회 청소', insp: '분기 1회 수질검사', ref: '한강 (1.0 mg/L)' },
        { rc: '26000', ft: '유분분리기', cmin: 0.5, cmax: 100, mat: '코알레서 타입 권장 (효율 80% 이상)', maint: '월 1회 이상', insp: '월 1회 정기점검, 오염도 모니터링', ref: '낙동강유역 (부산)' },
        { rc: '26000', ft: '침전지', cmin: 1, cmax: 500, mat: '콘크리트 구조, 2시간 체류 가능 용량', maint: '월 1회 청소', insp: '월 1회 정기점검, 장마기간 사전점검', ref: '낙동강 (1.5 mg/L)' },
        { rc: '26000', ft: '비상저류조', cmin: 2, cmax: 200, mat: '콘크리트, 일일 폐수배출량의 3배 이상', maint: '월 1회 점검', insp: '분기 1회 수질검사', ref: '낙동강 상수원 보호' },
        { rc: '30000', ft: '유분분리기', cmin: 0.5, cmax: 100, mat: '표준형 또는 코알레서 (효율 80% 이상)', maint: '분기 1회 이상', insp: '분기 1회 정기점검', ref: '금강유역 (대전)' },
        { rc: '30000', ft: '침전지', cmin: 1, cmax: 500, mat: '콘크리트 구조, 2시간 체류 가능 용량', maint: '월 1회 청소', insp: '분기 1회 수질검사', ref: '금강 (2.0 mg/L)' }
      ];

      const insertWaste = regulationsDb.prepare(`
        INSERT INTO regional_wastewater_standards
        (region_code, facility_type, capacity_min, capacity_max, material_requirement, maintenance_frequency, inspection_requirement, law_reference)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `);

      wasteWaterData.forEach(row => {
        insertWaste.run(row.rc, row.ft, row.cmin, row.cmax, row.mat, row.maint, row.insp, row.ref);
      });

      console.log('✅ 유역별 폐수처리 기준 12개 항목 로드 완료');
    }
  } catch (err) {
    console.warn('⚠️ 유역별 폐수처리 기준 로드 중 주의:', err.message.slice(0, 100));
  }
} catch (err) {
  console.warn('⚠️ 규정 DB 초기화 실패:', err.message);
}

module.exports = db;
module.exports.generateOrderNumber = generateOrderNumber;
module.exports.regulationsDb = regulationsDb;
