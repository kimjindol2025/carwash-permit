-- ===== 세차장 허가 의사결정 엔진 =====
-- 3단계 필터링: 토지 → 건축물 → 용도변경/신축

-- 1. 기존 건축물 용도별 세차장 허가 판정
CREATE TABLE IF NOT EXISTS existing_building_judgement (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  building_purpose TEXT NOT NULL UNIQUE,  -- 건축물 현재용도
  category TEXT NOT NULL,  -- 'freepass' / 'inspection' / 'not_applicable'

  -- 프리패스: 별도 검수 없음
  freepass_reason TEXT,  -- "주차장", "1급공업사", "2급공업사", "세차장"

  -- 검수 필요: 추가 조건 확인 필요
  inspection_items TEXT,  -- JSON: ["폐수처리", "주차장", ...]

  -- 비적용: 이 용도로는 불가
  not_applicable_reason TEXT,

  notes TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

-- 2. 나대지 신축 세차장 규칙
CREATE TABLE IF NOT EXISTS newland_carwash_rules (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  initial_purpose TEXT NOT NULL,  -- "창고", "상가" 등
  is_allowed INTEGER NOT NULL,  -- 1=허용, 0=불허
  final_purpose TEXT NOT NULL,  -- 최종 용도는 반드시 "자동차관련시설 세차장"

  required_design_items TEXT,  -- JSON: 필수 설계 항목
  required_permits TEXT,  -- JSON: 필수 인허가

  notes TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime')),
  UNIQUE(initial_purpose)
);

-- 3. 기존 건축물 용도변경 규칙
CREATE TABLE IF NOT EXISTS building_purpose_change_rules (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  from_purpose TEXT NOT NULL,  -- 변경 전 용도 (근생, 주택 등)
  to_purpose TEXT NOT NULL DEFAULT '자동차관련시설',  -- 변경 후 (항상 자동차관련시설)
  is_changeable INTEGER NOT NULL,  -- 1=가능, 0=불가능

  change_period_min INTEGER,  -- 최소 기간 (일)
  change_period_max INTEGER,  -- 최대 기간 (일)

  requires_council_review INTEGER DEFAULT 0,  -- 의회 심의 필요 여부 (1=필요)
  council_review_probability TEXT DEFAULT '낮음',  -- '낮음', '중간', '높음'

  design_requirements TEXT,  -- JSON: 설계 요구사항
  approval_requirements TEXT,  -- JSON: 인허가 요구사항

  notes TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime')),
  UNIQUE(from_purpose, to_purpose)
);

-- 4. 시군구별 용도변경 추가 규정
CREATE TABLE IF NOT EXISTS regional_purpose_change_rules (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  region_code TEXT NOT NULL,  -- 시군구 코드
  region_name TEXT NOT NULL,

  from_purpose TEXT NOT NULL,  -- 변경 전 용도

  -- 지역별 특이사항
  council_review_required INTEGER DEFAULT 0,  -- 의회 심의 필수 여부
  additional_inspection TEXT,  -- 추가 검수 항목
  estimated_period_days INTEGER,  -- 예상 기간 (일)

  special_conditions TEXT,  -- JSON: 특이 조건
  approval_path TEXT,  -- 승인 경로

  created_at TEXT DEFAULT (datetime('now','localtime')),
  UNIQUE(region_code, from_purpose)
);

-- 5. 건축물별 검수 항목 (프리패스 제외)
CREATE TABLE IF NOT EXISTS inspection_checklist (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category TEXT NOT NULL,  -- 'existing_building' / 'newland'

  item_name TEXT NOT NULL,  -- 검수 항목명
  requirement TEXT,  -- 필수 기준
  inspection_method TEXT,  -- 검사 방법
  responsible_dept TEXT,  -- 담당부서

  created_at TEXT DEFAULT (datetime('now','localtime'))
);

-- 6. 세차장 최종 판정 결과 저장
CREATE TABLE IF NOT EXISTS carwash_assessment_results (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  assessment_date TEXT,  -- 평가 날짜

  -- 입력 정보
  address TEXT,
  zone_code TEXT,  -- 토지용도지역
  building_purpose TEXT,  -- 건축물용도
  building_type TEXT,  -- 'existing' / 'newland'

  -- 1차 필터: 토지용도
  land_permit_status TEXT,  -- 'ok' / 'conditional' / 'denied'
  land_reason TEXT,

  -- 2차 필터: 건축물 판정
  building_permit_status TEXT,  -- 'freepass' / 'inspection' / 'denied'
  building_reason TEXT,

  -- 3차: 추가 조건
  requires_purpose_change INTEGER DEFAULT 0,  -- 용도변경 필요
  estimated_change_period TEXT,  -- 예상 변경 기간
  requires_council_review INTEGER DEFAULT 0,  -- 의회 심의 필요

  -- 최종 판정
  final_decision TEXT,  -- 'go' / 'caution' / 'stop' / 'consult'
  final_reason TEXT,

  next_step TEXT,  -- 다음 단계
  designer_consultation_required INTEGER DEFAULT 0,  -- 설계사 상담 필요

  created_at TEXT DEFAULT (datetime('now','localtime'))
);

-- 7. 인덱스
CREATE INDEX IF NOT EXISTS idx_existing_building_purpose ON existing_building_judgement(building_purpose);
CREATE INDEX IF NOT EXISTS idx_newland_purpose ON newland_carwash_rules(initial_purpose);
CREATE INDEX IF NOT EXISTS idx_purpose_change ON building_purpose_change_rules(from_purpose);
CREATE INDEX IF NOT EXISTS idx_regional_region ON regional_purpose_change_rules(region_code);
CREATE INDEX IF NOT EXISTS idx_assessment_decision ON carwash_assessment_results(final_decision);
