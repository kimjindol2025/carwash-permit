-- ===== 세차장 허가 법률 & 환경 기준 데이터베이스 =====

-- 1. 용도지역별 허가 기준 (건축법)
CREATE TABLE IF NOT EXISTS land_use_zones (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  zone_name TEXT NOT NULL UNIQUE,
  zone_code TEXT,
  car_wash_permit TEXT NOT NULL,  -- 'permitted', 'conditional', 'denied'
  reason TEXT,
  notes TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

-- 2. 수질오염 배출 허용 기준 (물환경보전법 시행규칙 별표13)
CREATE TABLE IF NOT EXISTS water_quality_standards (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  pollutant_name TEXT NOT NULL,  -- BOD, COD, SS, 총질소, 총인 등
  pollutant_code TEXT,
  region_type TEXT NOT NULL,  -- 청정지역, 가지역, 나지역, 특례지역
  daily_discharge_threshold INTEGER,  -- 일 폐수배출량 기준 (m³)
  max_concentration INTEGER,  -- 최대 농도 (mg/L)
  unit TEXT DEFAULT 'mg/L',
  law_reference TEXT DEFAULT '물환경보전법 시행규칙 별표13',
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

-- 3. 폐수배출시설 설치 기준
CREATE TABLE IF NOT EXISTS wastewater_facility_standards (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category TEXT NOT NULL,  -- '세차장', '자동차정비', '주유소' 등
  facility_type TEXT,  -- '필수', '권장', '선택'
  specification TEXT NOT NULL,  -- 시설 사양
  capacity_range TEXT,  -- '100~500m³', '500m³ 이상' 등
  installation_requirement TEXT NOT NULL,  -- 설치 의무 여부
  maintenance_frequency TEXT,  -- 유지보수 빈도 '월 1회', '분기 1회' 등
  notes TEXT,
  law_reference TEXT DEFAULT '물환경보전법',
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

-- 4. 필수 제출 서류 (허가 단계별)
CREATE TABLE IF NOT EXISTS required_documents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  approval_stage TEXT NOT NULL,  -- '건축허가', '폐수신고', '사업자등록', '최종확인'
  document_name TEXT NOT NULL,
  required_copy INTEGER DEFAULT 1,  -- 사본 부수
  issuing_authority TEXT,  -- 발급 기관
  validity_period TEXT,  -- 유효기간
  notes TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

-- 5. 관공서 확인 사항 (담당 부서별)
CREATE TABLE IF NOT EXISTS regulatory_agencies (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  agency_name TEXT NOT NULL,  -- '시군구청 건축과', '환경과' 등
  agency_code TEXT,
  responsibility TEXT NOT NULL,  -- 담당 업무
  inspection_items TEXT,  -- JSON 형식의 확인 항목
  restriction_authority TEXT NOT NULL,  -- 행위 제한 권한 여부
  contact_note TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

-- 6. 건축물대장 용도 분류 (자동차관련시설)
CREATE TABLE IF NOT EXISTS building_purposes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  purpose_code TEXT NOT NULL UNIQUE,
  purpose_name TEXT NOT NULL,  -- '세차장', '주유소', '자동차정비' 등
  category TEXT,  -- '주요시설', '부속시설'
  regulation_reference TEXT,  -- '건축법 시행령 별표1'
  notes TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

-- 7. 지자체별 조례 기준 (표본)
CREATE TABLE IF NOT EXISTS local_ordinances (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  region_name TEXT NOT NULL,  -- '서울시', '부산시' 등
  ordinance_title TEXT,
  building_setback INTEGER,  -- 건물 후퇴거리 (m)
  green_area_ratio REAL,  -- 녹지비율 (%)
  parking_requirement INTEGER,  -- 주차 필수 대수
  noise_standard INTEGER,  -- 소음 기준 (dB)
  special_conditions TEXT,  -- JSON 형식의 특수 조건
  ordinance_date TEXT,  -- 조례 시행일
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

-- 8. 세차장 운영 기준
CREATE TABLE IF NOT EXISTS operation_standards (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  standard_item TEXT NOT NULL,
  requirement TEXT NOT NULL,
  frequency TEXT,  -- 점검/검사 빈도
  responsible_agency TEXT,
  penalty_type TEXT,  -- 위반시 처벌 유형
  law_reference TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

-- 9. 허가 판정 로직 (규칙 엔진)
CREATE TABLE IF NOT EXISTS permit_decision_rules (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  rule_order INTEGER NOT NULL,  -- 판정 순서
  condition TEXT NOT NULL,  -- 조건
  check_item TEXT NOT NULL,  -- 확인 항목
  pass_result TEXT,  -- 통과시 결과
  fail_result TEXT,  -- 불통과시 결과
  is_critical INTEGER DEFAULT 0,  -- 1개 실패 시 전체 불가 여부
  notes TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

-- 인덱스 생성
CREATE INDEX IF NOT EXISTS idx_land_use_permit ON land_use_zones(car_wash_permit);
CREATE INDEX IF NOT EXISTS idx_water_quality_region ON water_quality_standards(region_type);
CREATE INDEX IF NOT EXISTS idx_required_docs_stage ON required_documents(approval_stage);
CREATE INDEX IF NOT EXISTS idx_agencies_name ON regulatory_agencies(agency_name);
CREATE INDEX IF NOT EXISTS idx_permit_rules_order ON permit_decision_rules(rule_order);
