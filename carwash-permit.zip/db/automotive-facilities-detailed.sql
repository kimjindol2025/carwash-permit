-- ===== 자동차관련시설 3가지 상세 법률 정보 =====

-- 1. 시설별 법적 정의 및 분류
CREATE TABLE IF NOT EXISTS automotive_facility_types (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  facility_name TEXT NOT NULL UNIQUE,
  legal_basis TEXT,
  building_law_code TEXT,
  definition TEXT,
  subcategories TEXT,  -- JSON 배열
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

-- 2. 시설별 용도지역 허가 매트릭스
CREATE TABLE IF NOT EXISTS facility_zoning_matrix (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  facility_type TEXT NOT NULL,  -- '주차장', '세차장', '정비공장'
  zone_name TEXT NOT NULL,
  zone_code TEXT,
  permission_status TEXT NOT NULL,  -- 'permitted', 'conditional', 'denied'
  law_reference TEXT,
  notes TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime')),
  UNIQUE(facility_type, zone_name)
);

-- 3. 시설별 건축법 기준
CREATE TABLE IF NOT EXISTS automotive_facility_standards (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  facility_type TEXT NOT NULL,
  standard_item TEXT NOT NULL,
  minimum_value INTEGER,
  maximum_value INTEGER,
  unit TEXT,
  requirement_type TEXT,  -- '필수', '권장', '조건부'
  law_reference TEXT,
  notes TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

-- 4. 시설별 환경기준
CREATE TABLE IF NOT EXISTS automotive_facility_environment (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  facility_type TEXT NOT NULL,
  environmental_item TEXT NOT NULL,
  standard_value REAL,
  unit TEXT,
  measurement_method TEXT,
  inspection_frequency TEXT,
  law_reference TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

-- 5. 시설별 필수 등록/인허가
CREATE TABLE IF NOT EXISTS facility_registrations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  facility_type TEXT NOT NULL,
  registration_name TEXT NOT NULL,
  issuing_authority TEXT NOT NULL,
  application_requirements TEXT,  -- JSON 배열
  processing_period TEXT,  -- 예: '5~10일'
  fee_range TEXT,
  annual_inspection INTEGER DEFAULT 0,  -- 연차 검사 필수 여부
  validity_period TEXT,
  law_reference TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

-- 6. 시설별 폐수처리 의무
CREATE TABLE IF NOT EXISTS facility_wastewater_obligations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  facility_type TEXT NOT NULL,
  triggering_condition TEXT,  -- 예: '작업장 200m² 이상', '매일 폐수 배출'
  wastewater_notification_required INTEGER DEFAULT 0,
  treatment_facility_required INTEGER DEFAULT 0,
  water_quality_inspection_required INTEGER DEFAULT 0,
  inspection_frequency TEXT,
  estimated_daily_discharge REAL,  -- 추정 일 배출량 m³
  unit TEXT DEFAULT 'm³/day',
  law_reference TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

-- 인덱스
CREATE INDEX IF NOT EXISTS idx_matrix_facility ON facility_zoning_matrix(facility_type);
CREATE INDEX IF NOT EXISTS idx_matrix_zone ON facility_zoning_matrix(zone_name);
CREATE INDEX IF NOT EXISTS idx_standards_facility ON automotive_facility_standards(facility_type);
CREATE INDEX IF NOT EXISTS idx_registrations_facility ON facility_registrations(facility_type);
