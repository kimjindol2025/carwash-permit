-- ===== 지자체별 세차장 환경 조례 및 기준 =====

-- 기존 테이블 삭제 (스키마 변경 시)
DROP TABLE IF EXISTS regional_authorities;
DROP TABLE IF EXISTS regional_wastewater_standards;
DROP TABLE IF EXISTS local_ordinances;

-- 1. 지자체별 조례 정보
CREATE TABLE IF NOT EXISTS local_ordinances (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  region_code TEXT NOT NULL UNIQUE,  -- '11000' (서울), '26000' (부산) 등
  sigungu_name TEXT NOT NULL,  -- 시군구명
  sido_name TEXT NOT NULL,  -- 시도명

  -- 세차장 기본 허가 조건
  carwash_zone_restriction TEXT,  -- 허가 용도지역 (JSON: ["상업", "공업"] 등)
  carwash_min_area REAL,  -- 최소 대지면적 (㎡)
  carwash_min_building_area REAL,  -- 최소 건축면적 (㎡)

  -- 폐수처리 기준 (물환경보전법과 다른 추가 기준이 있을 경우)
  water_quality_target TEXT,  -- '청정', '가', '나' 지역 분류
  bod_standard REAL,  -- BOD 배출기준 (mg/L)
  cod_standard REAL,  -- COD 배출기준 (mg/L)
  ss_standard REAL,  -- SS 배출기준 (mg/L)
  oil_standard REAL,  -- 유분 배출기준 (mg/L)
  nitrogen_standard REAL,  -- 총질소 (mg/L)
  phosphorus_standard REAL,  -- 총인 (mg/L)

  -- 환경 기준
  noise_standard REAL,  -- 소음기준 (dB)
  odor_standard REAL,  -- 악취기준 (희석배수)
  inspection_frequency TEXT,  -- 정기검사 주기 ('월1회', '분기1회' 등)

  -- 기타 조건
  parking_requirement TEXT,  -- 주차 기준
  business_registration_requirement TEXT,  -- 사업자등록 요건
  insurance_requirement TEXT,  -- 보험 요건
  additional_notes TEXT,  -- 추가 조건/비고

  created_at TEXT DEFAULT (datetime('now','localtime')),
  updated_at TEXT DEFAULT (datetime('now','localtime'))
);

-- 2. 지역별 상세 폐수처리시설 기준
CREATE TABLE IF NOT EXISTS regional_wastewater_standards (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  region_code TEXT NOT NULL,  -- local_ordinances.region_code와 연결
  facility_type TEXT NOT NULL,  -- '침전지', '유분분리기', '활성탄 필터' 등
  capacity_min REAL,  -- 최소 용량 (m³/day)
  capacity_max REAL,  -- 최대 용량 (m³/day)
  material_requirement TEXT,  -- 재질 요구사항
  maintenance_frequency TEXT,  -- 유지보수 주기
  inspection_requirement TEXT,  -- 검사 요건
  law_reference TEXT,  -- 법적 근거

  UNIQUE(region_code, facility_type)
);

-- 3. 지자체별 인허가 담당부서
CREATE TABLE IF NOT EXISTS regional_authorities (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  region_code TEXT NOT NULL UNIQUE,
  building_permit_dept TEXT,  -- 건축허가 담당부서
  environment_dept TEXT,  -- 환경 담당부서
  business_registration_office TEXT,  -- 사업자등록 세무서
  wastewater_authority TEXT,  -- 폐수배출시설 담당기관
  water_authority TEXT,  -- 상수도사업소
  contact_phone TEXT,  -- 통합 연락처 또는 환경과

  UNIQUE(region_code)
);

-- 4. 인덱스
CREATE INDEX IF NOT EXISTS idx_ordinances_sido ON local_ordinances(sido_name);
CREATE INDEX IF NOT EXISTS idx_ordinances_zone ON local_ordinances(carwash_zone_restriction);
CREATE INDEX IF NOT EXISTS idx_wastewater_region ON regional_wastewater_standards(region_code);
CREATE INDEX IF NOT EXISTS idx_authorities_region ON regional_authorities(region_code);
