-- ===== 지자체별 세차장 환경 조례 시드 데이터 =====

-- 기준: 물환경보전법 별표13 (전국 공통)
-- 청정지역: BOD 5, COD 10, SS 10
-- 가지역: BOD 8, COD 15, SS 20
-- 나지역: BOD 10, COD 20, SS 40

-- ===== 서울특별시 =====
INSERT INTO local_ordinances
(region_code, sigungu_name, sido_name, carwash_zone_restriction, carwash_min_area,
 water_quality_target, bod_standard, cod_standard, ss_standard, oil_standard,
 noise_standard, odor_standard, inspection_frequency, additional_notes) VALUES
('11000', '서울특별시', '서울', '["상업지역", "공업지역", "준주거지역"]', 50,
 '가', 8, 15, 20, 5,
 65, 2, '월1회', '서울시 환경영향평가 협의 필요');

INSERT INTO regional_authorities (region_code, building_permit_dept, environment_dept, wastewater_authority, contact_phone)
VALUES ('11000', '건축과', '환경과', '한강유역환경청', '031-790-2800');

-- ===== 부산광역시 =====
INSERT INTO local_ordinances
(region_code, sigungu_name, sido_name, carwash_zone_restriction, carwash_min_area,
 water_quality_target, bod_standard, cod_standard, ss_standard, oil_standard,
 noise_standard, odor_standard, inspection_frequency, additional_notes) VALUES
('26000', '부산광역시', '부산', '["상업지역", "공업지역", "준주거지역"]', 50,
 '가', 8, 15, 20, 5,
 65, 2, '월1회', '낙동강유역 관할, 특별 환경영향 검토 필요');

INSERT INTO regional_authorities (region_code, building_permit_dept, environment_dept, wastewater_authority, contact_phone)
VALUES ('26000', '건축과', '환경과', '낙동강유역환경청', '055-211-1600');

-- ===== 대구광역시 =====
INSERT INTO local_ordinances
(region_code, sigungu_name, sido_name, carwash_zone_restriction, carwash_min_area,
 water_quality_target, bod_standard, cod_standard, ss_standard, oil_standard,
 noise_standard, odor_standard, inspection_frequency, additional_notes) VALUES
('27000', '대구광역시', '대구', '["상업지역", "공업지역", "준주거지역"]', 50,
 '나', 10, 20, 40, 5,
 65, 2, '월1회', '낙동강 상류 지역, 수질 관리 강화');

INSERT INTO regional_authorities (region_code, building_permit_dept, environment_dept, wastewater_authority, contact_phone)
VALUES ('27000', '건축과', '환경과', '대구지방환경청', '053-230-2800');

-- ===== 인천광역시 =====
INSERT INTO local_ordinances
(region_code, sigungu_name, sido_name, carwash_zone_restriction, carwash_min_area,
 water_quality_target, bod_standard, cod_standard, ss_standard, oil_standard,
 noise_standard, odor_standard, inspection_frequency, additional_notes) VALUES
('28000', '인천광역시', '인천', '["상업지역", "공업지역", "준주거지역"]', 50,
 '가', 8, 15, 20, 5,
 65, 2, '월1회', '한강유역 관할, 내부 수로 관리 필요');

INSERT INTO regional_authorities (region_code, building_permit_dept, environment_dept, wastewater_authority, contact_phone)
VALUES ('28000', '건축과', '환경과', '한강유역환경청', '031-790-2800');

-- ===== 광주광역시 =====
INSERT INTO local_ordinances
(region_code, sigungu_name, sido_name, carwash_zone_restriction, carwash_min_area,
 water_quality_target, bod_standard, cod_standard, ss_standard, oil_standard,
 noise_standard, odor_standard, inspection_frequency, additional_notes) VALUES
('29000', '광주광역시', '광주', '["상업지역", "공업지역", "준주거지역"]', 50,
 '가', 8, 15, 20, 5,
 65, 2, '월1회', '영산강유역 관할');

INSERT INTO regional_authorities (region_code, building_permit_dept, environment_dept, wastewater_authority, contact_phone)
VALUES ('29000', '건축과', '환경과', '영산강유역환경청', '062-410-5200');

-- ===== 대전광역시 =====
INSERT INTO local_ordinances
(region_code, sigungu_name, sido_name, carwash_zone_restriction, carwash_min_area,
 water_quality_target, bod_standard, cod_standard, ss_standard, oil_standard,
 noise_standard, odor_standard, inspection_frequency, additional_notes) VALUES
('30000', '대전광역시', '대전', '["상업지역", "공업지역", "준주거지역"]', 50,
 '가', 8, 15, 20, 5,
 65, 2, '월1회', '금강유역 관할');

INSERT INTO regional_authorities (region_code, building_permit_dept, environment_dept, wastewater_authority, contact_phone)
VALUES ('30000', '건축과', '환경과', '금강유역환경청', '042-865-0700');

-- ===== 울산광역시 =====
INSERT INTO local_ordinances
(region_code, sigungu_name, sido_name, carwash_zone_restriction, carwash_min_area,
 water_quality_target, bod_standard, cod_standard, ss_standard, oil_standard,
 noise_standard, odor_standard, inspection_frequency, additional_notes) VALUES
('31000', '울산광역시', '울산', '["상업지역", "공업지역", "준주거지역"]', 50,
 '나', 10, 20, 40, 5,
 65, 2, '월1회', '화학산업단지 인근 엄격한 수질 관리');

INSERT INTO regional_authorities (region_code, building_permit_dept, environment_dept, wastewater_authority, contact_phone)
VALUES ('31000', '건축과', '환경과', '낙동강유역환경청', '055-211-1600');

-- ===== 세종특별자치시 =====
INSERT INTO local_ordinances
(region_code, sigungu_name, sido_name, carwash_zone_restriction, carwash_min_area,
 water_quality_target, bod_standard, cod_standard, ss_standard, oil_standard,
 noise_standard, odor_standard, inspection_frequency, additional_notes) VALUES
('36000', '세종특별자치시', '세종', '["상업지역", "공업지역", "준주거지역"]', 50,
 '청정', 5, 10, 10, 3,
 60, 2, '월1회', '청정지역 지정, 환경 기준 엄격');

INSERT INTO regional_authorities (region_code, building_permit_dept, environment_dept, wastewater_authority, contact_phone)
VALUES ('36000', '건축과', '환경과', '금강유역환경청', '042-865-0700');

-- ===== 경기도 =====
INSERT INTO local_ordinances
(region_code, sigungu_name, sido_name, carwash_zone_restriction, carwash_min_area,
 water_quality_target, bod_standard, cod_standard, ss_standard, oil_standard,
 noise_standard, odor_standard, inspection_frequency, additional_notes) VALUES
('41000', '경기도', '경기', '["상업지역", "공업지역", "준주거지역"]', 50,
 '가', 8, 15, 20, 5,
 65, 2, '월1회', '한강/낙동강 유역별 차등 관리');

INSERT INTO regional_authorities (region_code, building_permit_dept, environment_dept, wastewater_authority, contact_phone)
VALUES ('41000', '건축과', '환경과', '한강유역환경청', '031-790-2800');

-- ===== 강원도 =====
INSERT INTO local_ordinances
(region_code, sigungu_name, sido_name, carwash_zone_restriction, carwash_min_area,
 water_quality_target, bod_standard, cod_standard, ss_standard, oil_standard,
 noise_standard, odor_standard, inspection_frequency, additional_notes) VALUES
('42000', '강원도', '강원', '["상업지역", "공업지역", "준주거지역"]', 50,
 '청정', 5, 10, 10, 3,
 60, 2, '월1회', '산악지역, 청정 기준 적용');

INSERT INTO regional_authorities (region_code, building_permit_dept, environment_dept, wastewater_authority, contact_phone)
VALUES ('42000', '건축과', '환경과', '원주지방환경청', '033-769-0000');

-- ===== 충청북도 =====
INSERT INTO local_ordinances
(region_code, sigungu_name, sido_name, carwash_zone_restriction, carwash_min_area,
 water_quality_target, bod_standard, cod_standard, ss_standard, oil_standard,
 noise_standard, odor_standard, inspection_frequency, additional_notes) VALUES
('43000', '충청북도', '충북', '["상업지역", "공업지역", "준주거지역"]', 50,
 '가', 8, 15, 20, 5,
 65, 2, '월1회', '금강 상류, 수질 보전');

INSERT INTO regional_authorities (region_code, building_permit_dept, environment_dept, wastewater_authority, contact_phone)
VALUES ('43000', '건축과', '환경과', '금강유역환경청', '042-865-0700');

-- ===== 충청남도 =====
INSERT INTO local_ordinances
(region_code, sigungu_name, sido_name, carwash_zone_restriction, carwash_min_area,
 water_quality_target, bod_standard, cod_standard, ss_standard, oil_standard,
 noise_standard, odor_standard, inspection_frequency, additional_notes) VALUES
('44000', '충청남도', '충남', '["상업지역", "공업지역", "준주거지역"]', 50,
 '나', 10, 20, 40, 5,
 65, 2, '월1회', '금강/영산강 유역 분할, 산업폐수 엄격');

INSERT INTO regional_authorities (region_code, building_permit_dept, environment_dept, wastewater_authority, contact_phone)
VALUES ('44000', '건축과', '환경과', '금강유역환경청', '042-865-0700');

-- ===== 전라북도 =====
INSERT INTO local_ordinances
(region_code, sigungu_name, sido_name, carwash_zone_restriction, carwash_min_area,
 water_quality_target, bod_standard, cod_standard, ss_standard, oil_standard,
 noise_standard, odor_standard, inspection_frequency, additional_notes) VALUES
('45000', '전라북도', '전북', '["상업지역", "공업지역", "준주거지역"]', 50,
 '가', 8, 15, 20, 5,
 65, 2, '월1회', '영산강 유역 관할');

INSERT INTO regional_authorities (region_code, building_permit_dept, environment_dept, wastewater_authority, contact_phone)
VALUES ('45000', '건축과', '환경과', '영산강유역환경청', '062-410-5200');

-- ===== 전라남도 =====
INSERT INTO local_ordinances
(region_code, sigungu_name, sido_name, carwash_zone_restriction, carwash_min_area,
 water_quality_target, bod_standard, cod_standard, ss_standard, oil_standard,
 noise_standard, odor_standard, inspection_frequency, additional_notes) VALUES
('46000', '전라남도', '전남', '["상업지역", "공업지역", "준주거지역"]', 50,
 '나', 10, 20, 40, 5,
 65, 2, '월1회', '영산강 하류, 염분 관리');

INSERT INTO regional_authorities (region_code, building_permit_dept, environment_dept, wastewater_authority, contact_phone)
VALUES ('46000', '건축과', '환경과', '영산강유역환경청', '062-410-5200');

-- ===== 경상북도 =====
INSERT INTO local_ordinances
(region_code, sigungu_name, sido_name, carwash_zone_restriction, carwash_min_area,
 water_quality_target, bod_standard, cod_standard, ss_standard, oil_standard,
 noise_standard, odor_standard, inspection_frequency, additional_notes) VALUES
('47000', '경상북도', '경북', '["상업지역", "공업지역", "준주거지역"]', 50,
 '나', 10, 20, 40, 5,
 65, 2, '월1회', '낙동강 상류/중류 구간');

INSERT INTO regional_authorities (region_code, building_permit_dept, environment_dept, wastewater_authority, contact_phone)
VALUES ('47000', '건축과', '환경과', '낙동강유역환경청', '055-211-1600');

-- ===== 경상남도 =====
INSERT INTO local_ordinances
(region_code, sigungu_name, sido_name, carwash_zone_restriction, carwash_min_area,
 water_quality_target, bod_standard, cod_standard, ss_standard, oil_standard,
 noise_standard, odor_standard, inspection_frequency, additional_notes) VALUES
('48000', '경상남도', '경남', '["상업지역", "공업지역", "준주거지역"]', 50,
 '나', 10, 20, 40, 5,
 65, 2, '월1회', '낙동강 하류, 해수 유입 영향');

INSERT INTO regional_authorities (region_code, building_permit_dept, environment_dept, wastewater_authority, contact_phone)
VALUES ('48000', '건축과', '환경과', '낙동강유역환경청', '055-211-1600');

-- ===== 제주특별자치도 =====
INSERT INTO local_ordinances
(region_code, sigungu_name, sido_name, carwash_zone_restriction, carwash_min_area,
 water_quality_target, bod_standard, cod_standard, ss_standard, oil_standard,
 noise_standard, odor_standard, inspection_frequency, additional_notes) VALUES
('50000', '제주특별자치도', '제주', '["상업지역", "공업지역", "준주거지역"]', 50,
 '청정', 5, 10, 10, 3,
 60, 2, '월1회', '도서지역, 청정 기준 엄격, 지하수 보호');

INSERT INTO regional_authorities (region_code, building_permit_dept, environment_dept, wastewater_authority, contact_phone)
VALUES ('50000', '건축과', '환경과', '환경부 제주지역환경청', '064-800-8000');

-- ===== 폐수처리시설 기준 (전국 공통) =====
INSERT INTO regional_wastewater_standards (region_code, facility_type, capacity_min, capacity_max, material_requirement, maintenance_frequency, inspection_requirement)
VALUES
('00000', '침전지', 10, 100, 'PE/콘크리트', '월1회', '월1회 청소'),
('00000', '유분분리기', 10, 50, '강철/PE', '월1회', '월1회 점검'),
('00000', '활성탄필터', 5, 30, '스테인리스/플라스틱', '3개월', '3개월 교체'),
('00000', '응집침전지', 20, 100, 'PE/콘크리트', '월1회', '월1회 청소');
