# 🔄 워크플로우 API 가이드 (순차적 허가 체크)

## 📋 개요

사용자가 **지번 검색 → 토지이용 확인 → 건축물 확인 → 허가 체크** 의 순서대로 진행하며, 각 단계의 결과가 다음 단계에 활용되는 통합 워크플로우입니다.

---

## 🚀 워크플로우 흐름

```
┌─────────────────┐
│ Step 0: 시작     │  POST /api/workflow/start
└────────┬────────┘
         ↓
┌─────────────────┐
│ Step 1: 지번검색 │  POST /api/workflow/:sessionId/step/1
│ (주소 입력)      │  → session에 주소 저장
└────────┬────────┘
         ↓
┌─────────────────┐
│ Step 2: 토지이용 │  POST /api/workflow/:sessionId/step/2
│ (VWorld API)    │  → 용도지역 자동 조회 + 미리보기 판정
└────────┬────────┘
         ↓
┌─────────────────┐
│ Step 3: 건축물   │  POST /api/workflow/:sessionId/step/3
│ (용도 확인)      │  → 건축물 용도 저장
└────────┬────────┘
         ↓
┌─────────────────┐
│ Step 4: 허가체크 │  POST /api/workflow/:sessionId/step/4
│ (최종 판정)      │  → 최종 결과 + 리포트 생성
└────────┬────────┘
         ↓
┌─────────────────┐
│ 리포트 조회       │  GET /api/workflow/:sessionId/report
│ (다운로드/인쇄)  │
└─────────────────┘
```

---

## 📡 API 엔드포인트

### 1️⃣ 워크플로우 시작

**요청:**
```bash
POST /api/workflow/start
Content-Type: application/json
```

**응답:**
```json
{
  "success": true,
  "sessionId": "dd79adf7783650f0d155b2cf19ee10b5",
  "message": "워크플로우 시작. 지번 검색으로 진행하세요."
}
```

**사용 예:**
```javascript
const res = await fetch('/api/workflow/start', { method: 'POST' });
const { sessionId } = await res.json();
// sessionId를 모든 단계에서 사용
```

---

### 2️⃣ Step 1: 지번 검색 및 저장

**목적:** 사용자가 선택한 주소를 세션에 저장

**요청:**
```bash
POST /api/workflow/:sessionId/step/1
Content-Type: application/json

{
  "roadAddr": "서울시 강남구 테헤란로 123",
  "sigunguCd": "11680",          # 5자리 시군구 코드
  "bjdongCd": "10100",            # 법정동 코드
  "pnu": "1168010100101230004"    # 필지번호 (선택)
}
```

**응답:**
```json
{
  "success": true,
  "message": "1단계 완료: 주소가 저장되었습니다",
  "nextStep": 2,
  "instruction": "토지이용 확인으로 진행하세요"
}
```

**저장되는 데이터:**
```
step1_address    = "서울시 강남구 테헤란로 123"
step1_sigungu_cd = "11680"
step1_bjdong_cd  = "10100"
step1_pnu        = "1168010100101230004"
step1_completed  = 1
```

---

### 3️⃣ Step 2: 토지이용 확인

**목적:** VWorld API를 통해 용도지역 자동 조회 + 미리보기 허가 판정

**요청:**
```bash
POST /api/workflow/:sessionId/step/2
Content-Type: application/json

{
  "pnu": "1168010100101230004"  # 선택 (없으면 Step1에서 저장된 값 사용)
}
```

**응답:**
```json
{
  "success": true,
  "message": "2단계 완료: 용도지역이 확인되었습니다",
  "data": {
    "zoneType": "제2종일반주거지역",
    "zoneCode": "R2",
    "jimok": "대",
    "area": "1200",
    "source": "VWorld API"  # 또는 "Mock"
  },
  "permitPreview": {
    "result": "조건부가능",
    "resultColor": "result-cond"
  },
  "nextStep": 3,
  "instruction": "건축물 확인으로 진행하세요"
}
```

**저장되는 데이터:**
```
step2_zone_type  = "제2종일반주거지역"
step2_zone_code  = "R2"
step2_jimok      = "대"
step2_area       = "1200"
step2_source     = "VWorld API"
step2_completed  = 1
```

**주요 기능:**
- ✅ VWorld API 호출 (API 키 있을 때)
- ✅ Mock 데이터 폴백 (API 키 없을 때)
- ✅ 미리보기 허가 판정 (다음 Step 진행 전 결과 확인)

---

### 4️⃣ Step 3: 건축물 확인

**목적:** 건축물의 현재 용도 저장 (용도변경 필요 여부 판단용)

**요청:**
```bash
POST /api/workflow/:sessionId/step/3
Content-Type: application/json

{
  "buildingName": "테스트빌딩 A동",
  "purposeCd": "C1",              # 용도 코드
  "purposeNm": "제1종근린생활시설",  # 용도명
  "floorArea": "1500"             # 연면적 (m²)
}
```

**응답:**
```json
{
  "success": true,
  "message": "3단계 완료: 건축물 정보가 저장되었습니다",
  "data": {
    "building": "테스트빌딩 A동",
    "purpose": "제1종근린생활시설"
  },
  "nextStep": 4,
  "instruction": "최종 허가 체크로 진행하세요"
}
```

**저장되는 데이터:**
```
step3_building_nm = "테스트빌딩 A동"
step3_purpose_cd  = "C1"
step3_purpose_nm  = "제1종근린생활시설"
step3_floor_ar    = "1500"
step3_completed   = 1
```

---

### 5️⃣ Step 4: 최종 허가 체크 및 리포트 생성

**목적:** 모든 정보를 종합한 최종 판정 및 리포트 생성

**요청:**
```bash
POST /api/workflow/:sessionId/step/4
Content-Type: application/json

{}  # 이전 단계의 데이터를 자동으로 활용
```

**응답:**
```json
{
  "success": true,
  "message": "4단계 완료: 최종 허가 판정이 완료되었습니다",
  "report": {
    "sessionId": "dd79adf7783650f0d155b2cf19ee10b5",
    "address": "서울시 강남구 테헤란로 123",
    "zoneType": "제2종일반주거지역",
    "building": "테스트빌딩 A동",
    "permitResult": "조건부가능",
    "permitReason": "일정 조건을 만족하면 허가 가능합니다",
    "conditions": [
      "✓ 건폐율 60% 이하 확인 필요",
      "✓ 주차장 면적 (최소 6대) 확보",
      "✓ 폐수처리시설 설치 의무",
      "✓ 인접 주거지역 영향 최소화"
    ],
    "checklist": [
      "☐ 토지이용계획확인원",
      "☐ 건축물대장",
      "☐ 사업계획서",
      "☐ 폐수배출시설 설치신고 신청서"
    ],
    "nextSteps": [
      "1. 상세 조례 확인 필요",
      "2. 설계사무소 상담 (용도변경)",
      "3. 전문가 컨설팅 권고"
    ],
    "generatedAt": "2026-03-30T23:52:30.123Z"
  },
  "nextAction": "조건을 만족하는지 설계사무소/전문가와 상담하세요"
}
```

**저장되는 데이터:**
```
step4_result     = "조건부가능"
step4_reason     = "일정 조건을 만족하면 허가 가능합니다"
step4_conditions = [JSON 배열]
step4_checklist  = [JSON 배열]
status           = "completed"
final_report     = [JSON 리포트]
```

---

### 6️⃣ 진행 상황 확인

**목적:** 현재 진행도 및 각 단계의 데이터 확인

**요청:**
```bash
GET /api/workflow/:sessionId/status
```

**응답:**
```json
{
  "success": true,
  "sessionId": "dd79adf7783650f0d155b2cf19ee10b5",
  "currentStep": 2,
  "status": "active",
  "progress": {
    "completed": 2,
    "total": 4,
    "percentage": 50
  },
  "steps": [
    {
      "step": 1,
      "name": "지번 검색",
      "completed": true,
      "data": {
        "address": "서울시 강남구 테헤란로 123"
      }
    },
    {
      "step": 2,
      "name": "토지이용 확인",
      "completed": true,
      "data": {
        "zoneType": "제2종일반주거지역"
      }
    },
    {
      "step": 3,
      "name": "건축물 확인",
      "completed": false,
      "data": null
    },
    {
      "step": 4,
      "name": "허가 체크",
      "completed": false,
      "data": null
    }
  ]
}
```

**활용:**
```javascript
// 프로그래스 바 표시
const { progress } = await getStatus(sessionId);
console.log(`진행도: ${progress.percentage}% (${progress.completed}/${progress.total})`);

// 탭 활성화 제어
const { steps } = await getStatus(sessionId);
steps.forEach(step => {
  if (step.completed) {
    enableTab(step.step);  // 완료한 탭 활성화
  }
});
```

---

### 7️⃣ 최종 리포트 조회

**목적:** 생성된 최종 리포트 다시 조회 (다운로드/인쇄)

**요청:**
```bash
GET /api/workflow/:sessionId/report
```

**응답:**
```json
{
  "success": true,
  "data": {
    "sessionId": "dd79adf7783650f0d155b2cf19ee10b5",
    "address": "서울시 강남구 테헤란로 123",
    "zoneType": "제2종일반주거지역",
    "building": "테스트빌딩 A동",
    "permitResult": "조건부가능",
    "permitReason": "일정 조건을 만족하면 허가 가능합니다",
    "conditions": [...],
    "checklist": [...],
    "nextSteps": [...],
    "generatedAt": "2026-03-30T23:52:30.123Z"
  }
}
```

---

### 8️⃣ 세션 삭제

**목적:** 불필요한 세션 정리

**요청:**
```bash
DELETE /api/workflow/:sessionId
```

**응답:**
```json
{
  "success": true,
  "message": "세션이 삭제되었습니다"
}
```

---

## 💾 데이터베이스 구조

### workflow_sessions 테이블

```sql
CREATE TABLE workflow_sessions (
  id               INTEGER PRIMARY KEY,
  session_id       TEXT UNIQUE,          -- 세션 고유 ID (hex 32자)
  current_step     INTEGER,              -- 현재 단계 (0-4)
  status           TEXT,                 -- 'active' 또는 'completed'

  -- Step 1: 지번 검색
  step1_address    TEXT,
  step1_sigungu_cd TEXT,
  step1_bjdong_cd  TEXT,
  step1_pnu        TEXT,
  step1_completed  INTEGER,

  -- Step 2: 토지이용
  step2_zone_type  TEXT,
  step2_zone_code  TEXT,
  step2_jimok      TEXT,
  step2_area       TEXT,
  step2_source     TEXT,
  step2_completed  INTEGER,

  -- Step 3: 건축물
  step3_building_nm TEXT,
  step3_purpose_cd  TEXT,
  step3_purpose_nm  TEXT,
  step3_floor_ar    TEXT,
  step3_completed   INTEGER,

  -- Step 4: 허가 체크
  step4_result      TEXT,
  step4_reason      TEXT,
  step4_conditions  TEXT,    -- JSON 배열
  step4_checklist   TEXT,    -- JSON 배열
  step4_completed   INTEGER,

  final_report      TEXT,    -- JSON 리포트
  created_at        TEXT,
  updated_at        TEXT,
  expires_at        TEXT     -- 24시간 후 만료
);
```

**특징:**
- ✅ 각 단계의 데이터를 독립적으로 저장
- ✅ 단계별 완료 여부 추적
- ✅ 24시간 자동 만료 (이후 삭제 권고)
- ✅ 최종 리포트는 JSON으로 저장

---

## 🎯 사용 시나리오

### 시나리오 1: 기본 흐름 (4단계 모두 진행)

```javascript
// 1단계: 워크플로우 시작
const startRes = await fetch('/api/workflow/start', { method: 'POST' });
const { sessionId } = await startRes.json();

// 2단계: 주소 입력 (다음 우편번호 팝업)
new daum.Postcode({
  oncomplete: async (data) => {
    await fetch(`/api/workflow/${sessionId}/step/1`, {
      method: 'POST',
      body: JSON.stringify({
        roadAddr: data.roadAddress,
        sigunguCd: data.sigunguCode,
        bjdongCd: data.bcode.slice(5),
        pnu: data.bcode + '...'
      })
    });
    // Step 2로 자동 진행
  }
}).open();

// 3단계: 토지이용 자동 조회
const landRes = await fetch(`/api/workflow/${sessionId}/step/2`, {
  method: 'POST',
  body: JSON.stringify({})
});
const { data, permitPreview } = await landRes.json();
// permitPreview로 미리보기 표시

// 4단계: 건축물 정보 입력
await fetch(`/api/workflow/${sessionId}/step/3`, {
  method: 'POST',
  body: JSON.stringify({
    buildingName: '...',
    purposeNm: '...'
  })
});

// 5단계: 최종 허가 체크
const permitRes = await fetch(`/api/workflow/${sessionId}/step/4`, {
  method: 'POST',
  body: JSON.stringify({})
});
const { report, nextAction } = await permitRes.json();
// 리포트 표시
```

### 시나리오 2: 중간에 중단 후 복귀

```javascript
// 저장된 sessionId로 복귀
const statusRes = await fetch(`/api/workflow/${sessionId}/status`);
const { currentStep, steps } = await statusRes.json();

// 완료한 단계 확인
console.log(`${steps[currentStep - 1].name} 진행중`);

// Step 3부터 계속 진행
await fetch(`/api/workflow/${sessionId}/step/3`, { method: 'POST', ... });
```

### 시나리오 3: 특정 시나리오만 테스트

```javascript
// "상업지역"일 때의 결과만 보고 싶음
const testRes = await fetch(`/api/workflow/${sessionId}/step/2`, {
  method: 'POST',
  body: JSON.stringify({ scenario: '1' })  // Mock 시나리오
});
// result: "가능" 반환
```

---

## ✅ 허가 판정 로직

### 판정 규칙

| 용도지역 | 판정 | 근거 |
|---------|------|------|
| 상업지역, 공업지역, 준주거, 일반주거 | **가능** | 자동차관련시설 허용 |
| 제2종일반주거, 자연녹지 | **조건부가능** | 건폐율/주차장 조건 필수 |
| 보전/생산녹지, 상수원보호, 개발제한구역 | **불가** | 법령으로 금지 |
| 기타 | **확인필요** | 관청 문의 필수 |

### 조건부가능 시 필수 조건

1. **건폐율 60% 이하**
2. **주차장 6대 이상**
3. **폐수처리시설 설치**
4. **인접 주거지역 영향 최소화**

### 필수 서류

- 토지이용계획확인원
- 건축물대장
- 사업계획서
- 폐수배출시설 설치신고 신청서
- 자동차관련시설 건축허가/신고 신청서

---

## 🔐 보안

- **세션 ID**: 32바이트 hex (128bit 암호화 수준)
- **유효 기간**: 24시간 (자동 만료)
- **데이터 저장**: SQLite (로컬 저장소)
- **인증 불필요**: 공개 API (모든 사용자 접근 가능)

---

## 📊 모니터링 & 분석

```sql
-- 최근 워크플로우 조회
SELECT
  session_id,
  current_step,
  status,
  step4_result,
  created_at
FROM workflow_sessions
WHERE created_at > datetime('now', '-7 days')
ORDER BY created_at DESC;

-- 완료율 통계
SELECT
  ROUND(AVG(CASE WHEN step4_completed = 1 THEN 100 ELSE 0 END), 2) as completion_rate,
  COUNT(*) as total_sessions
FROM workflow_sessions;

-- 허가 판정 분포
SELECT step4_result, COUNT(*) as count
FROM workflow_sessions
WHERE step4_completed = 1
GROUP BY step4_result;
```

---

## 🚀 배포 & 프로덕션

**상태**: ✅ Production Ready

**테스트 완료:**
- [x] 모든 API 엔드포인트 정상 작동
- [x] 데이터 일관성 확인
- [x] VWorld API 통합 검증
- [x] 에러 처리 및 폴백
- [x] 세션 관리 안정성

**PM2 설정:**
```bash
pm2 start server.js --name carwash-permit --update-env
pm2 save
pm2 startup
```

---

## 📝 로그 확인

```bash
# 실시간 로그
pm2 logs carwash-permit

# 에러 로그
tail -f /home/kimjin/.pm2/logs/carwash-permit-error.log

# 데이터베이스 상태
sqlite3 db/shop.db "SELECT COUNT(*) FROM workflow_sessions;"
```

---

**버전**: v1.0
**마지막 업데이트**: 2026-03-30 23:52
**상태**: 🟢 Production Ready
