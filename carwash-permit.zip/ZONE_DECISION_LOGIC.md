# 🎯 용도지역별 세차장 허가 판정 로직 (알고리즘)

**작성일**: 2026-03-30
**버전**: v1.0
**대상**: 개발자, 관리자

---

## 목차

1. [판정 알고리즘 (의사결정도)](#1-판정-알고리즘-의사결정도)
2. [코드 구현 (JavaScript)](#2-코드-구현-javascript)
3. [테스트 케이스](#3-테스트-케이스)
4. [의존 정보](#4-의존-정보)

---

## 1. 판정 알고리즘 (의사결정도)

### 의사결정 순서도 (Flowchart)

```
┌─────────────────────────────────┐
│  용도지역 정보 입력             │
│  (지번 또는 주소)               │
└──────────────┬──────────────────┘
               │
               ▼
┌─────────────────────────────────┐
│  토지이용계획확인원 조회        │
│  → 용도지역명 + 용도지역코드    │
└──────────────┬──────────────────┘
               │
               ▼
┌─────────────────────────────────┐
│  1. 절대 불가능 지역 확인?      │
│  ├─ 개발제한구역 (그린벨트)      │
│  ├─ 보전녹지지역 (G2)           │
│  ├─ 생산녹지지역 (G3)           │
│  ├─ 상수원보호구역               │
│  └─ 문화재보호구역               │
└──────────────┬──────────────────┘
               │
       ┌───────┴───────┐
       │               │
      YES              NO
       │               │
   ❌ REJECT      ┌────▼─────┐
   (불가)        │  결과    │
                  │ RESULT_1 │
                  └────┬─────┘
                       │
                       ▼
┌─────────────────────────────────┐
│  2. 무조건 가능 지역?            │
│  ├─ C1, C2, C3 (상업지역)        │
│  ├─ I1, I2 (공업지역)           │
│  ├─ R1, R3, R4, R5 (주거지역)   │
│  └─ 준주거지역                    │
└──────────────┬──────────────────┘
               │
       ┌───────┴───────┐
       │               │
      YES              NO
       │               │
   ⭐ PERMIT      ┌────▼─────┐
   (가능)        │  결과    │
                  │ RESULT_2 │
                  └────┬─────┘
                       │
                       ▼
┌─────────────────────────────────┐
│  3. 조건부 가능 지역?            │
│  ├─ R2 (2종일반주거)            │
│  ├─ I3 (보전공업)               │
│  └─ G1 (자연녹지)               │
└──────────────┬──────────────────┘
               │
       ┌───────┴───────┐
       │               │
      YES              NO
       │               │
   ⚠️ CONDITIONAL  ┌────▼─────┐
   (조건부)        │  결과    │
                  │ RESULT_3 │
                  └────┬─────┘
                       │
                       ▼
┌─────────────────────────────────┐
│  4. 그 외 (알 수 없음)           │
│  → R0 (전용주거)                 │
│  → 미분류 지역                    │
└──────────────┬──────────────────┘
               │
               ▼
        ❌ REJECT
        (불가)
```

---

### 상세 판정 로직

#### Step 1: 절대 불가능 지역 검증

```javascript
function isAbsolutelyProhibited(zoneInfo) {
  const prohibitedZones = [
    'G2',      // 보전녹지지역
    'G3',      // 생산녹지지역
    'PG',      // (코드 변형) 보전녹지
  ];

  const prohibitedConditions = [
    zoneInfo.isDevelopmentRestrictionZone,      // 개발제한구역 (그린벨트)
    zoneInfo.isWaterSourceProtectionArea,       // 상수원보호구역
    zoneInfo.isCulturalHeritageProtectionArea,  // 문화재보호구역
    zoneInfo.isUrbanNaturalPark,                 // 도시자연공원
  ];

  return (
    prohibitedZones.includes(zoneInfo.zoneCode) ||
    prohibitedConditions.some(cond => cond === true)
  );
}
```

#### Step 2: 무조건 가능 지역 검증

```javascript
function isUnconditionallyPermitted(zoneInfo) {
  const permitZones = [
    'C1', 'C2', 'C3',    // 상업지역 (모든 종류)
    'I1', 'I2',          // 공업지역 (일부)
    'R1', 'R3', 'R4', 'R5',  // 주거지역 (일부)
  ];

  return permitZones.includes(zoneInfo.zoneCode);
}
```

#### Step 3: 조건부 가능 지역 검증

```javascript
function isConditionallyPermitted(zoneInfo) {
  const conditionalZones = [
    'R2',      // 2종일반주거지역 (건폐율 조건)
    'I3',      // 보전공업지역 (환경기준)
    'G1',      // 자연녹지지역 (주차장+처리시설)
  ];

  return conditionalZones.includes(zoneInfo.zoneCode);
}
```

#### Step 4: 조건 상세 검증 (R2)

```javascript
function checkR2Conditions(buildingInfo) {
  const buildingArea = buildingInfo.floorArea;      // 건물 면적
  const totalLandArea = buildingInfo.totalLandArea; // 부지 전체 면적

  const coverageRatio = (buildingArea / totalLandArea) * 100;
  const hasParking = buildingInfo.parkingSpaces >= 6; // 최소 6대
  const hasWastewaterSystem = buildingInfo.hasWastewaterTreatment;

  return {
    isPassed: coverageRatio <= 60 && hasParking && hasWastewaterSystem,
    details: {
      coverageRatio: {
        value: coverageRatio.toFixed(2),
        requirement: '≤60%',
        status: coverageRatio <= 60 ? '✓' : '✗'
      },
      parking: {
        value: buildingInfo.parkingSpaces,
        requirement: '≥6',
        status: hasParking ? '✓' : '✗'
      },
      wastewaterSystem: {
        status: hasWastewaterSystem ? '✓' : '✗'
      }
    }
  };
}
```

#### Step 5: 조건 상세 검증 (G1)

```javascript
function checkG1Conditions(buildingInfo, zoneInfo) {
  const hasParking = buildingInfo.parkingSpaces >= 6;
  const hasAdvancedWastewaterSystem =
    buildingInfo.wastewaterTreatmentLevel >= 3; // 3단계 이상
  const greenSpaceRatio = buildingInfo.greenSpace /
    buildingInfo.totalLandArea * 100;
  const needsPriorConsultation = true; // 항상 필요

  return {
    isPassed: false, // G1은 항상 조건부 + 상담 필요
    details: {
      parking: {
        value: buildingInfo.parkingSpaces,
        requirement: '≥6',
        status: hasParking ? '✓' : '✗'
      },
      wastewaterSystem: {
        value: buildingInfo.wastewaterTreatmentLevel,
        requirement: '≥3단계',
        status: hasAdvancedWastewaterSystem ? '✓' : '✗'
      },
      greenSpaceRatio: {
        value: greenSpaceRatio.toFixed(2),
        requirement: '≥30%',
        status: greenSpaceRatio >= 30 ? '✓' : '✗'
      },
      priorConsultation: {
        requirement: '구청 사전협의 필수',
        status: '필수'
      }
    }
  };
}
```

---

## 2. 코드 구현 (JavaScript)

### 통합 판정 함수

```javascript
/**
 * 세차장 허가 판정 메인 함수
 * @param {Object} zoneInfo - 용도지역 정보
 * @param {Object} buildingInfo - 건축물 정보 (선택사항)
 * @returns {Object} 판정 결과
 */
function evaluateCarwashPermit(zoneInfo, buildingInfo = {}) {
  // 1단계: 입력값 검증
  if (!zoneInfo || !zoneInfo.zoneCode) {
    return {
      result: 'ERROR',
      message: '용도지역 정보가 필요합니다.',
      reason: null,
      conditions: [],
      nextStep: '토지이용계획확인원 확보'
    };
  }

  // 2단계: 절대 불가능 지역 확인
  if (isAbsolutelyProhibited(zoneInfo)) {
    return {
      result: 'REJECTED',
      message: '이 지역에는 세차장을 설치할 수 없습니다.',
      reason: getProhibitionReason(zoneInfo),
      conditions: [],
      nextStep: '다른 위치 검토'
    };
  }

  // 3단계: 무조건 가능 지역 확인
  if (isUnconditionallyPermitted(zoneInfo)) {
    return {
      result: 'PERMITTED',
      message: '세차장 설치가 허가됩니다.',
      reason: `${zoneInfo.zoneType}은 세차장 설치 용도로 허가됩니다.`,
      conditions: [
        '폐수처리시설 설치 필수',
        '주차장 안전 관리',
        '기술기준 준수'
      ],
      nextStep: '단계1: 토지이용계획확인원 발급'
    };
  }

  // 4단계: 조건부 가능 지역 확인
  if (isConditionallyPermitted(zoneInfo)) {
    // 각 지역별 조건 검증
    if (zoneInfo.zoneCode === 'R2') {
      if (!buildingInfo.totalLandArea || !buildingInfo.floorArea) {
        return {
          result: 'CONDITIONAL',
          message: '조건을 확인하려면 건축물 정보가 필요합니다.',
          reason: `${zoneInfo.zoneType}에서 조건부 허가 가능`,
          conditions: [
            '건폐율 60% 이하 확인 필요',
            '주차장 6대 이상 확보 필요',
            '폐수처리시설 설치 필수'
          ],
          nextStep: '건축물대장 확보'
        };
      }

      const r2Check = checkR2Conditions(buildingInfo);
      if (r2Check.isPassed) {
        return {
          result: 'PERMITTED',
          message: '조건을 만족하여 세차장 설치 허가 가능합니다.',
          reason: `${zoneInfo.zoneType}의 모든 조건 충족`,
          conditions: [
            `✓ 건폐율: ${r2Check.details.coverageRatio.value}% (기준: 60% 이하)`,
            `✓ 주차장: ${r2Check.details.parking.value}대 (기준: 6대 이상)`,
            `✓ 폐수처리시설 설치 확인`
          ],
          nextStep: '단계1: 토지이용계획확인원 발급'
        };
      } else {
        return {
          result: 'REJECTED',
          message: '일부 조건을 충족하지 않아 허가 불가합니다.',
          reason: `${zoneInfo.zoneType}의 조건 미충족`,
          conditions: r2Check.details,
          nextStep: '건축물 구조 재검토'
        };
      }
    }

    // G1 지역
    if (zoneInfo.zoneCode === 'G1') {
      return {
        result: 'CONDITIONAL',
        message: '구청 사전협의를 통해 가능성 검토 필요합니다.',
        reason: `${zoneInfo.zoneType}에서 조건부 허가 가능`,
        conditions: [
          '✓ 구청 도시계획과 사전협의 필수 (30일)',
          '✓ 주차장 6대 이상 확보',
          '✓ 고급 폐수처리시설 필수',
          '✓ 녹화면적 30% 이상',
          '✓ 경관심의 통과 필수',
          '✓ 환경영향평가 검토 (500㎡↑)'
        ],
        nextStep: '단계1: 토지이용계획확인원 발급 후 구청 상담'
      };
    }

    // I3 지역
    if (zoneInfo.zoneCode === 'I3') {
      return {
        result: 'CONDITIONAL',
        message: '환경기준 확인을 통해 가능성 검토 필요합니다.',
        reason: `${zoneInfo.zoneType}에서 조건부 허가 가능`,
        conditions: [
          '✓ 환경오염 최소화 설비 필수',
          '✓ 폐수처리 및 대기배출 저감계획',
          '✓ 구청 환경과 사전협의 권장'
        ],
        nextStep: '단계1: 토지이용계획확인원 발급 후 환경과 상담'
      };
    }
  }

  // 5단계: 그 외 (불가능)
  return {
    result: 'REJECTED',
    message: '이 지역에는 세차장을 설치할 수 없습니다.',
    reason: `${zoneInfo.zoneType}은 세차장 설치 불허 용도입니다.`,
    conditions: [],
    nextStep: '다른 위치 검토'
  };
}

/**
 * 불가능 사유 상세 설명
 */
function getProhibitionReason(zoneInfo) {
  const reasons = {
    'G2': '자연 생태계 보전을 위해 개발이 제한됩니다.',
    'G3': '농업 생산을 위해 개발이 제한됩니다.',
    'PG': '보전녹지로 지정되어 개발이 불가능합니다.',
    'R0': '저층주택 보호를 위해 상업시설은 불가합니다.',
  };

  let reason = reasons[zoneInfo.zoneCode] || '해당 용도지역에서는 세차장 설치가 불허됩니다.';

  // 추가 제약사항 확인
  if (zoneInfo.isDevelopmentRestrictionZone) {
    reason += ' (개발제한구역 지정)';
  }
  if (zoneInfo.isWaterSourceProtectionArea) {
    reason += ' (상수원보호구역 지정)';
  }
  if (zoneInfo.isCulturalHeritageProtectionArea) {
    reason += ' (문화재보호구역 지정)';
  }

  return reason;
}

/**
 * 검증 헬퍼: 절대 불가능 지역
 */
function isAbsolutelyProhibited(zoneInfo) {
  const prohibitedZones = ['G2', 'G3', 'PG', 'R0'];
  const hasProhibitedCondition =
    zoneInfo.isDevelopmentRestrictionZone ||
    zoneInfo.isWaterSourceProtectionArea ||
    zoneInfo.isCulturalHeritageProtectionArea ||
    zoneInfo.isUrbanNaturalPark;

  return prohibitedZones.includes(zoneInfo.zoneCode) || hasProhibitedCondition;
}

/**
 * 검증 헬퍼: 무조건 가능 지역
 */
function isUnconditionallyPermitted(zoneInfo) {
  const permitZones = ['C1', 'C2', 'C3', 'I1', 'I2', 'R1', 'R3', 'R4', 'R5'];
  return permitZones.includes(zoneInfo.zoneCode);
}

/**
 * 검증 헬퍼: 조건부 가능 지역
 */
function isConditionallyPermitted(zoneInfo) {
  const conditionalZones = ['R2', 'I3', 'G1'];
  return conditionalZones.includes(zoneInfo.zoneCode);
}

/**
 * R2 지역 조건 검증
 */
function checkR2Conditions(buildingInfo) {
  const buildingArea = buildingInfo.floorArea;
  const totalLandArea = buildingInfo.totalLandArea;

  const coverageRatio = (buildingArea / totalLandArea) * 100;
  const hasParking = buildingInfo.parkingSpaces >= 6;
  const hasWastewaterSystem = buildingInfo.hasWastewaterTreatment === true;

  return {
    isPassed: coverageRatio <= 60 && hasParking && hasWastewaterSystem,
    details: {
      coverageRatio: {
        value: coverageRatio.toFixed(2),
        requirement: '≤60%',
        status: coverageRatio <= 60 ? '✓' : '✗'
      },
      parking: {
        value: buildingInfo.parkingSpaces,
        requirement: '≥6',
        status: hasParking ? '✓' : '✗'
      },
      wastewaterSystem: {
        status: hasWastewaterSystem ? '✓' : '✗'
      }
    }
  };
}
```

---

### Express 라우트 구현

```javascript
// routes/permit-check.js

const express = require('express');
const router = express.Router();

/**
 * POST /api/permit/check
 * 세차장 허가 여부 판정
 */
router.post('/api/permit/check', (req, res) => {
  try {
    const { zoneType, zoneCode, buildingInfo, additionalInfo } = req.body;

    // 입력값 검증
    if (!zoneType && !zoneCode) {
      return res.status(400).json({
        error: '용도지역 정보 필수',
        message: 'zoneType 또는 zoneCode를 제공해주세요.'
      });
    }

    // 평가 수행
    const evaluation = evaluateCarwashPermit(
      {
        zoneCode: zoneCode || detectZoneCode(zoneType),
        zoneType: zoneType,
        isDevelopmentRestrictionZone: additionalInfo?.isDevelopmentRestrictionZone || false,
        isWaterSourceProtectionArea: additionalInfo?.isWaterSourceProtectionArea || false,
        isCulturalHeritageProtectionArea: additionalInfo?.isCulturalHeritageProtectionArea || false,
        isUrbanNaturalPark: additionalInfo?.isUrbanNaturalPark || false,
      },
      buildingInfo || {}
    );

    // 응답
    return res.json({
      result: evaluation.result,
      message: evaluation.message,
      reason: evaluation.reason,
      conditions: evaluation.conditions,
      nextStep: evaluation.nextStep
    });

  } catch (error) {
    console.error('Permit check error:', error);
    return res.status(500).json({
      error: 'Internal server error',
      message: error.message
    });
  }
});

/**
 * 용도지역명 → 코드 변환
 */
function detectZoneCode(zoneType) {
  const zoneMap = {
    '전용주거지역': 'R0',
    '1종일반주거지역': 'R1',
    '2종일반주거지역': 'R2',
    '3종일반주거지역': 'R3',
    '준주거지역': 'R4',
    '중주거지역': 'R5',
    '일반상업지역': 'C1',
    '근린상업지역': 'C2',
    '유흥상업지역': 'C3',
    '일반공업지역': 'I1',
    '환경친화공업지역': 'I2',
    '보전공업지역': 'I3',
    '자연녹지지역': 'G1',
    '보전녹지지역': 'G2',
    '생산녹지지역': 'G3',
  };

  // 정확한 매칭
  if (zoneMap[zoneType]) {
    return zoneMap[zoneType];
  }

  // 부분 매칭 (사용자 입력 편의)
  for (const [key, value] of Object.entries(zoneMap)) {
    if (key.includes(zoneType) || zoneType.includes(key)) {
      return value;
    }
  }

  return null;
}

module.exports = router;
```

---

## 3. 테스트 케이스

### 단위 테스트

```javascript
// test/permit-check.test.js

const assert = require('assert');
const {
  evaluateCarwashPermit,
  isAbsolutelyProhibited,
  isUnconditionallyPermitted,
  isConditionallyPermitted
} = require('../routes/permit-check');

describe('세차장 허가 판정 로직', () => {

  describe('절대 불가능 지역', () => {
    it('G2 (보전녹지지역)은 불가능', () => {
      const result = evaluateCarwashPermit({
        zoneCode: 'G2',
        zoneType: '보전녹지지역'
      });
      assert.strictEqual(result.result, 'REJECTED');
    });

    it('개발제한구역은 불가능', () => {
      const result = evaluateCarwashPermit({
        zoneCode: 'G1',
        zoneType: '자연녹지지역',
        isDevelopmentRestrictionZone: true
      });
      assert.strictEqual(result.result, 'REJECTED');
    });

    it('R0 (전용주거지역)은 불가능', () => {
      const result = evaluateCarwashPermit({
        zoneCode: 'R0',
        zoneType: '전용주거지역'
      });
      assert.strictEqual(result.result, 'REJECTED');
    });
  });

  describe('무조건 가능 지역', () => {
    it('C1 (일반상업지역)은 허가', () => {
      const result = evaluateCarwashPermit({
        zoneCode: 'C1',
        zoneType: '일반상업지역'
      });
      assert.strictEqual(result.result, 'PERMITTED');
    });

    it('R1 (1종일반주거지역)은 허가', () => {
      const result = evaluateCarwashPermit({
        zoneCode: 'R1',
        zoneType: '1종일반주거지역'
      });
      assert.strictEqual(result.result, 'PERMITTED');
    });

    it('I1 (일반공업지역)은 허가', () => {
      const result = evaluateCarwashPermit({
        zoneCode: 'I1',
        zoneType: '일반공업지역'
      });
      assert.strictEqual(result.result, 'PERMITTED');
    });
  });

  describe('조건부 가능 지역', () => {
    it('R2 조건 만족 시 허가', () => {
      const result = evaluateCarwashPermit(
        {
          zoneCode: 'R2',
          zoneType: '2종일반주거지역'
        },
        {
          floorArea: 600,
          totalLandArea: 1000,
          parkingSpaces: 6,
          hasWastewaterTreatment: true
        }
      );
      assert.strictEqual(result.result, 'PERMITTED');
    });

    it('R2 건폐율 초과 시 불가', () => {
      const result = evaluateCarwashPermit(
        {
          zoneCode: 'R2',
          zoneType: '2종일반주거지역'
        },
        {
          floorArea: 700, // 70% 건폐율
          totalLandArea: 1000,
          parkingSpaces: 6,
          hasWastewaterTreatment: true
        }
      );
      assert.strictEqual(result.result, 'REJECTED');
    });

    it('G1은 항상 조건부', () => {
      const result = evaluateCarwashPermit({
        zoneCode: 'G1',
        zoneType: '자연녹지지역'
      });
      assert.strictEqual(result.result, 'CONDITIONAL');
    });
  });

});
```

---

## 4. 의존 정보

### 필수 입력 데이터

| 필드 | 타입 | 예시 | 필수 |
|------|------|------|------|
| zoneCode | String | 'C1', 'R2', 'G1' | O |
| zoneType | String | '일반상업지역' | O |
| isDevelopmentRestrictionZone | Boolean | true/false | X |
| isWaterSourceProtectionArea | Boolean | true/false | X |
| isCulturalHeritageProtectionArea | Boolean | true/false | X |
| isUrbanNaturalPark | Boolean | true/false | X |
| floorArea | Number | 600 | R2 시 필수 |
| totalLandArea | Number | 1000 | R2 시 필수 |
| parkingSpaces | Number | 6 | R2 시 필수 |
| hasWastewaterTreatment | Boolean | true | R2 시 필수 |

### 외부 의존성

- **VWorld API**: 용도지역 자동 조회
- **정부24 API**: 토지이용계획확인원
- **건축물대장 API**: 건물 정보 자동 조회

---

## 참고

- 알고리즘 최종 검증일: 2026-03-30
- 법령 기준: 2026년 현행 건축법
- 다음 업데이트: 법령 개정 시

