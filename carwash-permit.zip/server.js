const express = require('express');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 40090;
const USE_MOCK = process.env.USE_MOCK === 'true';
const NODE_ENV = process.env.NODE_ENV || 'development';

// ✅ P1-1: 에러 처리 및 로깅 함수
class Logger {
  log(level, msg, data = null) {
    const timestamp = new Date().toISOString();
    const logEntry = {
      timestamp,
      level,
      msg,
      ...(data && { data })
    };
    console.log(JSON.stringify(logEntry));
  }

  info(msg, data) { this.log('INFO', msg, data); }
  warn(msg, data) { this.log('WARN', msg, data); }
  error(msg, data) { this.log('ERROR', msg, data); }
}

const logger = new Logger();

// 에러 ID 생성 (추적용)
function generateErrorId() {
  return crypto.randomBytes(4).toString('hex').toUpperCase();
}

// ✅ P0-1: 레이트 리미팅 (DDoS 방지)
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,  // 15분
  max: 100,                    // 100 요청
  message: '요청 수를 초과했습니다. 15분 후 다시 시도하세요.',
  standardHeaders: true,       // RateLimit-* 헤더 표시
  legacyHeaders: false         // X-RateLimit-* 헤더 비활성화
});

// ✅ P0-2: 타임아웃 설정 (무한 대기 방지)
app.use((req, res, next) => {
  res.setTimeout(30000, () => {  // 30초 타임아웃
    res.status(408).json({
      success: false,
      error: '요청 시간 초과 (30초). 다시 시도해주세요.'
    });
  });
  next();
});

// 모든 API에 레이트 리미팅 적용
app.use('/api/', limiter);

app.use(express.json());

// ✅ 캐시 제어: HTML은 항상 최신, 다른 파일은 1시간 캐시
app.use(express.static(path.join(__dirname, 'public'), {
  setHeaders: function(res, filePath) {
    if (filePath.endsWith('.html')) {
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
    } else {
      res.setHeader('Cache-Control', 'public, max-age=3600');
    }
  }
}));

// ============ P1-2: zone-mapping.json 싱글톤 캐싱 ============
// 파일 시스템 접근 최소화: 첫 로드 후 메모리 캐시 사용
const zoneMapCache = (() => {
  let cache = null;
  return {
    get: () => {
      if (!cache) {
        try {
          const zoneMappingPath = path.join(__dirname, 'data', 'zone-mapping.json');
          cache = JSON.parse(fs.readFileSync(zoneMappingPath, 'utf8'));
          console.log('✅ zone-mapping.json 캐시 로드됨');
        } catch (err) {
          console.warn('⚠️ zone-mapping.json 로드 실패:', err.message);
          cache = {}; // 빈 객체로 폴백
        }
      }
      return cache;
    }
  };
})();

// ============ Mock 데이터 ============
const MOCK_ADDRESSES = [
  {
    roadAddr: '서울시 강남구 테헤란로 123',
    jibunAddr: '강남구 역삼동 123-4',
    sigunguCd: '11680',
    bjdongCd: '10100',
    bcode: '1168010100101230004',
    pnu: '1168010100101230004'
  },
  {
    roadAddr: '서울시 강남구 테헤란로 456',
    jibunAddr: '강남구 역삼동 456-7',
    sigunguCd: '11680',
    bjdongCd: '10100',
    bcode: '1168010100101450001',
    pnu: '1168010100101450001'
  },
  {
    roadAddr: '서울시 송파구 올림픽로 100',
    jibunAddr: '송파구 방이동 100-50',
    sigunguCd: '11710',
    bjdongCd: '10300',
    bcode: '1171010300101000050',
    pnu: '1171010300101000050'
  }
];

// VWorld API 응답 파싱
function parseVWorldResponse(vworldData, pnu) {
  try {
    if (!vworldData || !vworldData.features || vworldData.features.length === 0) {
      console.log('VWorld: 데이터 없음, Mock 반환');
      return getMockLandData('2');
    }

    const feature = vworldData.features[0];
    const props = feature.properties || {};

    // VWorld 응답에서 필요한 정보 추출
    // LP_PA_CBND_BUBUN 테이블 속성:
    // - LPC_LC_NM: 용도지역명
    // - LPC_LC_CLS_NM: 용도지역분류명
    // - GID: 지물ID
    // - JIMOK_NM: 지목명

    const zoneType = props.LPC_LC_NM || props.LPC_LC_CLS_NM || '용도지역 미분류';
    const jimok = props.JIMOK_NM || props.JMOK_NM || '대';
    const area = props.area ? Math.round(props.area) : 0;

    return {
      zoneType: zoneType.trim(),
      zoneCode: props.LPC_LC_CLS_CD || 'UNK',
      jimok: jimok.trim(),
      area: area > 0 ? area + '' : '미측정',
      source: 'VWorld API',
      pnu: pnu
    };
  } catch (err) {
    console.warn('VWorld 파싱 오류:', err.message);
    return getMockLandData('2');
  }
}

// 용도지역 Mock 데이터 (3가지 시나리오)
function getMockLandData(scenario = '2') {
  const scenarios = {
    '1': {
      zoneType: '상업지역 (일반상업지역)',
      zoneCode: 'C1',
      jimok: '대',
      area: '1500',
      note: '세차장 설치 가능'
    },
    '2': {
      zoneType: '제2종일반주거지역',
      zoneCode: 'R2',
      jimok: '대',
      area: '1200',
      note: '조건부 가능'
    },
    '3': {
      zoneType: '보전녹지지역',
      zoneCode: 'PG',
      jimok: '임',
      area: '2000',
      note: '세차장 설치 불가'
    }
  };
  return scenarios[scenario] || scenarios['2'];
}

// 건축물대장 Mock 데이터
const MOCK_BUILDING = [
  {
    bldNm: '테스트빌딩 A동',
    mainPurpsCdNm: '제1종근린생활시설',
    totalFlrAr: '1500',
    emdNm: '역삼동',
    bdMgtSn: '11680-10100-0123-00001',
    crtnDay: '20150315',
    useAprDay: '20150415'
  }
];

// ============ API Endpoints ============

// ① 주소 검색 (Mock 또는 실제 API)
app.get('/api/address/search', async (req, res) => {
  const { query } = req.query;

  if (USE_MOCK || !process.env.JUSO_KEY) {
    // Mock: 쿼리에 포함된 주소 필터링
    const results = MOCK_ADDRESSES.filter(addr =>
      addr.roadAddr.includes(query || '') || addr.jibunAddr.includes(query || '')
    );
    return res.json({
      success: true,
      mock: true,
      results: results.length > 0 ? results : MOCK_ADDRESSES
    });
  }

  try {
    // 실제 행안부 API 호출 (구현 필요)
    res.json({ success: true, results: [] });
  } catch (err) {
    res.json({ success: false, results: MOCK_ADDRESSES });
  }
});

// ② 용도지역 조회 (sigunguCode 기반 또는 VWorld API)
app.get('/api/land/zone', async (req, res) => {
  const { pnu, sigunguCd, scenario } = req.query;

  // 테스트용 시나리오 파라미터 처리
  if (scenario) {
    const landData = getMockLandData(scenario);
    return res.json({
      success: true,
      mock: true,
      mockScenario: scenario,
      data: landData
    });
  }

  // sigunguCode 기반 용도지역 조회 (시군구별 매핑)
  if (sigunguCd) {
    try {
      // ⭐ P1-2: 캐시된 zone-mapping 사용 (파일 I/O 제거)
      const zoneMapping = zoneMapCache.get();

      // 시군구 기본 정보 조회
      const sigunguInfo = zoneMapping.regional_defaults[sigunguCd];

      if (sigunguInfo) {
        // 기본 용도지역 반환 (주로 주거/상업 혼합지역)
        const primaryZoneCode = sigunguInfo.primary_zone;
        const zoneDetail = zoneMapping.zones[primaryZoneCode];

        const landData = {
          zoneCode: primaryZoneCode,
          zoneType: `${zoneDetail.name} (${sigunguInfo.sigungu_name})`,
          jimok: '대',
          area: '조회 예정',
          source: 'sigunguCode 기반 매핑',
          sigunguCd: sigunguCd,
          sigunguName: sigunguInfo.sigungu_name,
          sido: sigunguInfo.sido,
          note: zoneDetail.reason
        };

        return res.json({
          success: true,
          mock: false,
          source: 'sigunguCode mapping',
          data: landData
        });
      }
    } catch (err) {
      console.warn(`⚠️ 시군구 매핑 조회 오류: ${err.message}`);
    }
  }

  // 실제 VWorld API 사용 (USE_MOCK=false 이고 API 키 있을 때)
  if (!USE_MOCK && process.env.VWORLD_KEY && pnu) {
    try {
      console.log(`🌐 VWorld API 호출: PNU=${pnu}`);

      const vworldUrl = 'https://api.vworld.kr/req/data';
      const params = new URLSearchParams({
        service: 'data',
        version: '2.0',
        request: 'GetFeature',
        data: 'LP_PA_CBND_BUBUN',
        attrFilter: `pnu:=${pnu}`,
        crs: 'EPSG:4326',
        format: 'json',
        key: process.env.VWORLD_KEY
      });

      const response = await fetch(`${vworldUrl}?${params}`);
      const vworldData = await response.json();

      // VWorld 응답 파싱
      const landData = parseVWorldResponse(vworldData, pnu);

      return res.json({
        success: true,
        mock: false,
        source: 'VWorld API',
        data: landData
      });
    } catch (err) {
      console.warn(`⚠️ VWorld API 오류: ${err.message}`);
      // 오류 시 Mock 데이터로 폴백
      const landData = getMockLandData('2');
      return res.json({
        success: true,
        mock: true,
        fallback: 'VWorld API 오류 - Mock 데이터 사용',
        data: landData
      });
    }
  }

  // 기본: Mock 모드
  const landData = getMockLandData(scenario || '2');
  return res.json({
    success: true,
    mock: true,
    reason: 'Mock 모드 또는 API 키 미설정',
    data: landData
  });
});

// ② - 1 용도지역 매핑 정보 (토지용도 기준)
app.get('/api/zones', (req, res) => {
  try {
    // ⭐ P1-2: 캐시된 zone-mapping 사용 (파일 I/O 제거)
    const zoneMapping = zoneMapCache.get();

    res.json({
      success: true,
      zones: zoneMapping.zones,
      district_zones: zoneMapping.district_zones,
      permit_rules: zoneMapping.permit_rules
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: '용도지역 정보 조회 실패: ' + err.message
    });
  }
});

// ② - 2 건축물용도 정보 (용도변경 가능성)
app.get('/api/building-purposes', (req, res) => {
  try {
    const buildingPurposesPath = path.join(__dirname, 'data', 'building-purposes.json');
    const buildingPurposes = JSON.parse(fs.readFileSync(buildingPurposesPath, 'utf8'));

    res.json({
      success: true,
      purposes: buildingPurposes.purposes,
      change_requirements: buildingPurposes.change_requirements,
      process_flowchart: buildingPurposes.process_flowchart
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: '건축물용도 정보 조회 실패: ' + err.message
    });
  }
});

// 특정 건축물용도 상세 정보
app.get('/api/building-purposes/:purpose_name', (req, res) => {
  try {
    const buildingPurposesPath = path.join(__dirname, 'data', 'building-purposes.json');
    const buildingPurposes = JSON.parse(fs.readFileSync(buildingPurposesPath, 'utf8'));
    const { purpose_name } = req.params;

    const purpose = buildingPurposes.purposes[purpose_name];
    if (!purpose) {
      return res.status(404).json({
        success: false,
        error: '해당 건축물용도를 찾을 수 없습니다'
      });
    }

    res.json({
      success: true,
      purpose_name: purpose_name,
      details: purpose,
      change_requirements: buildingPurposes.change_requirements
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: err.message
    });
  }
});

// ③ 건축물대장 조회 (Mock 또는 국토부 API)
app.get('/api/building/info', async (req, res) => {
  const { sigunguCd, bjdongCd, bun, ji } = req.query;

  if (USE_MOCK || !process.env.DATA_API_KEY) {
    return res.json({
      success: true,
      mock: true,
      data: MOCK_BUILDING
    });
  }

  try {
    // 실제 국토부 건축물대장 API 호출 (구현 필요)
    res.json({ success: true, data: MOCK_BUILDING });
  } catch (err) {
    res.json({ success: false, data: MOCK_BUILDING });
  }
});

// ④ 관공서 연락처 (로컬 JSON)
app.get('/api/offices', (req, res) => {
  try {
    const officesPath = path.join(__dirname, 'data', 'offices.json');
    const offices = JSON.parse(fs.readFileSync(officesPath, 'utf8'));
    const { region } = req.query;

    // 지역에 해당하는 환경청 찾기
    let matchedOffices = offices.유역환경청;
    if (region && region.trim()) {
      matchedOffices = offices.유역환경청.filter(o =>
        o.관할.some(r => r === region)
      );
    }

    res.json({
      success: true,
      offices: matchedOffices,
      departments: offices.담당부서
    });
  } catch (err) {
    res.json({
      success: false,
      error: '관공서 조회 실패',
      offices: []
    });
  }
});

// ⑤ 허가 판단 규칙 엔진
app.post('/api/permit/check', (req, res) => {
  const { zoneType } = req.body;
  const result = checkPermit(zoneType);
  res.json(result);
});

// ============ 허가 판단 규칙 엔진 ============
function checkPermit(zoneType) {
  if (!zoneType) {
    return {
      result: '미확인',
      reason: '용도지역을 먼저 확인해주세요',
      conditions: [],
      checkList: []
    };
  }

  // 용도지역 포함 여부 체크
  const isAllowed = (zone) => zoneType.includes(zone);

  // 허가 불가능 지역
  if (isAllowed('보전녹지') || isAllowed('생산녹지') ||
      isAllowed('도시자연공원') || isAllowed('상수원보호') ||
      isAllowed('개발제한구역') || isAllowed('전용주거')) {
    return {
      result: '불가',
      resultColor: 'result-ng',
      reason: '세차장 설치가 금지된 지역입니다',
      reasonDetail: '해당 용도지역에서는 세차장을 설치할 수 없습니다',
      conditions: [
        '보전 및 생산 녹지지역 불가',
        '상수원 보호구역 불가',
        '개발제한구역(그린벨트) 불가'
      ],
      checkList: [],
      nextStep: '다른 위치를 검토해주세요'
    };
  }

  // 조건부 가능 지역
  if (isAllowed('제2종일반주거') || isAllowed('자연녹지')) {
    return {
      result: '조건부가능',
      resultColor: 'result-cond',
      reason: '일정 조건을 만족하면 허가 가능합니다',
      reasonDetail: '건폐율, 주차장 등 추가 조건 확인 필요',
      conditions: [
        '✓ 건폐율 60% 이하 확인 필요',
        '✓ 주차장 면적 (최소 6대) 확보',
        '✓ 폐수처리시설 설치 의무',
        '✓ 인접 주거지역 영향 최소화',
        '✓ 소음·악취 방지 시설'
      ],
      checkList: [
        '☐ 토지이용계획확인원',
        '☐ 건축물대장',
        '☐ 사업계획서 (시설배치도, 폐수 처리계획)',
        '☐ 폐수배출시설 설치신고 신청서',
        '☐ 수질오염방지시설 도면',
        '☐ 건축허가/신고 신청서'
      ],
      nextStep: '자세한 조건은 관할 구청 건축과 또는 환경과에 문의해주세요'
    };
  }

  // 허가 가능 지역
  if (isAllowed('상업지역') || isAllowed('공업지역') ||
      isAllowed('준주거') || isAllowed('일반주거')) {
    return {
      result: '가능',
      resultColor: 'result-ok',
      reason: '세차장 설치가 가능한 지역입니다',
      reasonDetail: '허가 요건을 충족하면 설치 가능',
      conditions: [
        '✓ 폐수처리시설 설치 의무',
        '✓ 사업자 자격 확인',
        '✓ 환경 기준 준수'
      ],
      checkList: [
        '☐ 토지이용계획확인원',
        '☐ 건축물대장 (필요시)',
        '☐ 사업계획서',
        '☐ 폐수배출시설 설치신고서',
        '☐ 자동차관련시설 건축허가/신고 신청서',
        '☐ 사업자등록'
      ],
      nextStep: '다음 단계로 진행하세요'
    };
  }

  // 기본값
  return {
    result: '확인필요',
    resultColor: 'result-cond',
    reason: '정확한 판단을 위해 관할 관청에 직접 문의가 필요합니다',
    reasonDetail: '용도지역 분류가 명확하지 않으니 전문가 상담을 권고합니다',
    conditions: [],
    checkList: ['☐ 관할 구청 건축과 방문/전화 상담'],
    nextStep: '관할 환경관청에 직접 연락해주세요'
  };
}

// ============ 거리 계산 함수 (Haversine) ============
function calculateDistance(lat1, lon1, lat2, lon2) {
  const R = 6371; // 지구 반지름 (km)
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

// ⑥ 주변 세차장 검색 (NEW)
app.get('/api/carwash/nearby', (req, res) => {
  const { latitude, longitude, radius } = req.query;
  const lat = parseFloat(latitude);
  const lon = parseFloat(longitude);
  const searchRadius = parseInt(radius) || 5; // 기본값 5km

  if (!lat || !lon || isNaN(lat) || isNaN(lon)) {
    return res.json({
      success: false,
      error: '위도/경도 필수',
      data: []
    });
  }

  try {
    const carwashPath = path.join(__dirname, 'data', 'carwash.json');
    const carwashData = JSON.parse(fs.readFileSync(carwashPath, 'utf8'));
    const nearby = carwashData.carwashes
      .map(cw => ({
        ...cw,
        distance: calculateDistance(lat, lon, cw.latitude, cw.longitude)
      }))
      .filter(cw => cw.distance <= searchRadius)
      .sort((a, b) => a.distance - b.distance);

    res.json({
      success: true,
      count: nearby.length,
      radius: searchRadius,
      centerPoint: { latitude: lat, longitude: lon },
      data: nearby
    });
  } catch (err) {
    console.warn('세차장 검색 오류:', err.message);
    res.json({
      success: false,
      error: '세차장 검색 실패',
      data: []
    });
  }
});

// ⑦ 세차장 통계 조회 (NEW)
app.get('/api/carwash/statistics', (req, res) => {
  const { region } = req.query;

  try {
    const carwashPath = path.join(__dirname, 'data', 'carwash.json');
    const carwashData = JSON.parse(fs.readFileSync(carwashPath, 'utf8'));

    console.log(`📊 통계 조회: region=${region}, available=${Object.keys(carwashData.statistics)}`);

    if (region) {
      const regionStats = carwashData.statistics[region];
      console.log(`  검색 결과: ${regionStats ? '찾음' : '없음'}`);

      if (!regionStats) {
        return res.json({
          success: false,
          error: '지역 데이터 없음',
          availableRegions: Object.keys(carwashData.statistics),
          data: {}
        });
      }
      return res.json({
        success: true,
        region: region,
        statistics: regionStats
      });
    }

    // 전국 통계
    res.json({
      success: true,
      metadata: carwashData.metadata,
      statistics: carwashData.statistics
    });
  } catch (err) {
    console.warn('통계 조회 오류:', err.message);
    res.json({
      success: false,
      error: '통계 조회 실패',
      data: {}
    });
  }
});

// ⑧ 폐수처리 기준 조회 (NEW)
app.get('/api/wastewater/standards', (req, res) => {
  const { basin, zoneType, dailyDischarge } = req.query;

  try {
    const wastewaterPath = path.join(__dirname, 'data', 'wastewater-standards.json');
    const wastewaterData = JSON.parse(fs.readFileSync(wastewaterPath, 'utf8'));

    // 1. 전체 메타데이터 반환
    if (!basin && !zoneType && !dailyDischarge) {
      return res.json({
        success: true,
        metadata: wastewaterData.metadata,
        classification: {
          zones: wastewaterData.zoneClassification.zones,
          basins: wastewaterData.carwashSpecificStandards.regionSpecific.map(b => ({
            basin: b.basin,
            regions: b.basins
          }))
        }
      });
    }

    // 2. 지역(유역) 및 구역 기반 기준 조회
    if (basin && zoneType) {
      const zoneData = wastewaterData.zoneClassification.zones.find(z =>
        z.zoneCode === zoneType || z.zoneName.includes(zoneType)
      );

      if (!zoneData) {
        return res.status(400).json({
          success: false,
          error: '해당 지역 분류를 찾을 수 없습니다',
          availableZones: wastewaterData.zoneClassification.zones.map(z => ({
            code: z.zoneCode,
            name: z.zoneName
          }))
        });
      }

      const basinData = wastewaterData.carwashSpecificStandards.regionSpecific.find(b =>
        b.basin === basin || b.basins.includes(basin)
      );

      // 기본 기준과 지역 강화기준 병합
      const standards = {
        ...zoneData.basePollutants,
        ...basinData?.strengthened
      };

      return res.json({
        success: true,
        basin: basin,
        zone: {
          code: zoneData.zoneCode,
          name: zoneData.zoneName,
          description: zoneData.description
        },
        standards: standards,
        additionalRequirements: basinData?.additionalRequirements || [],
        unit: 'mg/L (유분, 색도 제외)'
      });
    }

    // 3. 일일 배출량 기반 신고 기준 조회
    if (dailyDischarge) {
      const discharge = parseFloat(dailyDischarge);
      const notificationData = wastewaterData.notificationStandards.notificationTrigger.find(nt => {
        const range = nt.dailyDischarge.split('~').map(s => s.trim());
        if (nt.dailyDischarge.includes('<')) {
          return discharge < parseFloat(range[0]);
        } else if (nt.dailyDischarge.includes('>')) {
          return discharge >= parseFloat(range[0]);
        } else if (nt.dailyDischarge.includes('~')) {
          const [min, max] = range.map(s => parseFloat(s.split('ton')[0]));
          return discharge >= min && discharge <= max;
        }
      });

      if (!notificationData) {
        return res.status(400).json({
          success: false,
          error: '해당 배출량 기준을 찾을 수 없습니다'
        });
      }

      return res.json({
        success: true,
        dailyDischarge: dailyDischarge,
        requirement: notificationData.requirement,
        requiredFacilities: notificationData.facilities,
        inspectionSchedule: notificationData.inspection
      });
    }

    res.json({
      success: false,
      error: '쿼리 파라미터 필요: basin, zoneType, 또는 dailyDischarge'
    });
  } catch (err) {
    console.warn('폐수기준 조회 오류:', err.message);
    res.status(500).json({
      success: false,
      error: '폐수기준 조회 실패: ' + err.message
    });
  }
});

// ⑨ 폐수 처리시설 정보 조회 (NEW)
app.get('/api/wastewater/facilities', (req, res) => {
  const { type } = req.query;

  try {
    const wastewaterPath = path.join(__dirname, 'data', 'wastewater-standards.json');
    const wastewaterData = JSON.parse(fs.readFileSync(wastewaterPath, 'utf8'));

    if (type) {
      const facility = wastewaterData.treatmentFacilities.facilities.find(f =>
        f.name.includes(type) || f.type.includes(type)
      );

      if (!facility) {
        return res.status(404).json({
          success: false,
          error: '해당 시설을 찾을 수 없습니다',
          availableFacilities: wastewaterData.treatmentFacilities.facilities.map(f => ({
            name: f.name,
            type: f.type
          }))
        });
      }

      return res.json({
        success: true,
        facility: facility
      });
    }

    // 전체 시설 정보
    res.json({
      success: true,
      description: wastewaterData.treatmentFacilities.description,
      facilities: wastewaterData.treatmentFacilities.facilities.map(f => ({
        name: f.name,
        type: f.type,
        function: f.function
      }))
    });
  } catch (err) {
    console.warn('처리시설 조회 오류:', err.message);
    res.status(500).json({
      success: false,
      error: '처리시설 조회 실패'
    });
  }
});

// ⑩ 점검 및 유지관리 기준 조회 (NEW)
app.get('/api/wastewater/inspection', (req, res) => {
  const { dailyDischarge } = req.query;

  try {
    const wastewaterPath = path.join(__dirname, 'data', 'wastewater-standards.json');
    const wastewaterData = JSON.parse(fs.readFileSync(wastewaterPath, 'utf8'));

    if (dailyDischarge) {
      const discharge = parseFloat(dailyDischarge);
      const inspectionData = wastewaterData.inspectionAndMaintenance.inspectionSchedule.find(is => {
        const range = is.dailyDischarge.split('~').map(s => s.trim());
        if (is.dailyDischarge.includes('<')) {
          return discharge < parseFloat(range[0]);
        } else if (is.dailyDischarge.includes('>')) {
          return discharge >= parseFloat(range[0]);
        } else if (is.dailyDischarge.includes('~')) {
          const [min, max] = range.map(s => parseFloat(s.split('ton')[0]));
          return discharge >= min && discharge <= max;
        }
      });

      if (!inspectionData) {
        return res.status(400).json({
          success: false,
          error: '해당 배출량의 점검 기준을 찾을 수 없습니다'
        });
      }

      return res.json({
        success: true,
        dailyDischarge: dailyDischarge,
        inspectionSchedule: inspectionData
      });
    }

    // 전체 점검 기준
    res.json({
      success: true,
      inspectionSchedule: wastewaterData.inspectionAndMaintenance.inspectionSchedule,
      recordManagement: wastewaterData.inspectionAndMaintenance.recordManagement
    });
  } catch (err) {
    console.warn('점검기준 조회 오류:', err.message);
    res.status(500).json({
      success: false,
      error: '점검기준 조회 실패'
    });
  }
});

// ⑪ 세차장별 사례 및 체크리스트 조회 (NEW)
app.get('/api/wastewater/cases', (req, res) => {
  const { carwashType } = req.query;

  try {
    const wastewaterPath = path.join(__dirname, 'data', 'wastewater-standards.json');
    const wastewaterData = JSON.parse(fs.readFileSync(wastewaterPath, 'utf8'));

    if (carwashType) {
      const caseData = wastewaterData.caseSamples.samples.find(s =>
        s.type.includes(carwashType) || s.type.toLowerCase() === carwashType.toLowerCase()
      );

      if (!caseData) {
        return res.status(404).json({
          success: false,
          error: '해당 세차장 사례를 찾을 수 없습니다',
          availableTypes: wastewaterData.caseSamples.samples.map(s => s.type)
        });
      }

      return res.json({
        success: true,
        caseData: caseData
      });
    }

    // 전체 사례 및 체크리스트
    res.json({
      success: true,
      caseSamples: wastewaterData.caseSamples.samples,
      checklist: wastewaterData.checklist,
      notes: wastewaterData.noteAndWarnings
    });
  } catch (err) {
    console.warn('사례 조회 오류:', err.message);
    res.status(500).json({
      success: false,
      error: '사례 조회 실패'
    });
  }
});

// ============ 근처 세차장 API ============
const getCarwashDB = (() => {
  let db = null;
  return () => {
    if (!db) {
      const sqlite3 = require('better-sqlite3');
      db = new sqlite3(path.join(__dirname, 'db', 'carwash.db'));
      console.log('✅ 세차장 DB 연결됨');
    }
    return db;
  };
})();

// 두 좌표 간 거리 계산 (Haversine formula, km)
function getDistance(lat1, lon1, lat2, lon2) {
  const R = 6371; // 지구 반지름 (km)
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

// GET /api/carwash/nearby - 근처 세차장 조회
app.get('/api/carwash/nearby', (req, res) => {
  try {
    const { latitude, longitude, radius = 5, limit = 20 } = req.query;

    if (!latitude || !longitude) {
      return res.status(400).json({
        success: false,
        error: '위도/경도 필수'
      });
    }

    const lat = parseFloat(latitude);
    const lon = parseFloat(longitude);
    const rad = parseFloat(radius);

    const db = getCarwashDB();
    const stores = db.prepare(`
      SELECT id, name, road_address, phone, latitude, longitude,
             sigungu, business_type, carwash_type
      FROM carwash_stores
      WHERE latitude IS NOT NULL AND longitude IS NOT NULL
      LIMIT 100
    `).all();

    // 거리 계산 및 정렬
    const nearby = stores
      .map(store => ({
        ...store,
        distance: getDistance(lat, lon, store.latitude, store.longitude)
      }))
      .filter(store => store.distance <= rad)
      .sort((a, b) => a.distance - b.distance)
      .slice(0, limit);

    res.json({
      success: true,
      center: { latitude: lat, longitude: lon },
      radius: rad,
      stores: nearby,
      count: nearby.length,
      total: stores.length
    });
  } catch (err) {
    console.error('근처 세차장 조회 오류:', err);
    res.status(500).json({
      success: false,
      error: err.message
    });
  }
});

// GET /api/carwash/list - 지역별 세차장 목록
app.get('/api/carwash/list', (req, res) => {
  try {
    const { sido, sigungu, limit = 50 } = req.query;

    let sql = 'SELECT * FROM carwash_stores WHERE 1=1';
    const params = [];

    if (sido) {
      sql += ' AND sido = ?';
      params.push(sido);
    }
    if (sigungu) {
      sql += ' AND sigungu = ?';
      params.push(sigungu);
    }

    sql += ' ORDER BY name LIMIT ?';
    params.push(parseInt(limit));

    const db = getCarwashDB();
    const stores = db.prepare(sql).all(...params);

    res.json({
      success: true,
      stores: stores,
      count: stores.length
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: err.message
    });
  }
});

// GET /api/carwash/regions - 시도/시군구 목록
app.get('/api/carwash/regions', (req, res) => {
  try {
    const db = getCarwashDB();

    const sidos = db.prepare(`
      SELECT DISTINCT sido FROM carwash_stores ORDER BY sido
    `).all().map(r => r.sido);

    const regions = {};
    sidos.forEach(sido => {
      const sigunguList = db.prepare(`
        SELECT DISTINCT sigungu FROM carwash_stores
        WHERE sido = ? AND sigungu IS NOT NULL
        ORDER BY sigungu
      `).all(sido).map(r => r.sigungu);
      regions[sido] = sigunguList;
    });

    res.json({
      success: true,
      sidos: sidos,
      regions: regions
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: err.message
    });
  }
});

// ============ 건축물 데이터 초기화 ============
try {
  const Database = require('better-sqlite3');
  const buildingsDb = new Database(path.join(__dirname, 'db/init.db'));

  try {
    const buildingCount = buildingsDb.prepare('SELECT COUNT(*) as count FROM buildings').get().count;
    if (buildingCount === 0) {
      console.log('⏳ 건축물 데이터 로드 중...');
      buildingsDb.close();
      require('./db/load-buildings');
      console.log('✅ 건축물 데이터 로드 완료');
    } else {
      console.log(`✅ 건축물 DB 준비 완료: ${buildingCount}개`);
    }
  } catch (err) {
    // 테이블이 없으면 load-buildings 실행
    buildingsDb.close();
    console.log('⏳ 건축물 테이블 생성 중...');
    require('./db/load-buildings');
  }
} catch (err) {
  console.warn('⚠️ 건축물 데이터 초기화 오류:', err.message);
}

// ============ 라우트 등록 ============
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use('/api/shop', require('./routes/shopRoutes'));
app.use('/api/admin', require('./routes/adminRoutes'));
app.use('/api/regulations', require('./routes/regulationRoutes'));
app.use('/api/workflow', require('./routes/workflowRoutes'));
app.get('/admin', (req, res) => res.sendFile(path.join(__dirname, 'public', 'admin.html')));

// ============ P1-1: 글로벌 에러 핸들러 ============
// 404 - 라우트 없음
app.use((req, res) => {
  res.status(404).json({
    success: false,
    code: 'NOT_FOUND',
    message: '요청한 엔드포인트를 찾을 수 없습니다',
    path: req.path
  });
});

// 500 - 서버 에러
app.use((err, req, res, next) => {
  const errorId = generateErrorId();
  const isDev = NODE_ENV === 'development';

  // 서버 로그에는 항상 전체 정보 기록
  logger.error(`[ERR-${errorId}] ${err.message}`, {
    stack: err.stack,
    method: req.method,
    path: req.path,
    ip: req.ip
  });

  // 클라이언트에는 환경에 따라 다른 정보 반환
  const statusCode = err.statusCode || err.status || 500;
  res.status(statusCode).json({
    success: false,
    code: err.code || 'INTERNAL_SERVER_ERROR',
    message: isDev ? err.message : '서버 오류가 발생했습니다. 관리자에게 문의하세요.',
    errorId: isDev ? `ERR-${errorId}` : undefined,  // 개발 환경에서만 에러 ID 제공
    timestamp: new Date().toISOString()
  });
});

// ============ 서버 시작 ============
app.listen(PORT, () => {
  const mode = USE_MOCK ? '(Mock 모드)' : '(실제 API 모드)';
  console.log(`\n✅ 세차장 허가 체크 서버 실행 중 ${mode}`);
  console.log(`📍 http://localhost:${PORT}`);
  console.log(`\n포트: ${PORT}`);
  console.log(`Mock 모드: ${USE_MOCK}`);
  console.log(`\n엔드포인트:`);
  console.log(`  GET  /api/address/search?query=...`);
  console.log(`  GET  /api/land/zone?pnu=...&scenario=1|2|3`);
  console.log(`  GET  /api/building/info?sigunguCd=...&bjdongCd=...`);
  console.log(`  GET  /api/offices?region=...`);
  console.log(`  POST /api/permit/check (zoneType 필요)`);
  console.log(`  GET  /api/carwash/nearby?latitude=...&longitude=...&radius=5`);
  console.log(`  GET  /api/carwash/statistics?region=...`);
  console.log(`\n폐수처리 기준 엔드포인트 (NEW):`);
  console.log(`  GET  /api/wastewater/standards (메타데이터)`);
  console.log(`  GET  /api/wastewater/standards?basin=한강유역&zoneType=가지역`);
  console.log(`  GET  /api/wastewater/standards?dailyDischarge=30`);
  console.log(`  GET  /api/wastewater/facilities`);
  console.log(`  GET  /api/wastewater/facilities?type=침전지`);
  console.log(`  GET  /api/wastewater/inspection`);
  console.log(`  GET  /api/wastewater/inspection?dailyDischarge=30`);
  console.log(`  GET  /api/wastewater/cases`);
  console.log(`  GET  /api/wastewater/cases?carwashType=자동세차장\n`);
});
