const fs = require('fs');
const path = require('path');
const readline = require('readline');
const XLSX = require('xlsx');
require('dotenv').config();

const db = require('./db/init');

// ===== 1. 용도지역정보 로드 =====
async function loadZoneInfo() {
  console.log('\n📍 1. 용도지역정보(도시계획) 로드...');

  const csvFile = '/home/kimjin/다운로드/gov-data/KLIP_004/KP_SPUA_DSWE.csv';

  if (!fs.existsSync(csvFile)) {
    console.warn('⚠️ 파일 없음:', csvFile);
    return;
  }

  return new Promise((resolve) => {
    let count = 0;
    let skipCount = 0;

    // ⭐ P1-1: 테이블은 db/schema.sql에서 생성됨 (중복 제거)

    const insertStmt = db.prepare(`
      INSERT OR IGNORE INTO zone_info
      (wevd_cd, sgg_cd, wevd_ty_stcd, lcls_cd, mcls_cd, area_m2)
      VALUES (?, ?, ?, ?, ?, ?)
    `);

    const fileStream = fs.createReadStream(csvFile, { encoding: 'utf-8' });
    const rl = readline.createInterface({
      input: fileStream,
      crlfDelay: Infinity
    });

    let isHeader = true;

    rl.on('line', (line) => {
      if (isHeader) {
        isHeader = false;
        return;
      }

      try {
        // CSV 파싱
        const cols = line.split(',');
        if (cols.length < 13) return;

        const wevd_cd = cols[0]?.trim();
        const sgg_cd = cols[3]?.trim();
        const wevd_ty_stcd = cols[6]?.trim();
        const lcls_cd = cols[11]?.trim();
        const mcls_cd = cols[12]?.trim();
        const area_chng_af = parseFloat(cols[16]?.trim()) || 0;

        if (!wevd_cd || !sgg_cd) return;

        insertStmt.run(wevd_cd, sgg_cd, wevd_ty_stcd, lcls_cd, mcls_cd, area_chng_af);
        count++;

        if (count % 50000 === 0) {
          console.log(`⏳ 처리 중... ${count}개`);
        }
      } catch (err) {
        skipCount++;
      }
    });

    rl.on('close', () => {
      console.log(`✅ 용도지역정보 로드 완료: ${count}개`);
      resolve();
    });

    rl.on('error', (err) => {
      console.error('❌ 오류:', err.message);
      resolve();
    });
  });
}

// ===== 2. 토지이용규제 행위제한정보 로드 =====
async function loadLandUseRegulations() {
  console.log('\n📋 2. 토지이용규제 행위제한정보 로드 (스킵 - 큰 파일)');
  console.log('   ℹ️  나중에 별도로 처리 가능');
  return;
}

// ===== 3. 지역별 용도지역 매핑 조회 =====
function createZoneMapping() {
  console.log('\n🔗 3. 경기도 용도지역 매핑 생성...');

  // 경기도 시군구 코드
  const gyeonggiSgCodes = [
    '41000', '41100', '41200', '41300', '41400', '41500', '41600',
    '41700', '41800', '41900', '42000', '42100', '42200', '42300',
    '42400', '42500', '42600', '42700', '42800', '42900', '43000',
    '43100', '43200', '43300'
  ];

  const mapping = db.prepare(`
    SELECT
      sgg_cd,
      lcls_cd,
      mcls_cd,
      COUNT(*) as count,
      SUM(area_m2) as total_area
    FROM zone_info
    WHERE sgg_cd IN (${gyeonggiSgCodes.map(() => '?').join(',')})
    GROUP BY sgg_cd, lcls_cd, mcls_cd
    ORDER BY sgg_cd, count DESC
  `).all(...gyeonggiSgCodes);

  // 코드 매핑 (공식 용도지역 분류)
  const zoneCodeMap = {
    'UQA100': '농업지역',
    'UQA123': '생산녹지지역',
    'UQA400': '보전녹지지역',
    'URR100': '주거지역',
    'URR110': '전용주거지역',
    'URR120': '1종일반주거지역',
    'URR130': '2종일반주거지역',
    'URR140': '3종일반주거지역',
    'URR150': '준주거지역',
    'UCO100': '상업지역',
    'UCO110': '중심상업지역',
    'UCO120': '일반상업지역',
    'UCO130': '근린상업지역',
    'UCO140': '유통상업지역',
    'UIO100': '공업지역',
    'UIO110': '전용공업지역',
    'UIO120': '일반공업지역',
    'UIO130': '준공업지역',
    'UGR100': '관리지역',
    'UGR110': '보전관리지역',
    'UGR120': '생산관리지역',
    'UGR130': '계획관리지역',
    'UNZ100': '자연지역',
    'UNZ110': '자연보전지역',
    'UNZ120': '자연휴양지역'
  };

  console.log(`✅ 경기도 용도지역 매핑: ${mapping.length}개 항목`);
  console.log('\n🏙️ 상위 15개 용도지역:');

  mapping.slice(0, 15).forEach(row => {
    const zoneName = zoneCodeMap[row.mcls_cd] || row.mcls_cd || '미분류';
    console.log(`  ${zoneName}: ${row.count}개 필지, ${(row.total_area / 1000000).toFixed(1)}km²`);
  });

  return mapping;
}

// ===== 4. 통계 출력 =====
function printStats() {
  console.log('\n📈 DB 통계:');

  const zoneCount = db.prepare('SELECT COUNT(*) as count FROM zone_info').get().count;
  console.log(`  용도지역정보: ${zoneCount}개`);

  const devCount = db.prepare('SELECT COUNT(*) as count FROM development_permits').get().count;
  console.log(`  개발행위허가: ${devCount}개`);
}

// ===== Main =====
async function main() {
  try {
    console.log('🚀 정부 공공데이터 통합 로드 시작...\n');

    await loadZoneInfo();
    await loadLandUseRegulations();
    createZoneMapping();
    printStats();

    console.log('\n✅ 모든 데이터 로드 완료!');
    console.log('💡 다음 단계: /api/workflow/{sessionId}/step/2에서 zone_info 테이블 활용');
  } catch (err) {
    console.error('❌ 오류:', err.message);
    process.exit(1);
  }
}

// ⭐ P1-1: 모듈로 export (init.js에서 호출 가능)
module.exports = { loadZoneInfo, createZoneMapping, printStats, main };

// 직접 실행 시: node load-gov-data.js
if (require.main === module) {
  main();
}
